# vb-god2f.6 actual recovery-error refinement scout

Status: scoped implementation-bound proof BLOCKED by actual return datatype support under pinned verifier/no-new-trust policy. Native behavior and concrete counterexample verified. No formal replacement candidate or closure claim.

Owner: live vb-god2f.6 claimed from OPEN to IN_PROGRESS, owner/assignee Lewis; parent vb-god2f and sibling vb-god2f.3 untouched. Exact base34bfc925a4e1c4a6fc179db2836995c2a3b835b0. Git and JJ roots verified /home/lewis/src/isoloated/vb-recovery-refinement-r24. Scoped contract written before any test-oracle mutation at .beads/vb-god2f.6/contract.md. Production, formal source and original test all remain byte-identical to base. Only contract/evidence artifacts added; all persistent, CPU-only.

## Actual finite decision and callers

Storage RecoveryFrameSeedProduct carries either its typed CannotResume witness or a Resumable frame-seed product. The public compatibility frame boundary consumes this through DurableFrameRecoveryBoundary::from_seed/from_product (recovery.rs:160-198), which builds the actual private DurableFrameRecoveryProduct. ShapeCheckedRecoveryFrameProduct::parse in runtime recovery/product.rs:106-121 first calls the actual validate_recovery_seed_shape on the seed, then preserves the storage product variant. Malformed shape becomes DurableFrameRecoveryProduct::InvalidShape; a shape-checked product becomes CannotResumeRecoveryFrame because a frame seed alone lacks full RunState components.

Exact target at crates/vb_runtime/src/recovery/product.rs:43-48 returns InvalidRecoveryHydration only for InvalidShape and delegates CannotResume to the actual method at :159-163. That actual method returns RuntimeError::RecoveryCannotResume with String::from(self.cannot_resume.unsupported_reason()). The public RuntimeRecoveryBoundary implementation at recovery.rs:223-225 forwards directly to the actual private product. recovery_boundary_from_hydration at :230-243 preserves the typed FrameSeed path; SummaryRecoveryBoundary::hydrate_run_frame at :266-268 independently returns UnsupportedFullRecoveryHydration. These are distinct surfaces and error outcomes.

Production full recovery follows a parallel path: Runtime::recover_product in runtime/recovery_product.rs:8 builds RuntimeRecoveryProduct, whose real variants in recovery/full/product.rs:13-20 are SummaryOnly, CannotResume and Resumable. NonResumableRecoveryProduct retains state and optional terminal reason, and reason() at :111-116 preserves an explicit reason or derives it from the actual typed state. Runtime::recover_and_resume at runtime/cancel_recovery.rs:45-52 enqueues only Resumable. rejected_recovery_product_error in runtime/retry_validation.rs:28-42 maps CannotResume to typed RecoveryCannotResume and other rejected products to UnsupportedFullRecoveryHydration. It does not route through the compatibility DurableFrameRecoveryBoundary. No broader RunState/replay or production readiness proof is inferred from the finite compatibility mapping.

## Defect in the old proof claim

verification/verus/recovery_verification.rs:1656-1680 defines spec_runtime_collapses_to_invalid_recovery_hydration and proves its own four-variant mirrored RecoveryError predicate. It never calls the actual product hydration method. The proof lemma is internally true of that self-defined predicate; it does not establish the universal runtime claim in its surrounding prose. The actual domain here is DurableFrameRecoveryProduct, not the four-variant copied storage RecoveryError subset. extern_recovery_verification.rs:896-903 also declares a substitute RuntimeError without RecoveryCannotResume, and includes FrameDimensionOverflow despite the real runtime not having that variant. Opaque hydrate_run_frame_preconditions_pure at :1069 is Boolean conjunction over ten supplied flags and supplies no product/error correspondence.

All historical recovery.rs:108-150 numeric citations remain exactly unchanged, including the latest central numeric refresh. That span contains the trait/status/declaration/documentation area, not the two actual product method bodies above. It is not silently replaced with old95-137 or relabeled as actual binding. No spec, requires, ensures, mirror enum or mathematical contract was weakened or rewritten to make the discrepancy disappear.

## Actual native counterexample and restored checks

Canonical focused native command: TMPDIR=$PWD/target/tmp CARGO_TARGET_DIR=$PWD/target/native CARGO_BUILD_JOBS=2 CARGO_NET_OFFLINE=true RUSTC_WRAPPER= RUSTFLAGS=-Dwarnings NEXTEST_TEST_THREADS=4 timeout 7m rustup run nightly-2026-04-28 cargo nextest run --cargo-quiet --all-features -p vb_runtime --lib --test recovery_hydration_tests -E 'test(durable_frame_recovery_boundary_rejects_inconsistent_seed) | test(runtime_boundary_exposes_supported_pending_actions_state) | test(runtime_boundary_exposes_unsupported_state) | test(recovery_boundary_factory_preserves_storage_cannot_resume_witness_on_invalid_shape)'. First run native-caller.log/.exit: 4 run, 4 passed, 2689 skipped; exit0. These are existing actual production-calling fixtures: two shape-valid pending_actions/slot_taint typed rejections, malformed shape rejection, and invalid shape with the storage cannot-resume witness still observable.

For raw observational evidence, changed only the existing slot_taint fixture's expected result to the historical universal InvalidRecoveryHydration assertion, with its production inputs and called boundary unchanged. Exact one-case nextest command retains the same pinned toolchain, all-features and -Dwarnings flags, test binary recovery_hydration_tests, filter test(runtime_boundary_exposes_unsupported_state), timeout2m. old-claim-negative.log/.exit reports nextest exit100 and:

    left: Err(RecoveryCannotResume { reason: "slot_taint" })
    right: Err(InvalidRecoveryHydration)

This is an old-claim oracle negative on a real native caller, not a production-body mutation and not a formal counterexample to an unrelated mirror input. No copied RuntimeError or fake predicate was introduced. The test was restored from the saved original, and test-before.sha256 verifies exact byte restoration. The complete focused command reran after restoration (timeout2m, other flags identical): native-restored.log/.exit shows 4/4 passed,2689 skipped,exit0. No failing mutant remains. All production/formal/test source paths compare equal to base; source.sha256 preserves the actual evidence inputs.

## Exact type-binding blocker, reusing pinned audit

Installed verifier checked as Verus0.2026.05.05.d03e906, Linux x86_64, Rust1.95.0. The actual target signature returns RuntimeResult<RunFrame>, whose real error is crate::RuntimeError. Actual RuntimeError::Core at error/mod.rs:56-60 and EngineDriveFailed at :325-331 contain Box<vb_core::errors::CoreError>. Actual CoreError's variants at errors.rs:699,711,725,739,753,765 contain DateTime<Utc>. Thus this target inherits the same unsupported actual Chrono payload dependency already audited for .28, even though the finite method constructs only the two recovery error variants.

Reused pinned primary-source audit /home/lewis/src/isoloated/vb-walk-weight-r24/.evidence/chrono-audit-r24/report.md, SHA25686864270aef98e9ca0138169e12f5779ffa8ebcf3f125a2380514574764aea5a. Read its actual rust_to_vir_adts.rs snapshot: lines63-86 translate each field type before consulting field mode; lines251-268 visit every enum variant before choosing transparency. external_derive only excludes automatically derived impl items; it does not omit unsupported variant payload types. Existing raw source-preserved failures show actual DateTime/Utc rejection, then real Chrono source translation blocked on TimeZone and NonZeroI32/FixedOffset paths. No dependency fleet was recompiled or model support invented in this task.

Consequently a direct actual-return proof cannot presently use the approved source route without adding a forbidden opaque/external datatype assumption or changing actual error representation. No actual-return verifier run is claimed for .6, and no fake local identity/classifier or alternate error enum was offered as proof. This is a precise prerequisite/type-support boundary, not a claim that future verifier approaches or all recovery work are impossible. RunFrame/other full product dependencies have not been exhaustively qualified past this blocking boundary. A proof for the actual method, wrong-result production-body formal negative, independent candidate CODE/TEST and source/drift closure remain unperformed because no viable no-new-trust candidate was produced.

Own production-binding gate exits0 and reports zero VACUUM,34 existing weak mirrors. This inventory pass does not prove the absent actual product binding. git diff --check and explicit source equality checks exit0. No production/proof source, protected config, public API, schema, dependency, feature, runtime guard or numeric citation change was made. All remaining proof work stays on the existing in-progress child, not a falsely closed parent or duplicated follow-up.

## Concrete next ownership decision

Root may accept the scoped investigation/evidence record while keeping vb-god2f.6 in progress. Actual-return closure needs supported actual RuntimeError/CoreError/Chrono datatype translation under the unchanged no-new-trust policy, or an explicit separately approved representation/toolchain/interface change. This task requests none of those changes and does not preapprove one. Correcting only prose or narrowing the old mirror predicate cannot satisfy the actual implementation-bound acceptance contract.

Recommended local documentation commit proposal, if the scoped contract is selected for tracking:

docs(verification): scope recovery error refinement

- .beads/vb-god2f.6/contract.md
