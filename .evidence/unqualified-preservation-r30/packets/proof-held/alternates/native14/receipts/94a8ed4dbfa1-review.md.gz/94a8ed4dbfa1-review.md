# Independent TEST review of the nested Together cursor

**APPROVED — ACCEPTABLE for the three-file cursor change against native private-kernel baseline 483e93a82dc3a4544f04eef6fd571d123cf593bc.** The corrected walk.rs SHA256 is 5e742f393352eb47b17b2db4e74b797694c4c3441279bbc5b36d200430769c7f. The cursor_proof.rs SHA256 is 603367937c3d6151db5c1930233b212c5d8a54fb7195fa0627f8ac23f79d3634. The walk_spec.rs SHA256 is c9d8701e780b3c40cd8f480f8316c8a442e218cfacce83502be2b0ac130b55ff.

The baseline matched its 546-file manifest before applying the cursor files. The fully materialized corrected 547-file owner source matches the root candidate byte-for-byte. Its complete manifest has SHA256 fe1ced70903da4c4f2643fd1f52fceb08328ef0d90b347a42b5d75ef7b0d0055. Exactly the three files above differ from the baseline. The earlier cursor candidate with the attribute directly on an assignment failed native compilation. The corrected guarded block compiled with Rust 1.95 and warnings denied. This review kept the previous workspace, bookmarks and all tracked source untouched.

Independent native verification passed all 4,034 vb_core tests with four test threads, strict package Clippy, and workspace formatting. The full source-length scan passed for 1,535 production files with zero over-limit. The initial ordinary gate invocation selected the enclosing JJ inventory and failed on its path prefixes. The final run used the repository script's documented materialized-root mode and separately executed its exact compile-split check, which the alternate-root mode omits. Both returned 0. No test, lint, scanner or gate source was edited.

All 5,192 public differential outcomes matched the f3660037 baseline byte-for-byte, SHA256 c10f83442dd3c0cfb73ee41075329953d10751e7d858df3e2a3ea6980d26cdf8. An outer row physically beyond 65,535 retained its stored ID, and an inner candidate at 65,535 remained selectable. Both outputs matched their baseline, SHA256 3fc4f483299c2289a5073f4727e23bbcc0a0b9c3d9e6f01780609d51326ece8c. The additional seven native cursor cases exercised the actual included implementation. On a wide start, the contains traversal returned None and the find traversal returned stored outer 17. Both found representable candidate 65,535. Both exclusive-stop and out-of-range visits returned no match. Advancing the native cursor on 65,536 marked that row and preserved pending candidate 1, which the next advance found. The narrow harness printed nine dead-code warnings for members of the included private module it did not call. Strict full-library lint and compilation were clean.

The root's frozen current Verus log reports 73 verified, 0 errors. A separate CODE reviewer reran that proof, as reported by the coordinator. This TEST pass did not consume another solver slot. Its acceptance covers the cursor behavior and source-form correction. It makes no allocation or speed claim. Public chrono-backed error conversion, qualification of the newly combined projection against this cursor, registry wiring and full bead closure remain open.

## Proposed commit

```text
refactor(core): share nested Together traversal state

Keep each traversal's worklist and visited rows in its own cursor.
Prove the distinct overflow results for the contains and find passes.

crates/vb_core/src/engine/validate/nested_together/walk.rs
crates/vb_core/src/engine/validate/nested_together/cursor_proof.rs
crates/vb_core/src/engine/validate/nested_together/walk_spec.rs
```
