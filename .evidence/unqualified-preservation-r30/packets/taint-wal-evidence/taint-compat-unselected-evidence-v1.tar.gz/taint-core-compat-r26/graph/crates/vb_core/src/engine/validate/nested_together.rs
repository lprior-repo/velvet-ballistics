use crate::ids::StepIdx;
use crate::workflow::{CompiledNode, CompiledNodeKind, WorkflowError, WorkflowParts};
use std::collections::BTreeSet;

/// Rejects `TogetherStart` nodes that are reachable from the body of
/// another `TogetherStart` node.
///
/// `compute_max_parallel_in_flight` (in `vb_runtime::engine::drive`)
/// returns a per-node maximum branch count rather than the true peak
/// parallel-in-flight, so a nested `TogetherStart` produces a
/// `ParallelLimitExceeded` at runtime even when no real concurrency
/// limit has been violated. Surfacing the structural error at compile
/// time (RE-001, option (b)) gives operators a typed, deterministic
/// rejection with a precise location instead of a misleading runtime
/// signal.
pub fn validate_no_nested_together(parts: &WorkflowParts) -> Result<(), WorkflowError> {
    match first_nested_together(&parts.nodes) {
        Some((outer, inner)) => Err(WorkflowError::NestedTogether { outer, inner }),
        None => Ok(()),
    }
}

#[cfg_attr(verus_keep_ghost, vstd::prelude::verus_spec(result => ensures result == first_pair(nodes@)))]
fn first_nested_together(nodes: &[CompiledNode]) -> Option<(StepIdx, StepIdx)> {
    let (keys, has_two_starts) = collect_together_starts(nodes);
    if !has_two_starts {
        return None;
    }
    let mut index = 0usize;
    while index < nodes.len() {
        #[cfg(verus_keep_ghost)]
        #[cfg_attr(verus_keep_ghost, cfg(verus_keep_ghost_body))]
        invariant(verus_proof_expr!(
            index <= nodes@.len() && first_pair(nodes@) == first_outer_from(nodes@, keys@, index as nat)
        ));
        #[cfg(verus_keep_ghost)]
        decreases(verus_proof_expr!(nodes@.len() - index));
        let node = nodes.get(index)?;
        if let Some(inner) = find_nested_together_in_node(nodes, &keys, node) {
            return Some((node.id, inner));
        }
        index = index.checked_add(1)?;
    }
    None
}

#[cfg_attr(verus_keep_ghost, vstd::prelude::verus_spec(result => ensures
    result.0@ == start_ids_before(nodes@,nodes@.len()).to_set(),
    result.1 == (start_ids_before(nodes@,nodes@.len()).len() >= 2),
))]
fn collect_together_starts(nodes: &[CompiledNode]) -> (BTreeSet<u16>, bool) {
    let mut keys = std::collections::BTreeSet::new();
    let mut has_two = false;
    let mut index = 0usize;
    while index < nodes.len() {
        #[cfg(verus_keep_ghost)]
        #[cfg_attr(verus_keep_ghost, cfg(verus_keep_ghost_body))]
        invariant(verus_proof_expr!(
            index <= nodes@.len() && keys@ == start_ids_before(nodes@,index as nat).to_set()
            && has_two == (start_ids_before(nodes@,index as nat).len() >= 2)
        ));
        #[cfg(verus_keep_ghost)]
        #[cfg_attr(verus_keep_ghost, cfg(verus_keep_ghost_body))]
        decreases(verus_proof_expr!(nodes@.len() - index));
        let Some(node) = nodes.get(index) else {
            return (keys, has_two);
        };
        #[cfg(verus_keep_ghost)]
        vstd::prelude::proof! { record_start_prefix(nodes@,index as nat); }
        has_two = record_together_start(node, &mut keys, has_two);
        let Some(next) = index.checked_add(1) else {
            return (keys, has_two);
        };
        index = next;
    }
    (keys, has_two)
}

#[cfg_attr(verus_keep_ghost, vstd::prelude::verus_spec(result => ensures
    final(keys)@ == if together_start(node) { old(keys)@.insert(node.id.raw_spec()) } else { old(keys)@ },
    result == if together_start(node) { !old(keys)@.is_empty() } else { has_two },
))]
fn record_together_start(node: &CompiledNode, keys: &mut BTreeSet<u16>, has_two: bool) -> bool {
    if matches!(
        &node.kind,
        CompiledNodeKind::TogetherStart { .. } | CompiledNodeKind::TogetherConcurrentStart { .. }
    ) {
        let has_previous = !keys.is_empty();
        keys.insert(node.id.get());
        has_previous
    } else {
        has_two
    }
}

#[cfg_attr(verus_keep_ghost, vstd::prelude::verus_spec(result => ensures result == node_result(nodes@, keys@, node)))]
fn find_nested_together_in_node(
    nodes: &[CompiledNode],
    keys: &BTreeSet<u16>,
    node: &CompiledNode,
) -> Option<StepIdx> {
    match &node.kind {
        CompiledNodeKind::TogetherStart { branches, join }
        | CompiledNodeKind::TogetherConcurrentStart { branches, join } => {
            first_nested_branch(nodes, keys, branches, *join, node.id)
        }
        _ => None,
    }
}

#[cfg_attr(verus_keep_ghost, vstd::prelude::verus_spec(result => ensures result == first_branch_from(nodes@,keys@,branches@,join,outer,0)))]
fn first_nested_branch(
    nodes: &[CompiledNode],
    keys: &BTreeSet<u16>,
    branches: &[StepIdx],
    join: StepIdx,
    outer: StepIdx,
) -> Option<StepIdx> {
    let mut index = 0usize;
    while index < branches.len() {
        #[cfg(verus_keep_ghost)]
        #[cfg_attr(verus_keep_ghost, cfg(verus_keep_ghost_body))]
        invariant(verus_proof_expr!(
            index <= branches@.len() && first_branch_from(nodes@,keys@,branches@,join,outer,0)
            == first_branch_from(nodes@,keys@,branches@,join,outer,index as nat)
        ));
        #[cfg(verus_keep_ghost)]
        decreases(verus_proof_expr!(branches@.len() - index));
        let entry = branches.get(index)?;
        if let Some(inner) = find_nested_together_in_branch(nodes, keys, entry, join, outer) {
            return Some(inner);
        }
        index = index.checked_add(1)?;
    }
    None
}

#[cfg_attr(verus_keep_ghost,vstd::prelude::verus_spec(result => ensures result == branch_result(nodes@,together_set@,*branch_entry,join,outer)))]
fn find_nested_together_in_branch(
    nodes: &[CompiledNode],
    together_set: &BTreeSet<u16>,
    branch_entry: &StepIdx,
    join: StepIdx,
    outer: StepIdx,
) -> Option<StepIdx> {
    let entry_idx = branch_entry.as_usize();
    if entry_idx >= nodes.len() || join.as_usize() >= nodes.len() {
        return None;
    }
    if walk_contains_together_start(nodes, together_set, entry_idx, join.as_usize(), outer) {
        return Some(find_inner_together_start(
            nodes,
            together_set,
            entry_idx,
            join.as_usize(),
            outer,
        ));
    }
    None
}

include!("nested_together/successors.rs");
include!("nested_together/walk.rs");
#[cfg(verus_keep_ghost)]
include!("nested_together/scan_spec.rs");
#[cfg(verus_keep_ghost)]
include!("nested_together/walk_spec.rs");

#[cfg(verus_keep_ghost)]
include!("nested_together/projected_equivalence.rs");
