use super::*;
use crate::workflow::{ResourceContract, SecretResultPolicy};

#[test]
fn legacy_default_contract_bytes_and_digest_are_stable() {
    // Preserve the original default wire fixture while current runtime caps evolve.
    let legacy_default = ResourceContract {
        max_steps: 10_000,
        max_constants: u16::MAX,
        ..ResourceContract::DEFAULT
    };
    let bytes = encode_contract_bytes(&legacy_default);
    let expected = concat!(
        "7265736f757263655f636f6e74726163746d61785f737465707310276d61785f736c6f747300046d61785f",
        "636f6e7374616e7473ffff6d61785f6163636573736f727300206d61785f65787072657373696f6e730010",
        "6d61785f657870725f737461636b406d61785f737465705f6275646765745f7065725f7469636b10270000",
        "000000006d61785f7472616e736974696f6e735f7065725f7469636b10270000000000006d61785f696e70",
        "75745f6279746573000010006d61785f6f75747075745f6279746573000004006d61785f626c6f625f6279",
        "74657300000001000000006d61785f6970635f7061796c6f61645f6279746573000010006d61785f726574",
        "72795f617474656d70747303006d61785f66616e6f757440006d61785f636f6c6c6563745f6974656d7300",
        "0400006d61785f71756575655f6465707468000400006d61785f6a6f75726e616c5f62617463685f627974",
        "657300001000616c6c6f77735f7365637265745f726573756c747300"
    );
    assert_eq!(hex_encode(&bytes), expected);
    assert_eq!(
        blake3::hash(&bytes).to_hex().as_str(),
        "4bd79814352278253245f250a0cc9d55f6e94afecf9009b14b0ac50f8b2e8f1c"
    );
}

fn hex_encode(bytes: &[u8]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

// ---------------------------------------------------------------------------
// I1: Encoding determinism
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_is_deterministic() {
    let contract = ResourceContract::DEFAULT;
    let enc1 = encode_contract_bytes(&contract);
    let enc2 = encode_contract_bytes(&contract);
    assert_eq!(
        enc1, enc2,
        "encode_contract_bytes must produce identical output for identical input"
    );
}

#[test]
fn encode_contract_bytes_is_deterministic_for_random_contract() {
    let mut contract = ResourceContract::DEFAULT;
    contract.max_steps = 500;
    contract.max_slots = 64;
    contract.allows_secret_results = SecretResultPolicy::Allow;
    let enc1 = encode_contract_bytes(&contract);
    let enc2 = encode_contract_bytes(&contract);
    assert_eq!(
        enc1, enc2,
        "encode_contract_bytes must be deterministic for any contract"
    );
}

// ---------------------------------------------------------------------------
// I2: All 17 field tags present in canonical order
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_contains_all_17_field_tags_in_order() {
    let contract = ResourceContract::DEFAULT;
    let bytes = encode_contract_bytes(&contract);
    // The first tag is the header "resource_contract"
    assert!(
        bytes
            .windows(b"resource_contract".len())
            .any(|w| w == b"resource_contract"),
        "Must contain 'resource_contract' header"
    );

    let expected_tags: &[&[u8]] = &[
        b"max_steps",
        b"max_slots",
        b"max_constants",
        b"max_accessors",
        b"max_expressions",
        b"max_expr_stack",
        b"max_step_budget_per_tick",
        b"max_transitions_per_tick",
        b"max_input_bytes",
        b"max_output_bytes",
        b"max_blob_bytes",
        b"max_ipc_payload_bytes",
        b"max_retry_attempts",
        b"max_fanout",
        b"max_collect_items",
        b"max_queue_depth",
        b"max_journal_batch_bytes",
        b"allows_secret_results",
    ];

    // Each tag must appear in order
    let mut prev_pos = 0usize;
    for (i, tag) in expected_tags.iter().enumerate() {
        if let Some(pos) = bytes[prev_pos..].windows(tag.len()).position(|w| w == *tag) {
            let _actual_pos = prev_pos + pos;
            prev_pos = prev_pos + pos + tag.len();
            // Verify the tag is found
            assert!(
                pos < bytes.len(),
                "Tag {} ({}) must be present in encoding output",
                i,
                std::str::from_utf8(tag).unwrap_or("?")
            );
        } else {
            panic!(
                "Tag {}/{} ({}) missing from encode_contract_bytes output",
                i,
                expected_tags.len(),
                std::str::from_utf8(tag).unwrap_or("?")
            );
        }
    }
}

// ---------------------------------------------------------------------------
// I3: Little-endian encoding for multi-byte values
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_uses_little_endian_for_max_steps_u16() {
    let mut contract = ResourceContract::DEFAULT;
    contract.max_steps = 0x0102u16;
    let bytes = encode_contract_bytes(&contract);
    // Find the value bytes after "max_steps" tag
    let tag = b"max_steps";
    let tag_pos = bytes
        .windows(tag.len())
        .position(|w| w == tag)
        .expect("max_steps tag must be present");
    let val_start = tag_pos + tag.len();
    // The u16 value should be two bytes: 0x02, 0x01 (little-endian)
    assert_eq!(bytes[val_start], 0x02, "u16 LSB should be first byte");
    assert_eq!(bytes[val_start + 1], 0x01, "u16 MSB should be second byte");
}

#[test]
fn encode_contract_bytes_uses_little_endian_for_max_transitions_per_tick_u64() {
    let mut contract = ResourceContract::DEFAULT;
    contract.max_transitions_per_tick = 0x0102_0304_0506_0708u64;
    let bytes = encode_contract_bytes(&contract);
    let tag = b"max_transitions_per_tick";
    let tag_pos = bytes
        .windows(tag.len())
        .position(|w| w == tag)
        .expect("max_transitions_per_tick tag must be present");
    let val_start = tag_pos + tag.len();
    // u64 LE: lowest byte first
    assert_eq!(bytes[val_start], 0x08, "u64 LSB should be first byte");
    assert_eq!(bytes[val_start + 7], 0x01, "u64 MSB should be last byte");
}

#[test]
fn encode_contract_bytes_uses_little_endian_for_max_blob_bytes_u64() {
    let mut contract = ResourceContract::DEFAULT;
    contract.max_blob_bytes = 0xDEADBEEFu64;
    let bytes = encode_contract_bytes(&contract);
    let tag = b"max_blob_bytes";
    let tag_pos = bytes
        .windows(tag.len())
        .position(|w| w == tag)
        .expect("max_blob_bytes tag must be present");
    let val_start = tag_pos + tag.len();
    // 0xDEADBEEF in LE: EF BE AD DE 00 00 00 00
    assert_eq!(bytes[val_start], 0xEF, "u64 LSB should be first byte");
    assert_eq!(bytes[val_start + 1], 0xBE);
    assert_eq!(bytes[val_start + 2], 0xAD);
    assert_eq!(bytes[val_start + 3], 0xDE);
}

// ---------------------------------------------------------------------------
// I4: Unique domain tags
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_field_tags_are_unique() {
    let _tags: &[&[u8]] = &[
        b"max_steps",
        b"max_slots",
        b"max_constants",
        b"max_accessors",
        b"max_expressions",
        b"max_expr_stack",
        b"max_step_budget_per_tick",
        b"max_transitions_per_tick",
        b"max_input_bytes",
        b"max_output_bytes",
        b"max_blob_bytes",
        b"max_ipc_payload_bytes",
        b"max_retry_attempts",
        b"max_fanout",
        b"max_collect_items",
        b"max_queue_depth",
        b"max_journal_batch_bytes",
        b"allows_secret_results",
    ];

    // All 17 field tags (plus header "resource_contract") must be unique
    let all_tags: &[&[u8]] = &[
        b"resource_contract",
        b"max_steps",
        b"max_slots",
        b"max_constants",
        b"max_accessors",
        b"max_expressions",
        b"max_expr_stack",
        b"max_step_budget_per_tick",
        b"max_transitions_per_tick",
        b"max_input_bytes",
        b"max_output_bytes",
        b"max_blob_bytes",
        b"max_ipc_payload_bytes",
        b"max_retry_attempts",
        b"max_fanout",
        b"max_collect_items",
        b"max_queue_depth",
        b"max_journal_batch_bytes",
        b"allows_secret_results",
    ];

    for (i, a) in all_tags.iter().enumerate() {
        for (j, b) in all_tags.iter().enumerate() {
            if i != j {
                assert_ne!(
                    a, b,
                    "Field tags at positions {} and {} must be unique",
                    i, j
                );
            }
        }
    }
}

// ---------------------------------------------------------------------------
// I5: Encoding injectivity
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_is_injective_for_distinct_contracts() {
    let contract_a = ResourceContract::DEFAULT;
    let mut contract_b = ResourceContract::DEFAULT;
    contract_b.max_steps = contract_b.max_steps.saturating_add(1);
    let enc_a = encode_contract_bytes(&contract_a);
    let enc_b = encode_contract_bytes(&contract_b);
    assert_ne!(
        enc_a, enc_b,
        "Contracts differing in max_steps must produce different encodings"
    );
}

#[test]
fn encode_contract_bytes_differs_when_allows_secret_results_toggled() {
    let mut contract_true = ResourceContract::DEFAULT;
    contract_true.allows_secret_results = SecretResultPolicy::Allow;
    let mut contract_false = ResourceContract::DEFAULT;
    contract_false.allows_secret_results = SecretResultPolicy::Deny;
    let enc_true = encode_contract_bytes(&contract_true);
    let enc_false = encode_contract_bytes(&contract_false);
    assert_ne!(
        enc_true, enc_false,
        "Contracts differing only in allows_secret_results must differ in encoding"
    );
}

#[test]
fn secret_result_policy_serde_matches_legacy_bool_bytes() {
    let allow_bytes = postcard::to_allocvec(&SecretResultPolicy::Allow)
        .expect("postcard encode of Allow must succeed");
    let true_bytes = postcard::to_allocvec(&true).expect("postcard encode of true must succeed");
    assert_eq!(
        allow_bytes, true_bytes,
        "Allow must serialize exactly as legacy true"
    );
    let deny_bytes = postcard::to_allocvec(&SecretResultPolicy::Deny)
        .expect("postcard encode of Deny must succeed");
    let false_bytes = postcard::to_allocvec(&false).expect("postcard encode of false must succeed");
    assert_eq!(
        deny_bytes, false_bytes,
        "Deny must serialize exactly as legacy false"
    );
    let decoded: SecretResultPolicy =
        postcard::from_bytes(&allow_bytes).expect("postcard decode of Allow bytes must succeed");
    assert_eq!(decoded, SecretResultPolicy::Allow);
    let decoded: SecretResultPolicy =
        postcard::from_bytes(&deny_bytes).expect("postcard decode of Deny bytes must succeed");
    assert_eq!(decoded, SecretResultPolicy::Deny);
}

#[test]
fn encode_contract_bytes_differs_when_two_fields_change() {
    let contract_a = ResourceContract::DEFAULT;
    let mut contract_b = ResourceContract::DEFAULT;
    contract_b.max_steps = 1;
    contract_b.max_slots = 1;
    let enc_a = encode_contract_bytes(&contract_a);
    let enc_b = encode_contract_bytes(&contract_b);
    assert_ne!(
        enc_a, enc_b,
        "Contracts differing in two fields must produce different encodings"
    );
}

// ---------------------------------------------------------------------------
// I6: No panic on extreme values
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_does_not_panic_for_extreme_contract_values() {
    // All zeros
    let mut all_zero = ResourceContract::DEFAULT;
    all_zero.max_steps = 0;
    all_zero.max_slots = 0;
    all_zero.max_constants = 0;
    all_zero.max_accessors = 0;
    all_zero.max_expressions = 0;
    all_zero.max_expr_stack = 0;
    all_zero.max_step_budget_per_tick = 0;
    all_zero.max_transitions_per_tick = 0;
    all_zero.max_input_bytes = 0;
    all_zero.max_output_bytes = 0;
    all_zero.max_blob_bytes = 0;
    all_zero.max_ipc_payload_bytes = 0;
    all_zero.max_retry_attempts = 0;
    all_zero.max_fanout = 0;
    all_zero.max_collect_items = 0;
    all_zero.max_queue_depth = 0;
    all_zero.max_journal_batch_bytes = 0;
    all_zero.allows_secret_results = SecretResultPolicy::Deny;
    let _bytes_all_zero = encode_contract_bytes(&all_zero);

    // All max values
    let mut all_max = ResourceContract::DEFAULT;
    all_max.max_steps = u16::MAX;
    all_max.max_slots = u16::MAX;
    all_max.max_constants = u16::MAX;
    all_max.max_accessors = u16::MAX;
    all_max.max_expressions = u16::MAX;
    all_max.max_expr_stack = u8::MAX;
    all_max.max_step_budget_per_tick = u64::MAX;
    all_max.max_transitions_per_tick = u64::MAX;
    all_max.max_input_bytes = u32::MAX;
    all_max.max_output_bytes = u32::MAX;
    all_max.max_blob_bytes = u64::MAX;
    all_max.max_ipc_payload_bytes = u32::MAX;
    all_max.max_retry_attempts = u16::MAX;
    all_max.max_fanout = u16::MAX;
    all_max.max_collect_items = u32::MAX;
    all_max.max_queue_depth = u32::MAX;
    all_max.max_journal_batch_bytes = u32::MAX;
    all_max.allows_secret_results = SecretResultPolicy::Allow;
    let _bytes_all_max = encode_contract_bytes(&all_max);

    // DEFAULT contract must always work
    let _bytes_default = encode_contract_bytes(&ResourceContract::DEFAULT);
}

#[test]
fn encode_contract_bytes_output_is_not_empty() {
    let contract = ResourceContract::DEFAULT;
    let bytes = encode_contract_bytes(&contract);
    assert!(
        !bytes.is_empty(),
        "encoded contract bytes must not be empty"
    );
    // The encoding must be at least the header + all tags
    assert!(
        bytes.len() > 50,
        "encoded contract must contain meaningful data, got {} bytes",
        bytes.len()
    );
}

// ---------------------------------------------------------------------------
// Additional: encoding stability and prefix uniqueness
// ---------------------------------------------------------------------------

#[test]
fn encode_contract_bytes_no_tag_is_prefix_of_another_tag() {
    // Domain tags: "max_steps" must not be a prefix of "max_step_budget_per_tick" etc.
    let tags: &[&str] = &[
        "max_steps",
        "max_slots",
        "max_constants",
        "max_accessors",
        "max_expressions",
        "max_expr_stack",
        "max_step_budget_per_tick",
        "max_transitions_per_tick",
        "max_input_bytes",
        "max_output_bytes",
        "max_blob_bytes",
        "max_ipc_payload_bytes",
        "max_retry_attempts",
        "max_fanout",
        "max_collect_items",
        "max_queue_depth",
        "max_journal_batch_bytes",
        "allows_secret_results",
    ];

    for i in 0..tags.len() {
        for j in 0..tags.len() {
            if i != j {
                assert!(
                    !tags[i].starts_with(tags[j]),
                    "Tag '{}' must not be a prefix of '{}' (collision risk)",
                    tags[j],
                    tags[i]
                );
            }
        }
    }
}
