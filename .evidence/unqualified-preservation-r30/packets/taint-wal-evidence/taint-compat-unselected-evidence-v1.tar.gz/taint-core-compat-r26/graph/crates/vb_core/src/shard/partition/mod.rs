//! Shard Partition Math — Verification Model Types
//!
//! **TRUST BOUNDARY**: These types are verification models. They are NOT production
//! types. The production implementation (to be created in State 6/7) must match the
//! mathematical contracts validated by the proof harnesses against this model.
//!
//! # Model Commitments
//! - All arithmetic uses checked operations; no panics
//! - KeyRange invariant: start <= end (enforced by constructor)
//! - ShardCount invariant: 1 <= inner <= MAX_SHARD_COUNT
//! - PartitionPlan invariants: contiguous, disjoint, exhaustive ranges
//! - No unsafe, no unwrap, no expect, no panic

#![forbid(unsafe_code)]

// ============================================================================
// Constants
// ============================================================================

/// Maximum number of shards for a single-server deployment.
pub const MAX_SHARD_COUNT: usize = 65_536;

/// Maximum shard count for Kani bounded verification (TB-005).
pub const KANI_MAX_SHARD_COUNT: usize = 32;

fn usize_to_u64(value: usize) -> u64 {
    u64::try_from(value).map_or(u64::MAX, core::convert::identity)
}

// ============================================================================
// PartitionError
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PartitionError {
    ZeroShardCount,
    ShardCountExceedsMax { requested: u64, maximum: u64 },
    InvalidKeyRange { start: u64, end: u64 },
    ArithmeticOverflow { shard_index: u64 },
}

impl core::fmt::Display for PartitionError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::ZeroShardCount => write!(f, "shard count must be at least 1"),
            Self::ShardCountExceedsMax { requested, maximum } => {
                write!(f, "shard count {requested} exceeds maximum {maximum}")
            }
            Self::InvalidKeyRange { start, end } => {
                write!(f, "invalid key range: start {start} > end {end}")
            }
            Self::ArithmeticOverflow { shard_index } => {
                write!(f, "arithmetic overflow at shard {shard_index}")
            }
        }
    }
}

// ============================================================================
// KeyRange
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct KeyRange {
    start: u64,
    end: u64,
}

impl KeyRange {
    pub fn new(start: u64, end: u64) -> Result<Self, PartitionError> {
        if start > end {
            return Err(PartitionError::InvalidKeyRange { start, end });
        }
        Ok(Self { start, end })
    }

    #[must_use]
    pub const fn from_single_key(key: u64) -> Self {
        Self {
            start: key,
            end: key,
        }
    }
    #[must_use]
    pub const fn full_keyspace() -> Self {
        Self {
            start: 0,
            end: u64::MAX,
        }
    }
    #[must_use]
    pub const fn start(self) -> u64 {
        self.start
    }
    #[must_use]
    pub const fn end(self) -> u64 {
        self.end
    }
    #[must_use]
    pub const fn contains(self, key: u64) -> bool {
        self.start <= key && key <= self.end
    }
    #[must_use]
    pub const fn size(self) -> u64 {
        self.end.wrapping_sub(self.start)
    }
    #[must_use]
    pub fn count(self) -> Option<u64> {
        self.end.checked_sub(self.start)?.checked_add(1)
    }
    #[must_use]
    pub const fn is_singleton(self) -> bool {
        self.start == self.end
    }

    #[must_use]
    pub fn intersection(self, other: Self) -> Option<Self> {
        let start = if self.start > other.start {
            self.start
        } else {
            other.start
        };
        let end = if self.end < other.end {
            self.end
        } else {
            other.end
        };
        if start <= end {
            Some(Self { start, end })
        } else {
            None
        }
    }

    #[must_use]
    pub fn is_disjoint(self, other: Self) -> bool {
        self.intersection(other).is_none()
    }

    #[must_use]
    pub fn is_adjacent_to(self, other: Self) -> bool {
        if let Some(next) = self.end.checked_add(1)
            && next == other.start
        {
            return true;
        }
        if let Some(next) = other.end.checked_add(1)
            && next == self.start
        {
            return true;
        }
        false
    }
}

// ============================================================================
// ShardCount
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ShardCount(pub usize);

impl ShardCount {
    pub fn try_new(raw: usize) -> Result<Self, PartitionError> {
        if raw == 0 {
            return Err(PartitionError::ZeroShardCount);
        }
        if raw > MAX_SHARD_COUNT {
            return Err(PartitionError::ShardCountExceedsMax {
                requested: usize_to_u64(raw),
                maximum: usize_to_u64(MAX_SHARD_COUNT),
            });
        }
        Ok(Self(raw))
    }

    #[must_use]
    pub const fn get(self) -> usize {
        self.0
    }
    #[must_use]
    pub fn as_u64(self) -> u64 {
        usize_to_u64(self.0)
    }
    #[must_use]
    pub const fn is_single_shard(self) -> bool {
        self.0 == 1
    }
}

impl Default for ShardCount {
    fn default() -> Self {
        Self(1)
    }
}

mod plan;

pub use plan::{PartitionConfig, PartitionPlan};

// ============================================================================
// Kani Arbitrary (GOD RULE #1)
// ============================================================================

#[cfg(kani)]
mod kani_arbitrary {
    use super::*;

    impl kani::Arbitrary for KeyRange {
        fn any() -> Self {
            let start: u64 = kani::any();
            let end: u64 = kani::any();
            kani::assume(start <= end);
            Self { start, end }
        }
    }

    impl kani::Arbitrary for ShardCount {
        fn any() -> Self {
            let raw: usize = kani::any();
            kani::assume(raw >= 1 && raw <= KANI_MAX_SHARD_COUNT);
            Self(raw)
        }
    }

    impl kani::Arbitrary for PartitionConfig {
        fn any() -> Self {
            let shard_count: ShardCount = kani::any();
            let keyspace: KeyRange = kani::any();
            Self {
                shard_count,
                keyspace,
            }
        }
    }
}

// ============================================================================
// Proptest strategies
// ============================================================================

#[cfg(test)]
#[allow(unused_imports)]
pub mod proptest_strategies {
    use super::*;
    use proptest::prelude::*;
    use proptest::strategy::Strategy;

    pub fn any_u64() -> impl Strategy<Value = u64> {
        proptest::num::u64::ANY
    }

    pub fn key_range_strategy() -> impl Strategy<Value = KeyRange> {
        (any_u64(), any_u64()).prop_map(|(a, b)| {
            let (start, end) = if a <= b { (a, b) } else { (b, a) };
            match KeyRange::new(start, end) {
                Ok(kr) => kr,
                Err(_) => KeyRange::full_keyspace(),
            }
        })
    }

    pub fn shard_count_strategy() -> impl Strategy<Value = ShardCount> {
        (1usize..=MAX_SHARD_COUNT).prop_map(ShardCount)
    }

    pub fn partition_config_strategy() -> impl Strategy<Value = PartitionConfig> {
        (shard_count_strategy(), key_range_strategy())
            .prop_map(|(sc, kr)| PartitionConfig::new(sc, kr))
    }
}

// ============================================================================
// Kani harnesses
// ============================================================================

#[cfg(kani)]
#[path = "../../verification/kani/partition_kani_key_range_properties.rs"]
pub mod kani_key_range_properties;

#[cfg(kani)]
#[path = "../../verification/kani/partition_kani_partition_plan_safety.rs"]
pub mod kani_partition_plan_safety;
