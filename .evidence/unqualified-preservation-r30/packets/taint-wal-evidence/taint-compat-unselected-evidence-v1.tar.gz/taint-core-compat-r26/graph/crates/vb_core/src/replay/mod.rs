#![forbid(unsafe_code)]
//! Deterministic replay engine for reconstructing slot state from journal evidence.
//!
//! Given a compiled workflow and step evidence, re-executes deterministic steps
//! to reconstruct slot state. Non-deterministic nodes (Action, Ask) cause
//! suspension with the blocking step index.

use crate::errors::EngineError;
use crate::frame::RunFrame;
use crate::ids::{ExprIdx, RunId, SlotIdx, StepIdx};
use crate::value::{SlotValue, Taint};
use crate::value_store::ValueStore;
use crate::workflow::CompiledWorkflow;

pub mod choose;
pub mod expr_stack;
pub mod helpers;
pub mod ops;
pub mod step;

pub use expr_stack::ReplayExprStack;
pub use step::{ReplayAction, SuspensionKind};

// ---------------------------------------------------------------------------
// Error types
// ---------------------------------------------------------------------------

/// Failures that can occur during deterministic replay.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum ReplayError {
    /// The target step does not exist in the compiled workflow.
    StepNotFound {
        /// Requested step index.
        step: StepIdx,
    },
    /// Replay encountered a non-deterministic node that cannot be replayed.
    NonDeterministicStep {
        /// Step index of the blocking node.
        step: StepIdx,
        /// Typed non-deterministic suspension kind.
        kind: SuspensionKind,
    },
    /// A required slot was not populated before being read.
    SlotNotAvailable {
        /// Slot that was missing.
        slot: SlotIdx,
    },
    /// Expression evaluation failed during replay.
    ExpressionEvalFailed {
        /// Step where evaluation failed.
        step: StepIdx,
    },
    /// An internal error occurred during replay.
    Internal {
        /// Description of the internal failure.
        reason: &'static str,
    },
    /// A deterministic iteration exceeded its checked resource limit.
    IterationLimitExceeded {
        /// Resource whose configured bound was exceeded.
        resource: &'static str,
    },
}

// ---------------------------------------------------------------------------
// Error conversion
// ---------------------------------------------------------------------------

/// Replay-wide mapping from `EngineError` to `ReplayError`.
///
/// Routes evidence-bearing engine failures (slot bounds, uninitialized slots,
/// invalid program counter) to typed `ReplayError` variants that preserve the
/// offending slot/step index. Reserves `ReplayError::Internal` for genuinely
/// unexpected failures so the variant retains its invariant: "this should
/// never happen in a correct journal".
///
/// CE-004: invalid jump/branch targets produced by `run.set_pc` now surface
/// as `ReplayError::StepNotFound { step }` instead of collapsing to
/// `Internal`, preserving the offending step index.
fn engine_to_replay_err(e: EngineError) -> ReplayError {
    match e {
        EngineError::InvalidProgramCounter { step } => ReplayError::StepNotFound { step },
        EngineError::SlotOutOfBounds { slot } => ReplayError::SlotNotAvailable { slot },
        EngineError::SlotUninitialized { slot } => ReplayError::SlotNotAvailable { slot },
        EngineError::IterationLimitExceeded { resource } => {
            ReplayError::IterationLimitExceeded { resource }
        }
        _ => ReplayError::Internal {
            reason: "unexpected engine error during replay",
        },
    }
}

// ---------------------------------------------------------------------------
// ReplayEngine
// ---------------------------------------------------------------------------

/// Deterministic replay engine.
///
/// Holds a reference to a compiled workflow and re-executes deterministic nodes
/// in order from the entry step to a target step, reconstructing slot state in
/// the provided `ValueStore` and `RunFrame`.
pub struct ReplayEngine<'a> {
    plan: &'a CompiledWorkflow,
}

impl<'a> ReplayEngine<'a> {
    /// Creates a new replay engine for the given compiled workflow.
    pub fn new(plan: &'a CompiledWorkflow) -> Self {
        Self { plan }
    }

    /// Replays deterministic steps from the entry point up to `target_step`.
    ///
    /// Returns `Ok(target_step)` if the target was reached.
    /// Returns `Ok(suspension_point)` if a non-deterministic node blocked progress
    /// before the target was reached.
    ///
    /// # Bounded execution
    ///
    /// The loop is bounded by `MAX_STEP_BUDGET` to prevent unbounded iteration
    /// from back-edges (Jump nodes) in a corrupted or adversarial workflow.
    pub fn replay_up_to(
        &self,
        target_step: StepIdx,
        store: &mut ValueStore,
    ) -> Result<StepIdx, ReplayError> {
        self.replay_frame_up_to(target_step, store)
            .map(|frame| frame.pc())
    }

    /// Replays deterministic steps from entry until `target_step` is reached.
    pub fn replay_frame_up_to(
        &self,
        target_step: StepIdx,
        store: &mut ValueStore,
    ) -> Result<RunFrame, ReplayError> {
        self.ensure_step_exists(target_step)?;
        let run = self.new_replay_frame()?;
        self.replay_until(target_step, store, run, ReplayTargetMode::Before)
    }

    /// Replays deterministic steps through and including `target_step`.
    pub fn replay_frame_through(
        &self,
        target_step: StepIdx,
        store: &mut ValueStore,
    ) -> Result<RunFrame, ReplayError> {
        self.ensure_step_exists(target_step)?;
        let run = self.new_replay_frame()?;
        self.replay_until(target_step, store, run, ReplayTargetMode::Through)
    }

    fn ensure_step_exists(&self, step: StepIdx) -> Result<(), ReplayError> {
        self.plan
            .node(step)
            .map(|_| ())
            .ok_or(ReplayError::StepNotFound { step })
    }

    fn new_replay_frame(&self) -> Result<RunFrame, ReplayError> {
        RunFrame::new(
            RunId::new(0),
            self.plan.entry(),
            self.plan.node_count(),
            self.plan.slot_count(),
        )
        .map_err(engine_to_replay_err)
    }

    fn replay_until(
        &self,
        target_step: StepIdx,
        store: &mut ValueStore,
        run: RunFrame,
        mode: ReplayTargetMode,
    ) -> Result<RunFrame, ReplayError> {
        let collect_states = step::ReplayCollectStates::new();
        std::iter::successors(Some(self.plan.entry()), |step| Some(*step))
            .take(replay_step_budget_len())
            .try_fold(
                (run, self.plan.entry(), collect_states),
                |(mut frame, current, mut states), _| {
                    if mode == ReplayTargetMode::Before && current == target_step {
                        return Err(ReplayFoldStop::Done(frame));
                    }
                    let next = self.replay_one(current, &mut frame, store, &mut states)?;
                    if mode == ReplayTargetMode::Through && current == target_step {
                        Err(ReplayFoldStop::Done(frame))
                    } else {
                        match next {
                            Some(step) => Ok((frame, step, states)),
                            None => Err(ReplayFoldStop::Done(frame)),
                        }
                    }
                },
            )
            .map_or_else(ReplayFoldStop::into_result, |_| {
                Err(ReplayError::Internal {
                    reason: "replay step budget exhausted",
                })
            })
    }

    fn replay_one(
        &self,
        current: StepIdx,
        run: &mut RunFrame,
        store: &mut ValueStore,
        collect_states: &mut step::ReplayCollectStates,
    ) -> Result<Option<StepIdx>, ReplayFoldStop> {
        let node =
            self.plan
                .node(current)
                .ok_or(ReplayFoldStop::Error(ReplayError::StepNotFound {
                    step: current,
                }))?;
        match step::replay_step_with_collect(node, run, store, self.plan, collect_states) {
            Ok(step::ReplayAction::Continue(next)) => Ok(Some(next)),
            Ok(step::ReplayAction::Finished) => Ok(None),
            Ok(step::ReplayAction::Suspended { step, kind }) => {
                Err(ReplayFoldStop::Error(ReplayError::NonDeterministicStep {
                    step,
                    kind,
                }))
            }
            Err(error) => Err(ReplayFoldStop::Error(error)),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReplayTargetMode {
    Before,
    Through,
}

enum ReplayFoldStop {
    Done(RunFrame),
    Error(ReplayError),
}

impl ReplayFoldStop {
    fn into_result(self) -> Result<RunFrame, ReplayError> {
        match self {
            Self::Done(frame) => Ok(frame),
            Self::Error(error) => Err(error),
        }
    }
}

fn replay_step_budget_len() -> usize {
    match usize::try_from(crate::limits::MAX_STEP_BUDGET) {
        Ok(value) => value,
        Err(_) => usize::MAX,
    }
}

pub(crate) fn eval_expr_for_replay(
    plan: &CompiledWorkflow,
    run: &RunFrame,
    store: &mut ValueStore,
    expr: ExprIdx,
) -> Result<(SlotValue, Taint), ReplayError> {
    if plan.expression(expr).is_none() {
        return Err(ReplayError::Internal {
            reason: "expression out of bounds",
        });
    }
    crate::engine::eval_expr_with_store(plan, run, store, expr).map_err(|error| {
        if crate::engine::is_ordinary_expression_failure(&error) {
            ReplayError::ExpressionEvalFailed { step: run.pc() }
        } else {
            engine_to_replay_err(error)
        }
    })
}

// Re-export for tests and re-exports from submodules
pub use ops::pop_i64_pair;
pub use ops::pop_pair;
pub use step::replay_step;

#[cfg(test)]
#[path = "tests.rs"]
mod tests;

#[cfg(any(kani, test))]
#[path = "../verification/kani/replay_kani_harnesses.rs"]
mod kani_harnesses;
