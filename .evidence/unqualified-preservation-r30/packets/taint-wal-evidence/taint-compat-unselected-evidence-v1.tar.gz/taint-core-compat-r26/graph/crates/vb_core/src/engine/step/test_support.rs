use crate::action::{
    ActionContract, ActionFailure, ActionFailureCode, ActionName, ActionOutputReady, ActionTicket,
    Idempotency, RetryPolicy, RetrySafety, SideEffect, compute_action_idempotency_key,
};
use crate::frame::RunFrame;
use crate::ids::{ActionId, RunId, SeqNo, SlotIdx, StepIdx, WorkflowDigest};
use crate::value::ConstValue;
use crate::value::{SlotValue, Taint};
use crate::workflow::{
    CompiledInputConstraint, CompiledInputSlot, CompiledNode, CompiledNodeKind, CompiledWorkflow,
    ErrorRouting, InputSlotKind, NodeOutput, NodeRouting, ResourceContract, WorkflowParts, node,
};

pub(super) fn ensure_equal<T>(actual: T, expected: T) -> Result<(), String>
where
    T: core::fmt::Debug + PartialEq,
{
    if actual == expected {
        Ok(())
    } else {
        Err(format!("expected {expected:?}, found {actual:?}"))
    }
}

pub(super) fn test_frame(workflow: &CompiledWorkflow) -> Result<RunFrame, String> {
    RunFrame::new(
        RunId::new(1),
        workflow.entry(),
        workflow.node_count(),
        workflow.slot_count(),
    )
    .map_err(|e| e.to_string())
}

pub(super) fn external_input() -> Box<[CompiledInputSlot]> {
    Box::new([CompiledInputSlot {
        slot: SlotIdx::new(0),
        kind: InputSlotKind::Any,
        constraint: CompiledInputConstraint::required(),
    }])
}

pub(super) fn nop_then_finish_workflow() -> Result<CompiledWorkflow, String> {
    CompiledWorkflow::try_from_parts(WorkflowParts {
        semantic_source_identity: None,
        source_metadata: None,
        input_slots: external_input(),
        name: Box::<str>::from("nop_finish"),
        digest: WorkflowDigest::from_bytes([0x11; 32]),
        nodes: vec![
            node(
                StepIdx::new(0),
                CompiledNodeKind::Nop,
                None,
                Some(StepIdx::new(1)),
            ),
            node(
                StepIdx::new(1),
                CompiledNodeKind::Finish {
                    result: SlotIdx::new(0),
                },
                None,
                None,
            ),
        ]
        .into_boxed_slice(),
        expressions: Box::new([]),
        accessors: Box::new([]),
        constants: vec![ConstValue::I64(42)].into_boxed_slice(),
        slot_count: 1,
        symbols_count: 0,
        entry: StepIdx::new(0),
        resource_contract: ResourceContract::DEFAULT,
        step_names: Box::new([]),
    })
    .map_err(|e| e.to_string())
}

pub(super) fn action_ticket(run: u64, step: u16, action: u16, capacity: u16) -> ActionTicket {
    let run = RunId::new(run);
    let seq = SeqNo::new(1);
    let action = ActionId::new(action);
    ActionTicket {
        run,
        step: StepIdx::new(step),
        seq,
        action,
        run_attempt: 1,
        attempt: 1,
        idempotency_key: compute_action_idempotency_key(run, 1, seq, action),
        capacity,
        fencing_token: 0,
    }
}

pub(super) fn action_contract(action: u16, max_output_bytes: u32) -> ActionContract {
    ActionContract {
        id: ActionId::new(action),
        name: ActionName::from_static_infallible("test-action"),
        input_slot_count: 1,
        output_slot_count: 1,
        max_input_bytes: 128,
        max_output_bytes,
        timeout_ms: 1_000,
        idempotency: Idempotency::DeterministicPure,
        side_effect: SideEffect::None,
        retry_safety: RetrySafety::Safe,
        required_capabilities: Box::new([]),
    }
}

pub(super) fn payload_len(payload: &[u8]) -> Result<u32, String> {
    u32::try_from(payload.len()).map_err(|_| String::from("payload length exceeds u32"))
}

pub(super) fn ready_output(
    output_slot: SlotIdx,
    value: SlotValue,
    taint: Taint,
    payload: &[u8],
) -> Result<ActionOutputReady, String> {
    Ok(ActionOutputReady {
        output_slot,
        value,
        taint,
        encoded_len: payload_len(payload)?,
    })
}

pub(super) fn failure_payload(
    code: ActionFailureCode,
    retry_policy: RetryPolicy,
    taint: Taint,
    payload: &[u8],
) -> Result<ActionFailure, String> {
    Ok(ActionFailure {
        code,
        retry_policy,
        taint,
        detail: None,
        encoded_len: payload_len(payload)?,
    })
}

pub(super) fn single_do_workflow(
    name: &str,
    digest: [u8; 32],
    slot_count: u16,
) -> Result<CompiledWorkflow, String> {
    CompiledWorkflow::try_from_parts(WorkflowParts {
        semantic_source_identity: None,
        source_metadata: None,
        input_slots: external_input(),
        name: Box::<str>::from(name),
        digest: WorkflowDigest::from_bytes(digest),
        nodes: vec![do_node(StepIdx::new(0), ActionId::new(1), None, None, None)]
            .into_boxed_slice(),
        expressions: Box::new([]),
        accessors: Box::new([]),
        constants: Box::new([]),
        slot_count,
        symbols_count: 0,
        entry: StepIdx::new(0),
        resource_contract: ResourceContract::DEFAULT,
        step_names: Box::new([]),
    })
    .map_err(|e| e.to_string())
}

pub(super) fn do_then_finish_workflow(
    name: &str,
    digest: [u8; 32],
    slot_count: u16,
) -> Result<CompiledWorkflow, String> {
    CompiledWorkflow::try_from_parts(WorkflowParts {
        semantic_source_identity: None,
        source_metadata: None,
        input_slots: external_input(),
        name: Box::<str>::from(name),
        digest: WorkflowDigest::from_bytes(digest),
        nodes: vec![
            do_node(
                StepIdx::new(0),
                ActionId::new(1),
                Some(StepIdx::new(1)),
                None,
                None,
            ),
            finish_node(StepIdx::new(1)),
        ]
        .into_boxed_slice(),
        expressions: Box::new([]),
        accessors: Box::new([]),
        constants: Box::new([]),
        slot_count,
        symbols_count: 0,
        entry: StepIdx::new(0),
        resource_contract: ResourceContract::DEFAULT,
        step_names: Box::new([]),
    })
    .map_err(|e| e.to_string())
}

pub(super) fn do_with_error_handler_workflow(
    name: &str,
    digest: [u8; 32],
) -> Result<CompiledWorkflow, String> {
    CompiledWorkflow::try_from_parts(WorkflowParts {
        semantic_source_identity: None,
        source_metadata: None,
        input_slots: external_input(),
        name: Box::<str>::from(name),
        digest: WorkflowDigest::from_bytes(digest),
        nodes: vec![
            do_node(
                StepIdx::new(0),
                ActionId::new(9),
                Some(StepIdx::new(1)),
                Some(StepIdx::new(2)),
                Some(SlotIdx::new(1)),
            ),
            finish_node(StepIdx::new(1)),
            finish_node(StepIdx::new(2)),
        ]
        .into_boxed_slice(),
        expressions: Box::new([]),
        accessors: Box::new([]),
        constants: Box::new([]),
        slot_count: 2,
        symbols_count: 0,
        entry: StepIdx::new(0),
        resource_contract: ResourceContract::DEFAULT,
        step_names: Box::new([]),
    })
    .map_err(|e| e.to_string())
}

fn do_node(
    id: StepIdx,
    action: ActionId,
    next: Option<StepIdx>,
    on_error: Option<StepIdx>,
    error_slot: Option<SlotIdx>,
) -> CompiledNode {
    CompiledNode {
        retry: None,
        id,
        output: NodeOutput::Slot(SlotIdx::new(0)),
        routing: NodeRouting {
            next: next.into(),
            error: match on_error {
                Some(handler) => ErrorRouting::Handler {
                    handler,
                    error_slot,
                },
                None => ErrorRouting::None,
            },
        },
        kind: CompiledNodeKind::Do {
            action,
            input: SlotIdx::new(0),
        },
    }
}

pub(super) fn finish_node(id: StepIdx) -> CompiledNode {
    node(
        id,
        CompiledNodeKind::Finish {
            result: SlotIdx::new(0),
        },
        None,
        None,
    )
}
