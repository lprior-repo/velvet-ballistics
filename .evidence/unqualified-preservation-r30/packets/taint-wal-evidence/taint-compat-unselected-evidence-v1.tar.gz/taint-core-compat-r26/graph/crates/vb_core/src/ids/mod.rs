#![forbid(unsafe_code)]

//! Compact numeric identifiers used by the hot runtime.
//!
//! This module exposes the numeric identifier types used by the runtime:
//!
//! - Generic numeric IDs produced by the `numeric_id!` macro and its
//!   `checked_index!` extension (WorkflowId, StepIdx, SlotIdx, ExprIdx,
//!   ActionId, AccessorIdx, ConstIdx, SymbolId, ListId, ObjectId, BlobId,
//!   RunId, EventSeq, SeqNo, TenantId).
//! - Hand-written domain identifiers (BranchIdx, FanoutLimit, MaxAttempts,
//!   RetryCount, BranchCount) and the `WorkflowDigest` content hash.
//! - Kani harnesses for ID boundary and proof obligations
//!   (`kani_id_bounds`, `kani_id_arbitrary`, `kani_shard_index_bounds`).
//!
//! The hand-written domain types live in `parts/chunk_001_custom_types.rs`
//! and are `include!`-d into this module to keep the public surface and
//! macro/derived-type definitions in a single, scannable file.

use core::num::ParseIntError;
use core::str::FromStr;
use serde::{Deserialize, Serialize};
#[cfg(verus_keep_ghost)]
use vstd::prelude::*;

macro_rules! numeric_id {
    ($name:ident, $inner:ty, $accessor:ident) => { numeric_id!($name, $inner, $accessor, value, self); };
    ($name:ident, $inner:ty, $accessor:ident, $value:ident, $this:ident $(, $constructor_contract:meta, $accessor_contract:meta)?) => {
        #[doc = concat!(stringify!($name), " numeric identifier.")]
        #[derive(
            Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize,
        )]
        #[repr(transparent)]
        #[cfg_attr(verus_keep_ghost, verifier::verify)]
        #[cfg_attr(verus_keep_ghost, verifier::external_derive(erialize))]
        pub struct $name($inner);

        impl $name {
            /// Creates an identifier from a validated integer.
            #[must_use]
            $(#[$constructor_contract])?
            pub const fn new($value: $inner) -> Self {
                Self($value)
            }

            /// Returns the raw identifier value.
            #[must_use]
            $(#[$accessor_contract])?
            pub const fn $accessor($this) -> $inner {
                $this.0
            }
        }

        impl FromStr for $name {
            type Err = ParseIntError;

            fn from_str(input: &str) -> Result<Self, Self::Err> {
                input.parse::<$inner>().map(Self)
            }
        }
    };
}

macro_rules! checked_index {
    ($name:ident) => { checked_index!($name, self); };
    ($name:ident, $this:ident $(, $index_contract:meta)?) => {
        impl $name {
            /// Returns the index as `usize` for checked slice access.
            #[must_use]
            $(#[$index_contract])?
            pub fn as_usize($this) -> usize {
                usize::from($this.0)
            }
        }
    };
}

numeric_id!(WorkflowId, u32, get);
numeric_id!(
    StepIdx, u16, get, value, self,
    cfg_attr(verus_keep_ghost, verus_spec(returns Self::from_raw_spec(value))),
    cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == self.raw_spec()))
);
numeric_id!(SlotIdx, u16, get);
numeric_id!(ExprIdx, u16, get);
numeric_id!(ActionId, u16, get);
numeric_id!(AccessorIdx, u16, get);
numeric_id!(ConstIdx, u16, get);
numeric_id!(SymbolId, u32, get);
numeric_id!(ListId, u32, get);
numeric_id!(ObjectId, u32, get);
numeric_id!(BlobId, u64, get);
numeric_id!(RunId, u64, get);
numeric_id!(EventSeq, u64, get);
numeric_id!(SeqNo, u64, get);
numeric_id!(TenantId, u64, get);

checked_index!(
    StepIdx, self,
    cfg_attr(verus_keep_ghost, verus_spec(result => ensures result as int == self.raw_spec() as int))
);
checked_index!(SlotIdx);
checked_index!(ExprIdx);
checked_index!(AccessorIdx);
checked_index!(ConstIdx);

#[cfg(verus_keep_ghost)]
vstd::prelude::verus! {
    impl StepIdx {
        pub closed spec fn from_raw_spec(value: u16) -> Self { Self(value) }
        pub closed spec fn raw_spec(self) -> u16 { self.0 }
        pub proof fn raw_roundtrip(value: u16)
            ensures Self::from_raw_spec(value).raw_spec() == value
        {}
    }
}

include!("parts/chunk_001_custom_types.rs");

#[cfg(test)]
#[path = "tests_and_verification.rs"]
mod tests_and_verification;

#[cfg(kani)]
#[path = "../verification/kani/ids_kani_id_bounds.rs"]
pub mod kani_id_bounds;

#[cfg(kani)]
#[path = "../verification/kani/ids_kani_id_arbitrary.rs"]
pub mod kani_id_arbitrary;

#[cfg(kani)]
#[path = "../verification/kani/ids_kani_shard_index_bounds.rs"]
pub mod kani_shard_index_bounds;
