#[cfg(verus_keep_ghost)]
include!("walk_weight.rs");
#[cfg(verus_keep_ghost)]
vstd::prelude::verus! {

spec fn walk_next_seen(len: nat, index: usize, stop: usize, visited: Set<usize>) -> Set<usize> {
    if index >= len || index == stop {
        visited
    } else {
        visited.insert(index)
    }
}

spec fn walk_next_stack(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
) -> Seq<usize> {
    if can_visit(nodes.len(), index, stop, visited) && index <= 65535 && !is_nested_start(
        keys,
        index,
        outer,
    ) {
        successor_stack(&nodes[index as int], popped)
    } else {
        popped
    }
}

#[verifier::inline]
spec fn walk_potential_does_not_grow(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
) -> bool {
    walk_weight_from(nodes, walk_next_seen(nodes.len(), index, stop, visited), 0) + walk_next_stack(
        nodes,
        keys,
        popped,
        index,
        stop,
        outer,
        visited,
    ).len() <= walk_weight_from(nodes, visited, 0) + popped.len()
}

proof fn walk_step_drops_potential(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
)
    ensures
        walk_potential_does_not_grow(nodes, keys, popped, index, stop, outer, visited),
{
    if can_visit(nodes.len(), index, stop, visited) {
        walk_weight_insert(nodes, visited, index, 0);
        if index <= 65535 && !is_nested_start(keys, index, outer) {
            successor_append(&nodes[index as int], popped);
        }
    } else if index < nodes.len() && index != stop {
        assert(visited.contains(index));
        assert(visited.insert(index) == visited);
    }
}

enum WalkReferenceTransition {
    Found(StepIdx),
    Continue(Seq<usize>, Set<usize>),
}

struct WalkReferenceContext {
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    stop: usize,
    outer: StepIdx,
    stop_on_overflow: bool,
}

#[verifier::inline]
spec fn walk_reference(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    stack: Seq<usize>,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
    fuel: int,
    stop_on_overflow: bool,
) -> Option<StepIdx> {
    let context = WalkReferenceContext { nodes, keys, stop, outer, stop_on_overflow };
    walk_reference_in_context(context, stack, visited, fuel)
}

spec fn walk_reference_in_context(
    context: WalkReferenceContext,
    stack: Seq<usize>,
    visited: Set<usize>,
    fuel: int,
) -> Option<StepIdx>
    decreases fuel,
{
    if fuel <= 0 || stack.len() == 0 {
        None
    } else {
        match walk_reference_step(context, stack.drop_last(), stack.last(), visited) {
            WalkReferenceTransition::Found(step) => Some(step),
            WalkReferenceTransition::Continue(next, seen) => walk_reference_in_context(
                context,
                next,
                seen,
                fuel - 1,
            ),
        }
    }
}

#[verifier::inline]
spec fn walk_reference_step(
    context: WalkReferenceContext,
    popped: Seq<usize>,
    index: usize,
    visited: Set<usize>,
) -> WalkReferenceTransition {
    if !can_visit(context.nodes.len(), index, context.stop, visited) {
        WalkReferenceTransition::Continue(popped, visited)
    } else {
        walk_reference_eligible(context, popped, index, visited.insert(index))
    }
}

#[verifier::inline]
spec fn walk_reference_eligible(
    context: WalkReferenceContext,
    popped: Seq<usize>,
    index: usize,
    marked: Set<usize>,
) -> WalkReferenceTransition {
    if index > 65535 && context.stop_on_overflow {
        WalkReferenceTransition::Found(context.outer)
    } else if index > 65535 {
        WalkReferenceTransition::Continue(popped, marked)
    } else if is_nested_start(context.keys, index, context.outer) {
        WalkReferenceTransition::Found(StepIdx::from_raw_spec(index as u16))
    } else {
        WalkReferenceTransition::Continue(
            successor_stack(&context.nodes[index as int], popped),
            marked,
        )
    }
}

spec fn expected_contains_walk(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    start: usize,
    stop: usize,
    outer: StepIdx,
) -> bool {
    walk_reference(
        nodes,
        keys,
        seq![start],
        stop,
        outer,
        Set::empty(),
        1 + walk_weight_from(nodes, Set::empty(), 0) as int,
        false,
    ).is_some()
}

#[verifier::inline]
spec fn walk_continue_is_allowed(
    len: nat,
    keys: Set<u16>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
    stop_on_overflow: bool,
) -> bool {
    !(can_visit(len, index, stop, visited) && index <= 65535 && is_nested_start(keys, index, outer))
        && !(stop_on_overflow && can_visit(len, index, stop, visited) && index > 65535)
}

#[verifier::inline]
spec fn walk_continues(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
    fuel: int,
    stop_on_overflow: bool,
) -> bool {
    walk_reference(nodes, keys, popped.push(index), stop, outer, visited, fuel, stop_on_overflow)
        == walk_reference(
        nodes,
        keys,
        walk_next_stack(nodes, keys, popped, index, stop, outer, visited),
        stop,
        outer,
        walk_next_seen(nodes.len(), index, stop, visited),
        fuel - 1,
        stop_on_overflow,
    )
}

proof fn walk_skipped_visit_has_no_effect(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
)
    requires
        !can_visit(nodes.len(), index, stop, visited),
    ensures
        walk_next_seen(nodes.len(), index, stop, visited) == visited,
        walk_next_stack(nodes, keys, popped, index, stop, outer, visited) == popped,
{
    if index < nodes.len() && index != stop {
        assert(visited.contains(index));
        assert(visited.insert(index) == visited);
    }
}

proof fn walk_reference_continue_step(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    popped: Seq<usize>,
    index: usize,
    stop: usize,
    outer: StepIdx,
    visited: Set<usize>,
    fuel: int,
    stop_on_overflow: bool,
)
    requires
        fuel > 0,
        walk_continue_is_allowed(nodes.len(), keys, index, stop, outer, visited, stop_on_overflow),
    ensures
        walk_continues(nodes, keys, popped, index, stop, outer, visited, fuel, stop_on_overflow),
{
    reveal(walk_reference_in_context);
    assert(popped.push(index).last() == index);
    assert(popped.push(index).drop_last() == popped);
    if !can_visit(nodes.len(), index, stop, visited) {
        walk_skipped_visit_has_no_effect(nodes, keys, popped, index, stop, outer, visited);
    }
}

spec fn expected_find_walk(
    nodes: Seq<crate::workflow::CompiledNode>,
    keys: Set<u16>,
    start: usize,
    stop: usize,
    outer: StepIdx,
) -> StepIdx {
    match walk_reference(
        nodes,
        keys,
        seq![start],
        stop,
        outer,
        Set::empty(),
        1 + walk_weight_from(nodes, Set::empty(), 0) as int,
        true,
    ) {
        Some(step) => step,
        None => outer,
    }
}

} // verus!
