# Verus Review

**STATUS:** APPROVED for bounded maintenance of the existing trusted resume projection  
**Grade claimed/reviewed:** PASS only; stronger native binding and PRODUCTION_USABLE are not claimed  
**Scope:** BASE ae8ab1a7440cd65e01e52b32b18d5295bd3539e1 to HEAD eb3c2a81cfb615f7d340576b1259383ebcd41fa6; changed resume decision projection and its spec, assumption signature, wrapper and proof controls  
**Verifier evidence reviewed:** Independently ran registered `verus --crate-type=lib verification/verus/vb_runtime_execute_do_spec.rs`, exit0,34 verified/0 errors, no diagnostics; binding and drift scripts exit0  
**Trust scan:** Reviewed complete local closure spec -> extern_runtime_execute_do.rs -> production_inner/execute_do_production.rs. Same-line scan plus full changed hunks shows7 existing verifier::external attributes and7 existing assume_specification entries before and after. No cfg_attr, multiline trust attributes, admit, assume(), axiom, external_body, new trusted function or runtime fork appears.  
**Intactness/safe-change evidence:** Full exact diff read. Explicitly approved delta adds actual None/safety scalars through the existing projection/spec/assumption/wrapper; changes refusal/capacity/overflow branches to source behavior; generalizes Ready/Suspended/nonretryable controls; pins original positive control to pure; adds permitted-safety, unsafe refusal, precedence and sequence-overflow controls. No requires clause strengthens an existing native API; runtime source and test hashes are unchanged. No invariant, decreases, visibility, TCB entry or trust marker is removed/added. Regex is used only for simple same-line markers and complemented by full source/diff inspection; no parser-safe claim about complex attributes is needed here.

## Code Parity

- Nonpure Unsafe refusal -> native engine/action/mod.rs:220-225 -> mirror resume_action_outcome_pure_decision and spec_resume_action_outcome_decision -> proof_resume_nonpure_unsafe_is_unsupported at1218 and proof_resume_unsafe_refusal_precedes_exhaustion at1240 -> exact registered verifier command. Native public behavior was independently executed in attempt1 on the byte-identical native sources, including all current nonpure effects and refusal-over-exhaustion.
- Pure and permitted safety positive behavior -> native None short circuit and primitives/retry.rs:164-173 -> explicit None/safety scalars -> proof_resume_failed_retryable_with_capacity_is_awaiting at1142 and proof_resume_permitted_safety_with_capacity_is_awaiting at1194. The proof requires for permitted safety select the intended Safe/KeyRequired cases and leave the unsafe refusal control unrestricted by capacity/overflow.
- Refusal before capacity; capacity before arithmetic -> native action/mod.rs:220-234 and action/retry_helpers.rs:9-30 -> source-ordered mirror/spec branches -> exhaustion/overflow conditional control at1153, refusal precedence at1240 and sequence-overflow control at1249. Attempt-overflow boolean overapproximates an unreachable below-capacity u16 state, but actual source-view inputs still map to the correct branch; no proof depends on pretending such a state is reachable.
- Ready, Suspended and nonretryable failure -> unchanged native outcome branches -> generalized controls at1108,1125,1174. Each proof has satisfiable bounded scalar witnesses; no contradictory precondition or empty domain is introduced.

## Findings

No unresolved introduced findings in the reviewed delta. Original CODE F1 is closed. The pre-existing sequence-overflow projection discrepancy is also repaired. Unchanged unrelated projection functions and whole-native correctness were not requalified by this bounded review.

## Trust Boundary

- `PROVED`: Conditional scalar-spec branch properties accepted by the exact registered verifier invocation;34 obligations verified in the containing target. Semantic review is restricted to changed resume obligations.
- `TRUSTED`: The existing external mirror body and seven assume_specification bridges. contracts/proof_obligations.yaml:548-579 registers this trusted projection design; extern_runtime_execute_do.rs:20-36 explicitly labels WEAK binding; spec file trust-boundary comments also disclose it. The existing resume bridge gains explicit source-view parameters and retains its equality/result-domain guarantees. No new assumption entry is introduced.
- `BLOCKED`: A stronger claim that Verus verifies the native runtime body. Independent `verus --no-cheating --crate-type=lib verification/verus/vb_runtime_execute_do_spec.rs` exits1, refusing the same seven assumption entries. This is the recorded reason the registered command lacks no-cheating. No full project CI, strong source binding or canonical taxonomy acceptance is claimed. The existing registry's broad deductively_verified labels are not upgraded or independently endorsed by this review.

## Verdict

Approve the scoped repair of the existing conditional projection and close the introduced CODE finding. Native runtime helper repair retains its prior bounded source/test approval. Keep the result at verifier PASS with an explicit TRUSTED boundary; canonical vb-eirmk.60 remains incomplete under the user's exhaustive mapping decision.
