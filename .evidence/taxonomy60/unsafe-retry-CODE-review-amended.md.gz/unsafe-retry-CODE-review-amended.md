**Bead**: vb-eirmk.60, bounded current-format unsafe retry repair only  
**State**: amended frozen candidate review  
**Reviewer**: black-hat-reviewer  
**Source checkout**: /home/lewis/src/isoloated/vb-taxonomy60-design-r24  
**Attempt**: 2  
**Native BASE**: f366003714753937573e04650bf63cc4e5beb8ea  
**Amended formal BASE**: ae8ab1a7440cd65e01e52b32b18d5295bd3539e1  
**HEAD**: eb3c2a81cfb615f7d340576b1259383ebcd41fa6

## Gate Result

**STATUS: APPROVED** for the bounded current-format helper refusal and existing weak projection repair. F1 from unsafe-retry-CODE-review.md is closed at this exact HEAD. This approval supplies no canonical taxonomy acceptance, full CI claim, stronger native proof binding or vb-eirmk.60 closure.

## PHASE 1: Contract & Bead Parity

| Requirement | Status | Evidence |
|-------------|--------|----------|
| Nonpure Unsafe Retryable failure refuses before another ticket | PASS | Native source unchanged at its previously reviewed/tested SHA; action/mod.rs:220-225 |
| None bypass, Safe/KeyRequired, nonretryable, Ready/Suspended retained | PASS | Previously independent42-test run remains on byte-identical native/test sources; explicit formal controls cover pure and permitted classes |
| Formal safety/refusal order matches source | PASS | Mirror336-367 and spec301-333 now take side_effect_is_none/retry_safety_disc and check safety before capacity |
| Capacity and overflow source parity | PASS | Exhaustion precedes overflow; below capacity overflow now yields InternalInvariantViolation, matching retry_helpers.rs |
| No new assumption/trust entry or native/API/schema changes | PASS for exact diff | Only the two formal files change against amended BASE; native/test hashes identical to prior reviewed HEAD;7 external and7 assume_specification entries before/after |

The parent's expressly requested projection repair authorized the added scalar parameters and corresponding spec/assumption signatures, explicit safe/pure positive controls, refusal controls and overflow correction. The changes constrain the model to the authoritative behavior and do not loosen a native requirement.

## PHASE 2: Farley Engineering Rigor

The amended files are existing formal artifacts, not newly introduced runtime functions. Native modified functions remain the measured17-line resume_action_outcome and21-line resume_failed_action reviewed in attempt1. The projection keeps direct branch order, bounded scalar inputs and no I/O. No new runtime abstraction, authority DTO or dependency appears.

## PHASE 3: Holzman Rust (The Big 6)

No native source changes occur in this amendment. Formal scalar branches add no unsafe, unwrap, expect, panic, unchecked arithmetic, loop or allocation. Existing trusted projection attributes remain explicitly TRUSTED and are not counted as verified native executable bodies.

## PHASE 4: Ruthless Simplicity & DDD

The explicit source-derived None flag and safety discriminator preserve the actual deciding axes. The model has no unconstrained may_retry flag capable of hiding an unsafe input. Unknown nonpure retry-safety discriminators refuse; pure bypass and Ready/Suspended remain independent of safety, matching the current helper's behavior.

## PHASE 5: The Bitter Truth

The amended projection closes the introduced semantic omission. Verus verifies conditional properties of an existing trusted mirror; it does not verify resume_action_outcome's native body. The no-cheating control demonstrates that boundary by failing on the same seven existing assumption bridges. Full repository CI and canonical taxonomy are not established by this review.

## Findings (Ordered by Severity)

No unresolved introduced findings in the bounded amendment. Prior F1 is closed. The prior sequence-overflow model discrepancy is also corrected. Existing weak binding, unrelated formal models and lack of in-repository live callers for the public helper remain scope limits, not newly introduced patch defects.

## Quality Gates

| Gate | Result | Evidence |
|------|--------|----------|
| Exact registered verus command | PASS, exit0 | amended-verus.log:34 verified,0 errors |
| bash scripts/check-verus-production-binding.sh | PASS, exit0 | amended-binding.log:0 STRONG,34 WEAK,0 VACUUM |
| bash scripts/check-production-inner-drift.sh | PASS, exit0 | amended-drift.log:34 mirrors,33 extern files,0 drift findings |
| git diff --check amendedBASE HEAD | PASS, exit0 | Independent command on frozen sources |
| Independent native scoped nextest | PASS, prior observed run on identical native/test SHA | unsafe-retry-native-review.log:42 passed,2609 excluded; source hashes checked unchanged at amended HEAD |
| verus --no-cheating registered target | EXPECTED REFUSAL, exit1 | amended-no-cheating.log lists7 existing assume_specification entries; this is a trust-boundary control, not proof success |
| Full moon ci / stronger native formal binding | NOT ESTABLISHED | Outside bounded acceptance; no claim made |

Verifier command comes verbatim from contracts/proof_obligations.yaml:568:

```sh
verus --crate-type=lib verification/verus/vb_runtime_execute_do_spec.rs
```

Independent execution used persistent workspace TMPDIR and a60-second command bound without changing verifier arguments. Installed Verus0.2026.05.05.d03e906, release, linux_x86_64, toolchain1.95.0-x86_64-unknown-linux-gnu. Output contains only `verification results:: 34 verified, 0 errors`.

Source SHA256 at amended HEAD:

```text
af94cfc37c850fa8deeb5ada51557f30f626b5262d2b238466bab5b2e57f80a9  verification/verus/production_inner/execute_do_production.rs
19d5f2f91513f98ff5e87becde11ee816182ad60b96097350e558f7d8f6ba6e3  verification/verus/vb_runtime_execute_do_spec.rs
0e5595ca10b06f72f57a2d794060c1a89ebcf4979cc35d543047cc274f3fcdee  crates/vb_runtime/src/engine/action/mod.rs
900344c441d7ec8c315a6a6c6e99fe505df64766c567a64d18426b0b3453be62  crates/vb_runtime/tests/action_resume_contract.rs
```

## Verdict

**STATUS: APPROVED** for this bounded helper behavior and conditional projection maintenance. No additional repair requested within that scope. The user's exhaustive MASTER65 implications still block canonical LocalWrite projection of the historical IdempotentExternal register, as recorded in mapping-decision-addendum.md. vb-eirmk.60 remains open; parent owns lifecycle updates.
