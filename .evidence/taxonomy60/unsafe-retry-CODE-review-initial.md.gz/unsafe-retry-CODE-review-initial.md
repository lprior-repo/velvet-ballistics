**Bead**: vb-eirmk.60, bounded current-format unsafe retry repair only  
**State**: frozen candidate review  
**Reviewer**: black-hat-reviewer  
**Source checkout**: /home/lewis/src/isoloated/vb-taxonomy60-design-r24  
**Attempt**: 1  
**BASE**: f366003714753937573e04650bf63cc4e5beb8ea  
**HEAD**: ae8ab1a7440cd65e01e52b32b18d5295bd3539e1

## Gate Result

**STATUS: REJECTED** for delivery while introduced formal projection drift remains. Bounded runtime implementation: PASS, no implementation defect found. This is not approval of canonical taxonomy or full vb-eirmk.60.

## PHASE 1: Contract & Bead Parity

| Requirement | Status | Evidence |
|-------------|--------|----------|
| Retryable nonpure Unsafe refuses before another ticket and before exhaustion handling | PASS | action/mod.rs:220-225 calls existing is_failure_retriable; all current nonpure classes covered by public tests; independent native run passes |
| None bypass and Safe/KeyRequired behavior retained | PASS | new conjunct is skipped for None; helper returns retryable for current Safe/KeyRequired; public tests cover allowed tickets and exhaustion |
| NonRetryable, Ready and Suspended behavior retained | PASS | first refusal guard retained; Ready/Suspended branches unchanged; existing caller tests rerun |
| Exact artifact/ABI/catalog/verifier formats retained | PASS for diff scope | git diff --name-only returns only runtime action module and public behavior test; all serialized types and source identity authorities unchanged |
| Existing resume formal projection still describes production | FAIL, introduced discrepancy | mirror/spec omit both contract axes and still predict AwaitingAction for the newly rejected unsafe failure |

The bounded contract read from the frozen author's workspace is .beads/vb-eirmk.60/unsafe-retry-contract.md. Repo-wide source search finds the public definition/reexport and tests, but no in-repository live production call to resume_action_outcome. Evidence therefore establishes public helper behavior; it does not establish that all shard retry routes use this helper.

## PHASE 2: Farley Engineering Rigor

| Function | Lines | Limit | Status |
|----------|-------|-------|--------|
| resume_action_outcome, lines197-213 | 17 measured physical lines | 25 | PASS |
| resume_failed_action, lines215-235 | 21 measured physical lines | 25 | PASS |

Both changed functions have three parameters, perform pure decision/ticket construction, and add no I/O. Existing long unrelated functions were not charged to this diff. New tests exercise the public API with exact typed refusal, ticket fields and exhaustion results; test source style is outside this CODE gate.

## PHASE 3: Holzman Rust (The Big 6)

| Rule | Status |
|------|--------|
| Zero new unsafe | PASS |
| Zero new unwrap/expect | PASS |
| Zero new panic/todo/dbg | PASS |
| Existing checked ticket arithmetic retained | PASS |

The new predicate reuses primitives/retry.rs:164-173 and runs before retry_ticket, whose unchanged checked sequence/attempt helpers return typed errors. No new arithmetic, collection, dependency, authority type or serialization code is added.

## PHASE 4: Ruthless Simplicity & DDD

| Check | Status |
|-------|--------|
| No new Option-based state machine | PASS |
| Explicit decision before ticket construction | PASS |
| Reuses existing retry-safety calculation | PASS |

The supplied contract now participates in the failure decision. The bounded contract intentionally preserves the existing pure bypass and KeyRequired behavior; key validation and ticket/contract authority binding remain separate pre-existing concerns.

## PHASE 5: The Bitter Truth

The native repair meets its narrow behavioral contract. The existing formal chain cannot establish this new refusal because its projected inputs omit the deciding contract values. A passing identifier-drift script is not evidence of semantic equivalence. Existing verifier::external/assume_specification use remains a weak mirror binding, and repairing the projection must not be reported as a new native mathematical proof.

## Findings (Ordered by Severity)

| Finding | Severity | File:Line | Status |
|---------|----------|-----------|--------|
| F1: Resume formal projection omits the newly enforced safety branch | HIGH, introduced by behavioral change | verification/verus/production_inner/execute_do_production.rs:330; verification/verus/vb_runtime_execute_do_spec.rs:301 | Open, blocks delivery review |

### F1: Resume formal projection omits the contract refusal

**Location**: verification/verus/production_inner/execute_do_production.rs:330-365; verification/verus/vb_runtime_execute_do_spec.rs:301-332,439-459,736-775,1110-1117.

**Problem**: The production function now rejects Failed + Retryable + non-None + Unsafe before capacity. The mirror/spec accept no side-effect or retry-safety input and return AwaitingAction when attempt<capacity and arithmetic succeeds. The existing positive proof asserts that unconditional retryable result. This discrepancy is introduced by the new source decision even though these formal files are unchanged.

**Evidence**: For current nonpure Unsafe with attempt1/capacity3, production now yields UnsupportedPrimitive(action_failed_non_retryable), while both projected decisions at their current input tuple (2,1,3,0,false,false) yield AwaitingAction. The independent native public test confirms production refusal. The drift gate passes because its identifier checks do not compare this decision relation.

**Required Fix**: Extend the existing projection/spec/assume_specification/wrapper with actual side_effect_is_none and retry_safety discriminator inputs, reproduce the exact current helper semantics and refusal precedence, and add unsafe refusal plus precedence controls. Preserve positive cases explicitly for pure or permitted retry-safety inputs. Keep the same existing assumption/trust category; add no external_body, new trusted predicate, weakened guard or new assumption to bypass the obligation. A free may_retry boolean is weaker evidence than explicit source discriminants because it can hide the unsafe case in an unconstrained projection. Native source-bound behavior tests remain necessary.

**Pre-existing model limitation**: The same old mirror reports RetryExhausted for sequence overflow, while production action/retry_helpers.rs:9-17 reports InternalInvariantViolation. This was not introduced by this patch and is not a second new runtime finding. Any renewed claim of an exact full resume projection should also model the existing overflow branch correctly, or explicitly restrict the equivalence claim. The attempted-capacity guard precedes overflow; the new safety refusal precedes both. The existing weak trusted mirror architecture also predates this patch and is not newly created here.

## Quality Gates

| Gate | Result | Evidence |
|------|--------|----------|
| Independent scoped canonical-nextest-derived run | PASS, exit0 | unsafe-retry-native-review.log:42 tests run,42 passed,2609 excluded; run e515428c-e83e-4110-89e8-4fe5f93adf02 |
| bash scripts/check-production-inner-drift.sh | PASS, exit0 | production-inner-drift.log:34 mirrors,33 extern files,0 findings; semantic omission remains as F1 |
| git diff --check BASE HEAD | PASS, exit0 | actual command executed in own isolated workspace |
| Full moon ci / Verus proof execution | NOT RUN | outside this bounded CODE run; no closure claimed |
| Clippy / rustfmt | NOT independently run | author report exists but not treated as independent evidence |

Independent test command, derived from .moon/tasks/all.yml:test with bounded package/binary/filter selection:

```sh
flock --shared target/moon-locks/source-mutation.lock env TMPDIR=$PWD/target/tmp RUSTC_WRAPPER= RUSTFLAGS=-Dwarnings CARGO_BUILD_JOBS=2 timeout 10m rustup run nightly-2026-04-28 cargo nextest run --cargo-quiet -p vb_runtime --all-features --lib --test action_resume_contract --test-threads 4 -E 'test(engine::action::tests::) | test(resume_action) | test(retry_ticket) | binary(action_resume_contract)'
```

Frozen source SHA256:

```text
0e5595ca10b06f72f57a2d794060c1a89ebcf4979cc35d543047cc274f3fcdee  crates/vb_runtime/src/engine/action/mod.rs
900344c441d7ec8c315a6a6c6e99fe505df64766c567a64d18426b0b3453be62  crates/vb_runtime/tests/action_resume_contract.rs
fb57fd6349c2d181f38b5f8a5c306b780c976ccdb91a406871777ae8a3fea329  verification/verus/production_inner/execute_do_production.rs
0939ce3eed4a3c51f0bac7298e308a31e295b1cc4e05af024fc792c2d677b5c5  verification/verus/vb_runtime_execute_do_spec.rs
```

Source hashes also retained in unsafe-retry-review-source.sha256. The review workspace has no tracked diff. Parent owns bead state; no commit, push or bead closure performed.

## Verdict

**STATUS: REJECTED** for delivery due to F1. The bounded runtime implementation passes source review and independent scoped native execution. Formal projection repair is finite and may clear this blocker without claiming canonical taxonomy acceptance, full CI success or stronger native proof binding.

## Required Repair Actions

1. HIGH: Update and verify the existing resume formal projection and controls against the exact new refusal branch, retaining explicit trust-boundary disclosure.
