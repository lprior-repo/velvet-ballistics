**Bead**: vb-eirmk.60, retained current-format fixture CODE review only  
**State**: frozen test-source review  
**Reviewer**: black-hat-reviewer  
**Source checkout**: /home/lewis/src/isoloated/vb-taxonomy60-design-r24, reading immutable Git blobs  
**Attempt**: 1  
**Production BASE**: f366003714753937573e04650bf63cc4e5beb8ea  
**Baseline fixture HEAD**: c92826fb216079584b5a4ee390abf68867027d8f  
**Checkpoint fixture HEAD**: b0e249de044d1a8ec2a34aec5f2e7115d11cbd5f

## Gate Result

**STATUS: APPROVED** for bounded fixture code and issuer provenance. No issuer bypass, forged opaque authority, unsafe operation or production data-format change found in the reviewed test-source delta. Assertion adequacy, archive integrity and executable recovery/replay acceptance belong to the separate TEST review and are not approved by this source-only result.

## PHASE 1: Contract & Bead Parity

The frozen checkpoint commit is directly based on the frozen baseline fixture commit; the baseline is directly based on f366003714753937573e04650bf63cc4e5beb8ea. Git source-diff enumeration returns3 changed test-source files and0 changed files under crates/vb_core, vb_runtime, vb_storage or vb_validate. Reviewed both complete added fixture modules, their integration entry and the pre-existing workflow/contract/grant helpers they call. Archived binary databases were not unpacked or executed in this review.

- Baseline retained_taxonomy.rs:31-53 calls actual ExecutorCatalog::run_registered_conformance, register_pack and submit_artifact for registered Strict artifacts; pure Strict uses submit_artifact_with_contracts. Declared contracts and WorkflowParts are caller input, not fabricated accepted authority. The workflow constructor validates the checksum/parts before submission.
- Baseline lines68-90 submits through public Runtime, ticks it, then extracts an actual pending ticket and matching scheduled ABI event. Lines100-112 obtain a real register grant and scoped grant through catalog issuer APIs, execute through Runtime::execute_registered_action and validate the returned opaque receipt.
- Distinct Sends/Creates/Destroys records at138-164 use genuine Journaled storage admission and remain cold. The test does not label them registered Strict executors or give them a new canonical classification.
- Checkpoint retained_retry.rs:51-85 uses the same actual acceptance/runtime issuance chain. Lines90-96 deliberately performs a provider effect through the public FjallRegister adapter with a catalog-issued grant before runtime completion; this is a controlled crash-window setup, not direct receipt fabrication.
- Checkpoint lines98-125 call public Runtime::fail_action and tick_all, then extract the actual persisted RetryCheckpoint event/payload. The checkpoint is decoded from that event and is not hand-constructed as authority. Replay lines143-171 verify the accepted artifact, validate the checkpoint against it and call public Runtime::recover_retry.

## PHASE 2: Farley Engineering Rigor

I/O lives in explicitly named test issue/replay/copy helpers. Test implementation style and large fixture-function length are not production style findings. copy_tree bounds recursion with checked_sub and private destination creation; every copied database is opened under the private replay tree. No production core performs new file access or parsing.

## PHASE 3: Holzman Rust (The Big 6)

No unsafe code, new production arithmetic, new dependency, production enum/tag/schema change, catalog source mutation or verifier source mutation is introduced by these fixture commits. Checkpoint sequence advancement uses checked_add. Filesystem and issuer failures propagate as test errors. tempfile scratch uses the runner-configured persistent TMPDIR; this source review did not run tests or create scratch outside the assigned workspace.

## PHASE 4: Ruthless Simplicity & DDD

AcceptedArtifact, ActionTicket, JournalEvent and RunCheckpointV1 are deserialized as data and then checked by public storage/runtime authorities before use. Opaque RegisterGrant, ScopedGrant and ExecutedConformance are never deserialized or built by field injection in the new fixture code.

The pre-existing scoped_grant_fixture::issue_scoped uses fixed test issuer/subject/time/approval input parameters, then calls ExecutorCatalog::issue_scoped_grant. The result is actual opaque issued authority under the repository's local operator trust model. GrantDispatchContext is a public request context; it does not replace the issuer. These tests establish no cryptographic provider identity, remote grant lifecycle or bound human-approval claim.

Raw Fjall access at baseline lines120-133 reads existing register_receipts_v1 rows for byte retention after the adapter is dropped. It does not construct/insert target, metadata or receipt rows. The known keyspace name matches the actual executor source; reopening/keyspace discovery occurs only in fixture-owned storage.

## PHASE 5: The Bitter Truth

Fixture authority originates in real APIs; synthetic run IDs, input values and local policy parameters do not manufacture opaque checked tokens. Baseline replay copies retained directories before opening them (167-179,260-263); checkpoint replay does likewise (256-259). Recovery, reconciliation and resulting appends affect the copy. This is current-format characterization and retained identity evidence; no cold adapter or canonical taxonomy is implemented.

## Findings (Ordered by Severity)

No introduced CODE finding in the bounded issuer/serialization scope. This does not certify every replay assertion, the archive's executable success, all corruption controls, archive packaging size or future-schema compatibility. The separate TEST reviewer owns that evidence.

## Quality Gates

| Gate | Result | Evidence |
|------|--------|----------|
| Frozen source diff enumeration | PASS |3 changed test-source files;0 production authority files under the selected core/runtime/storage/validate roots |
| git diff --check productionBASE checkpointHEAD -- crates | PASS, exit0 | Independent command against immutable commits |
| Source reads and issuer-call provenance | PASS | Locations above; public grant helper inspected from the frozen checkpoint commit |
| Fixture native tests/replay/archive hashes | NOT independently executed here | Deliberately assigned to separate TEST reviewer; no inherited pass counts repeated |

Frozen source SHA256:

```text
7f0183d120abeebb9f4421dc9f737ad297de0c5a50898cbeca1faafd2ba929e9  c92826fb:crates/workspace_tests/tests/vb_7x0ol_probe_registered_executor/retained_taxonomy.rs
5ee141df8f502beb724147e75c673cbe0bb17cddfe492e402e2fefeb2f309928  b0e249de:crates/workspace_tests/tests/vb_7x0ol_probe_registered_executor/retained_taxonomy.rs
e4bb1abe9e0a112c263ef773e7cb65223658fab63e7a8e389444fbe8762ce013  b0e249de:crates/workspace_tests/tests/vb_7x0ol_probe_registered_executor/retained_retry.rs
94245d6952ac5d9bb2f2c6a14350bf47be55699b5df2d44c5378499eef92fd96  b0e249de:crates/workspace_tests/tests/vb_7x0ol_probe_registered_executor.rs
```

## Verdict

**STATUS: APPROVED** for frozen fixture code/issuer provenance only. Keep canonical vb-eirmk.60 open and the local executor canonical projection blocked under the user's exhaustive mapping decision. Parent retains tracker and integration ownership; this reviewer changed no production source or tracker status.
