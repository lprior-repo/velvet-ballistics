#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 1 ] || [ ! -r "$1" ]; then
    exit 2
fi

awk '
BEGIN { running_count = 0; result_count = 0; ok = 1 }
/^running / {
    running_count++
    if ($0 != "running 1 test") { ok = 0 }
}
/^test result:/ {
    result_count++
    if ($0 !~ /^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [0-9]+\.[0-9]+s$/) { ok = 0 }
}
END {
    if (running_count != 1 || result_count != 1 || ok != 1) { exit 1 }
}
' "$1"
