#![forbid(unsafe_code)]
//! Multi-shard runtime routing commands to correct shards.

use std::num::NonZeroUsize;
use vb_core::action::{ActionContract, ActionFailure, ActionOutputReady, ActionTicket};
use vb_core::capability::CapabilitySet;
use vb_core::ids::{RunId, SlotIdx, StepIdx, WorkflowDigest};
use vb_core::value::SlotValue;
use vb_core::workflow::CompiledWorkflow;

use crate::counters::{CounterSnapshot, RuntimeMetricsSnapshot, ShardMetricsSnapshot};
use crate::journal::SharedRuntimeJournal;
use crate::shard::timer_wheel::TimerEntry;
use crate::shard::{
    AskAnswer, InspectResponse, Shard, ShardCommand, ShardConfig, ShardDirective,
    ShardPendingBoundarySnapshot,
};
use crate::trace::TraceEvent;
use crate::{RuntimeError, RuntimeResult};

mod shutdown;
pub use shutdown::{ShutdownFailure, ShutdownPhase, ShutdownReport};

struct RecoveryArtifactWorkflow {
    artifact: vb_storage::admission::AcceptedArtifact,
    workflow: CompiledWorkflow,
}

struct RecoveryPrefixEvidence {
    events: Vec<vb_storage::JournalEvent>,
    admission: crate::admission::RunAdmission,
    workflow_digest: WorkflowDigest,
    next_seq: vb_storage::EventSeq,
}

struct RecoveredSeedProductContext {
    run: RunId,
    prefix: RecoveryPrefixEvidence,
    /// Typed frame-seed product. The storage-side cannot-resume witness is
    /// carried on `seed.cannot_resume_state()` and survives through the
    /// runtime classification step (`product_from_recovered_context` →
    /// `RuntimeRecoveryProduct::CannotResume`). Holding the typed product
    /// here is what closes the FINDING-002 typestate bypass: the raw
    /// `RecoveryFrameSeed` DTO no longer leaks into the runtime flow.
    seed: vb_storage::recovery::RecoveryFrameSeedProduct,
    boundary: crate::recovery::RecoveredRunBoundary,
}

/// Lossless conversion of a `u32` integer to its exact `f32` representation.
///
/// `From<u32> for f32` is NOT implemented by the Rust standard library
/// (only `From<u8>`, `From<u16>`, `From<i8>`, `From<i16>` exist for `f32`).
/// For values in `[0, 2^24)` — which includes the full RA-003 trace-ring
/// domain (`cap <= 2^20`, `len <= cap`) — the IEEE-754 single-precision
/// encoding fits the integer exactly, so this helper produces a result
/// bit-identical to `(n as f32)` without using an `as`-cast and without
/// tripping `clippy::as_conversions`. All integer arithmetic uses
/// `u32::checked_*` / `u32::saturating_*` so `clippy::arithmetic_side_effects`
/// is also satisfied.
fn u32_to_f32_exact(n: u32) -> f32 {
    if n == 0 {
        return 0.0_f32;
    }
    // `e = floor(log2(n))`. For n in [1, 2^32), `leading_zeros` is in [0, 31],
    // so `e` is in [0, 31]. The `31 - ...` formula is the bit-width (32) minus
    // 1 (for the implicit leading one) minus `leading_zeros`.
    let e = u32::checked_sub(31, n.leading_zeros()).unwrap_or(0);
    let biased_exp = u32::saturating_add(e, 127);
    let power = 1_u32.checked_shl(e).unwrap_or(1);
    let mantissa = u32::checked_sub(n, power)
        .unwrap_or(0)
        .checked_shl(23_u32.saturating_sub(e))
        .unwrap_or(0);
    f32::from_bits((biased_exp << 23) | mantissa)
}

/// Summary of an active run on a shard.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ActiveRunSummary {
    /// Run identifier.
    pub run_id: RunId,
    /// Compiled workflow digest.
    pub workflow: vb_core::WorkflowDigest,
    /// Number of steps in the workflow.
    pub step_count: u16,
    /// Steps that reached a terminal state (Succeeded, Failed, Skipped, or Cancelled).
    pub steps_completed: u16,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuntimePendingBoundarySnapshot {
    shards: Box<[ShardPendingBoundarySnapshot]>,
    command_queue_depth: usize,
    active_run_count: usize,
    pending_timer_count: usize,
    pending_action_count: usize,
    pending_ask_count: usize,
    truncated: bool,
}

impl RuntimePendingBoundarySnapshot {
    fn new(
        shards: Box<[ShardPendingBoundarySnapshot]>,
        totals: RuntimePendingBoundaryTotals,
    ) -> Self {
        Self {
            shards,
            command_queue_depth: totals.command_queue_depth,
            active_run_count: totals.active_run_count,
            pending_timer_count: totals.pending_timer_count,
            pending_action_count: totals.pending_action_count,
            pending_ask_count: totals.pending_ask_count,
            truncated: totals.truncated,
        }
    }

    #[must_use]
    pub fn shards(&self) -> &[ShardPendingBoundarySnapshot] {
        &self.shards
    }

    #[must_use]
    pub const fn command_queue_depth(&self) -> usize {
        self.command_queue_depth
    }

    #[must_use]
    pub const fn active_run_count(&self) -> usize {
        self.active_run_count
    }

    #[must_use]
    pub const fn pending_timer_count(&self) -> usize {
        self.pending_timer_count
    }

    #[must_use]
    pub const fn pending_action_count(&self) -> usize {
        self.pending_action_count
    }

    #[must_use]
    pub const fn pending_ask_count(&self) -> usize {
        self.pending_ask_count
    }

    #[must_use]
    pub const fn truncated(&self) -> bool {
        self.truncated
    }
}

#[derive(Default)]
struct RuntimePendingBoundaryTotals {
    command_queue_depth: usize,
    active_run_count: usize,
    pending_timer_count: usize,
    pending_action_count: usize,
    pending_ask_count: usize,
    truncated: bool,
}

impl RuntimePendingBoundaryTotals {
    fn add_shard(&mut self, shard: &ShardPendingBoundarySnapshot) {
        self.command_queue_depth = self
            .command_queue_depth
            .saturating_add(shard.command_queue_depth());
        self.active_run_count = self
            .active_run_count
            .saturating_add(shard.active_run_count());
        self.pending_timer_count = self
            .pending_timer_count
            .saturating_add(shard.pending_timer_count());
        self.pending_action_count = self
            .pending_action_count
            .saturating_add(shard.pending_action_count());
        self.pending_ask_count = self
            .pending_ask_count
            .saturating_add(shard.pending_ask_count());
        self.truncated |= shard.truncated();
    }
}

fn shard_id_from_index(index: usize) -> u32 {
    u32::try_from(index).map_or(u32::MAX, core::convert::identity)
}

/// Multi-shard runtime.
pub struct Runtime {
    shards: Vec<Shard>,
    shard_count: usize,
    journal: SharedRuntimeJournal,
    policy: vb_core::policy::RuntimePolicy,
    live_policy: crate::policy::LivePolicy,
}

impl Runtime {
    /// Creates a new runtime with the given number of shards, per-shard configuration, and
    /// explicit [`SharedRuntimeJournal`].
    ///
    /// The journal argument is **required**: this constructor will not silently pick a
    /// non-durable default. Master §18 requires Fjall-backed persistence for recovery,
    /// so production callers must wire a [`crate::journal::StorageRuntimeJournal`] (strict
    /// barrier) or [`crate::journal::QueuedStorageRuntimeJournal`] (group-committed).
    /// Tests and benchmarks that do not need durability should pass
    /// [`crate::journal::VolatileRuntimeJournal::shared`] or
    /// [`crate::journal::NoopRuntimeJournal::shared_for_tests_and_benchmarks`] so the
    /// call site documents the non-durable intent.
    #[must_use]
    pub fn new(
        shard_count: NonZeroUsize,
        config: ShardConfig,
        journal: SharedRuntimeJournal,
    ) -> Self {
        let count = shard_count.get();
        let mut shards = Vec::with_capacity(count);
        let mut index = 0usize;
        while index < count {
            shards.push(Shard::new_with_journal(config, journal.clone()));
            index = index.saturating_add(1);
        }
        Self {
            shards,
            shard_count: count,
            journal,
            policy: config.policy,
            live_policy: crate::policy::LivePolicy::new(),
        }
    }

    /// Creates a new runtime whose journal events survive only until process exit.
    ///
    /// This is the **test/benchmark-only** non-durable path. It is intentionally named
    /// long and explicit so every call site self-documents the trade-off. Production
    /// callers must use [`Runtime::new`] with a storage-backed
    /// [`SharedRuntimeJournal`].
    #[must_use]
    pub fn new_for_tests_and_benchmarks_only(
        shard_count: NonZeroUsize,
        config: ShardConfig,
    ) -> Self {
        Self::new(
            shard_count,
            config,
            crate::journal::VolatileRuntimeJournal::shared(),
        )
    }

    /// Configures the live policy with a verified artifact and rule.
    ///
    /// Updates actor-owned runtime state; does not persist to durable storage.
    pub fn configure_live_policy(
        &mut self,
        digest: vb_core::policy::PolicyDigest,
        rule: vb_core::policy::PolicyRule,
    ) -> RuntimeResult<()> {
        self.configure_live_policy_helper(digest, rule);
        Ok(())
    }

    /// Activates the emergency deny overlay with strict durability.
    ///
    /// Persists the emergency marker, verifies the returned state is Active,
    /// then mirrors into owned live policy state. Fails on corruption or
    /// unsupported marker versions.
    pub fn activate_emergency_deny(&mut self) -> RuntimeResult<()> {
        self.activate_emergency_deny_helper()
    }

    /// Submits a run using a compiled workflow.
    pub fn submit_direct(&self, run: RunId, workflow: CompiledWorkflow) -> RuntimeResult<()> {
        self.submit_direct_with_grants(run, workflow, CapabilitySet::empty())
    }

    /// Submits a run using a compiled workflow and explicit caller grants.
    pub fn submit_direct_with_grants(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        caps: CapabilitySet,
    ) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.validate_submit_admission(run, &workflow, caps.clone())?;
        shard.enqueue(ShardCommand::Submit {
            run,
            workflow,
            caps,
        })
    }

    /// Submits a run with explicit caller grants and validated action contracts.
    pub fn submit_direct_with_grants_and_contracts(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        caps: CapabilitySet,
        action_contracts: Box<[ActionContract]>,
    ) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.validate_submit_admission_with_contracts(
            run,
            &workflow,
            caps.clone(),
            &action_contracts,
        )?;
        shard.enqueue(ShardCommand::SubmitWithContracts {
            run,
            workflow,
            caps,
            action_contracts,
        })
    }

    /// Submits a run with pre-mapped input slots, explicit caller grants, and validated action contracts.
    pub fn submit_direct_with_inputs_grants_and_contracts(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        inputs: Box<[(SlotIdx, SlotValue)]>,
        caps: CapabilitySet,
        action_contracts: Box<[ActionContract]>,
    ) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.validate_submit_admission_with_contracts(
            run,
            &workflow,
            caps.clone(),
            &action_contracts,
        )?;
        shard.enqueue(ShardCommand::SubmitWithInputsAndContracts {
            run,
            workflow,
            inputs,
            caps,
            action_contracts,
        })
    }

    /// Submits a run with inline workflow (same as submit_direct for now).
    pub fn submit_compiled(&self, run: RunId, workflow: CompiledWorkflow) -> RuntimeResult<()> {
        self.submit_direct(run, workflow)
    }

    /// Submits a compiled run with explicit caller grants.
    pub fn submit_compiled_with_grants(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        caps: CapabilitySet,
    ) -> RuntimeResult<()> {
        self.submit_direct_with_grants(run, workflow, caps)
    }

    /// Submits a run with pre-mapped runtime input slots.
    pub fn submit_compiled_with_inputs(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        inputs: Box<[(SlotIdx, SlotValue)]>,
    ) -> RuntimeResult<()> {
        self.submit_compiled_with_inputs_and_grants(run, workflow, inputs, CapabilitySet::empty())
    }

    /// Submits a run with pre-mapped runtime input slots and explicit caller grants.
    pub fn submit_compiled_with_inputs_and_grants(
        &self,
        run: RunId,
        workflow: CompiledWorkflow,
        inputs: Box<[(SlotIdx, SlotValue)]>,
        caps: CapabilitySet,
    ) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.validate_submit_admission(run, &workflow, caps.clone())?;
        shard.enqueue(ShardCommand::SubmitWithInputs {
            run,
            workflow,
            inputs,
            caps,
        })
    }

    /// Cancels a run.
    pub fn cancel_run(&self, run: RunId) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Cancel { run, reason: None })
    }

    /// Kills a run unconditionally.
    pub fn kill_run(&self, run: RunId) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Kill { run, reason: None })
    }

    /// Resumes a suspended run from its current program counter.
    pub fn resume_run(&self, run: RunId) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Resume { run })
    }
    /// Recovers a run from durable Fjall journal evidence and enqueues it for resumption.
    ///
    /// This is the end-to-end recovery entry point: it reads the journal,
    /// replays events to reconstruct a typed `RecoveryFrameSeedProduct`,
    /// hydrates the recoverable live-frame portion, restores durable
    /// pending-action authority when present, and enqueues
    /// `ShardCommand::Recover` on the owning shard.
    ///
    /// Recovery crosses the bead `vb-w25-runtime-a2` FINDING-001/FINDING-002
    /// typestate boundary: the storage layer never hands back a raw
    /// `RecoveryFrameSeed`. It returns the typed
    /// `vb_storage::recovery::RecoveryFrameSeedProduct` (the storage
    /// cannot-resume/resumable witness, FINDING-002), which
    /// `recover_product` classifies through the parallel runtime boundary
    /// into a `crate::recovery::RuntimeRecoveryProduct`
    /// (`SummaryOnly` / `CannotResume { reason }` / `Resumable`,
    /// FINDING-001). `recover_and_resume` enqueues only the `Resumable`
    /// product and rejects the rest with a typed error.
    ///
    /// Returns `RuntimeError::RecoveryNotAvailable` when the runtime's
    /// journal is not storage-backed (noop or volatile journals cannot
    /// be replayed for crash recovery).
    ///
    /// Returns `RuntimeError::Recovery` when the recovery operation fails
    /// the journal replay fails (missing data, corrupt snapshot, digest
    /// mismatch, or unsupported recovery state).
    pub fn recover_and_resume(&self, run: RunId) -> RuntimeResult<()> {
        match self.recover_product(run)? {
            crate::recovery::RuntimeRecoveryProduct::Resumable(product) => {
                self.enqueue_recovered_product(*product)
            }
            other => Err(Self::rejected_recovery_product_error(other)),
        }
    }

    /// Recovers a failed run from a validated retry checkpoint.
    ///
    /// Unlike [`Runtime::recover_and_resume`], this path uses the full
    /// [`crate::run_checkpoint::RunCheckpointV1`] captured at the failure boundary,
    /// rather than a legacy resumable frame seed. The checkpoint identity is checked
    /// against the run before the recovery command is enqueued; `handle_recover`
    /// re-validates the checkpoint against the independently loaded accepted artifact
    /// (artifact digest, workflow digest, policy, ABI grant authority, frame/store/collect
    /// integrity) before any runtime state mutation.
    pub fn recover_retry(
        &self,
        run: RunId,
        checkpoint: crate::run_checkpoint::RunCheckpointV1,
        next_seq: vb_storage::EventSeq,
    ) -> RuntimeResult<()> {
        if checkpoint.run_id != run {
            return Err(RuntimeError::Recovery {
                error: "retry checkpoint run identity mismatch".to_string(),
            });
        }
        // Bind the caller-supplied checkpoint and next_seq to the actual durable chain
        // (latest accepted RetryCheckpoint + its preceding RunFailed event). A legacy,
        // missing, tampered, stale, or cross-run checkpoint fails closed here, before any
        // state or journal mutation. The CLI boundary is digest-protected, but this public
        // raw API must not trust caller-supplied run-attempt / prior-seq / next-seq authority.
        self.validate_retry_checkpoint_against_durable_chain(run, &checkpoint, next_seq)?;
        let command = crate::shard::types::RecoverRunCommand::for_retry(checkpoint, next_seq)?;
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Recover {
            command: Box::new(command),
        })
    }

    /// Validates a caller-supplied retry checkpoint against the run's durable journal.
    ///
    /// The durable failure boundary ends in `RunFailedEvent { seq: S, attempt: A }` followed by
    /// `RetryCheckpoint { seq: S+1, attempt: A+1 }`. The supplied checkpoint must decode to the
    /// exact latest durable `RetryCheckpoint` payload (binding run/step/attempt/prior_seq/
    /// artifact/workflow/policy/grants/frame/store/collect/contracts), its `prior_seq` must name
    /// the immediately preceding `RunFailedEvent` sequence, and `next_seq` must be the sequence
    /// immediately after the checkpoint. Checked arithmetic throughout; every rejection is
    /// fail-closed with no state or journal mutation.
    fn validate_retry_checkpoint_against_durable_chain(
        &self,
        run: RunId,
        checkpoint: &crate::run_checkpoint::RunCheckpointV1,
        next_seq: vb_storage::EventSeq,
    ) -> RuntimeResult<()> {
        let journal = self.recovery_storage_journal()?;
        let events = journal
            .events_for_run_full(run)
            .map_err(|error| RuntimeError::Recovery {
                error: format!("retry journal read failed: {error}"),
            })?;

        let durable = events.iter().rev().find(|event| {
            matches!(
                event,
                vb_storage::JournalEvent::RetryCheckpoint { run: r, .. } if *r == run
            )
        });
        let vb_storage::JournalEvent::RetryCheckpoint {
            run: durable_run,
            seq: durable_seq,
            attempt: durable_attempt,
            payload_digest: durable_payload_digest,
            payload: durable_payload,
            ..
        } = durable.ok_or_else(|| RuntimeError::Recovery {
            error: "run has no durable retry checkpoint".to_string(),
        })?
        else {
            return Err(RuntimeError::Recovery {
                error: "run has no durable retry checkpoint".to_string(),
            });
        };

        // Integrity of the durable record itself.
        let observed_digest = *blake3::hash(durable_payload).as_bytes();
        if observed_digest != *durable_payload_digest {
            return Err(RuntimeError::Recovery {
                error: "durable retry checkpoint payload digest mismatch".to_string(),
            });
        }

        // The supplied checkpoint must decode to the exact durable checkpoint value.
        // Use the version-aware decoder to reject historical version 1 payloads
        // that lack the policy_pin field in RunAdmission.
        let durable_checkpoint = crate::run_checkpoint::decode_checkpoint_payload(durable_payload)
            .map_err(|error| RuntimeError::Recovery {
                error: format!("durable retry checkpoint decode failed: {error}"),
            })?;
        if durable_checkpoint != *checkpoint {
            return Err(RuntimeError::Recovery {
                error: "retry checkpoint does not match durable RetryCheckpoint evidence"
                    .to_string(),
            });
        }

        // run_attempt / step authority (also covered by the value equality above, but these
        // yield clearer diagnostics and double as a defense-in-depth binding).
        if *durable_run != run {
            return Err(RuntimeError::Recovery {
                error: "durable retry checkpoint belongs to a different run".to_string(),
            });
        }
        if checkpoint.run_attempt.get() != *durable_attempt {
            return Err(RuntimeError::Recovery {
                error: "retry checkpoint run attempt does not match durable RetryCheckpoint"
                    .to_string(),
            });
        }

        // prior_seq must be the sequence immediately before the durable checkpoint.
        let expected_checkpoint_seq =
            checkpoint
                .prior_seq
                .checked_add(1)
                .ok_or_else(|| RuntimeError::Recovery {
                    error: "retry checkpoint prior_seq overflow".to_string(),
                })?;
        if durable_seq.get() != expected_checkpoint_seq {
            return Err(RuntimeError::Recovery {
                error: "retry checkpoint prior_seq does not match durable RetryCheckpoint position"
                    .to_string(),
            });
        }

        // next_seq must be the sequence immediately after the durable checkpoint.
        let expected_next_seq =
            durable_seq
                .get()
                .checked_add(1)
                .ok_or_else(|| RuntimeError::Recovery {
                    error: "retry checkpoint next_seq overflow".to_string(),
                })?;
        if next_seq.get() != expected_next_seq {
            return Err(RuntimeError::Recovery {
                error: "retry next_seq does not match durable RetryCheckpoint position".to_string(),
            });
        }

        // The checkpoint must be the journal head. An explicit retry that already consumed
        // this checkpoint appends StepStarted / ActionScheduled / RunFinished AFTER it, so a
        // checkpoint that is no longer the last event is already-consumed and must be rejected
        // (a stale `next_seq` alone cannot be trusted to detect this).
        let checkpoint_is_head = events
            .last()
            .is_some_and(|event| event.seq().get() == durable_seq.get());
        if !checkpoint_is_head {
            return Err(RuntimeError::Recovery {
                error: "retry checkpoint has already been consumed (journal advanced past it)"
                    .to_string(),
            });
        }

        // The event immediately preceding the checkpoint must be the run's own RunFailed
        // event for the attempt immediately before the checkpoint's run_attempt.
        let expected_failed_attempt =
            checkpoint
                .run_attempt
                .get()
                .checked_sub(1)
                .ok_or_else(|| RuntimeError::Recovery {
                    error: "retry checkpoint run_attempt underflow".to_string(),
                })?;
        let preceding_failed = events.iter().find(|event| {
            event.seq().get() == checkpoint.prior_seq
                && matches!(
                    event,
                    vb_storage::JournalEvent::RunFailedEvent { run: r, .. } if *r == run
                )
        });
        match preceding_failed {
            Some(vb_storage::JournalEvent::RunFailedEvent { attempt, .. })
                if *attempt == expected_failed_attempt =>
            {
                Ok(())
            }
            _ => Err(RuntimeError::Recovery {
                error: "retry checkpoint does not follow the run's own durable RunFailed event"
                    .to_string(),
            }),
        }
    }

    fn rejected_recovery_product_error(
        product: crate::recovery::RuntimeRecoveryProduct,
    ) -> RuntimeError {
        match product {
            crate::recovery::RuntimeRecoveryProduct::CannotResume(product) => {
                RuntimeError::RecoveryCannotResume {
                    reason: String::from(product.reason()),
                }
            }
            crate::recovery::RuntimeRecoveryProduct::SummaryOnly(_)
            | crate::recovery::RuntimeRecoveryProduct::Resumable(_) => {
                RuntimeError::UnsupportedFullRecoveryHydration
            }
        }
    }

    /// Builds a typed durable recovery product without mutating shard state.
    pub fn recover_product(
        &self,
        run: RunId,
    ) -> RuntimeResult<crate::recovery::RuntimeRecoveryProduct> {
        let fjall_journal = self.recovery_storage_journal()?;
        let prefix = Self::load_recovery_prefix_evidence(fjall_journal.as_ref(), run)?;
        let recovered = self.load_recovery_artifact_and_workflow(
            std::sync::Arc::clone(&fjall_journal),
            prefix.admission.artifact_digest(),
        )?;
        Self::validate_recovery_admission(run, self.policy, &prefix, &recovered)?;
        let retained_inputs = Self::load_retained_inputs_for_recovery(
            &prefix,
            &recovered,
            fjall_journal.as_ref(),
            run,
        )?;
        self.build_runtime_recovery_product(run, prefix, recovered, retained_inputs)
    }

    /// Loads and validates retained typed inputs for cold startup recovery.
    fn load_retained_inputs_for_recovery(
        prefix: &RecoveryPrefixEvidence,
        recovered: &RecoveryArtifactWorkflow,
        journal: &vb_storage::FjallJournal,
        run: RunId,
    ) -> RuntimeResult<Option<vb_storage::RunInputsRecord>> {
        // Check if this admission is new-bound (has input digest) or legacy
        let admission_event = prefix
            .events
            .iter()
            .find(|e| matches!(e, vb_storage::JournalEvent::RunAdmission { .. }))
            .ok_or(RuntimeError::Recovery {
                error: "recovery: admission event not found in journal events".to_string(),
            })?;

        if !crate::recovery::admission_is_new_bound(admission_event) {
            // Legacy unbound admission - no retained inputs expected
            return Ok(None);
        }

        // New-bound admission - retained inputs required
        let record = journal.run_inputs(run)?.ok_or(RuntimeError::Recovery {
            error: format!(
                "recovery: retained input record missing for new-bound run {:?}",
                run
            ),
        })?;

        crate::recovery::validate_input_record_binding(&record, run, admission_event)?;
        crate::recovery::validate_input_record_artifact(
            &record,
            prefix.admission.artifact_digest(),
        )?;
        crate::recovery::validate_input_record_workflow(&record, &recovered.workflow)?;

        Ok(Some(record))
    }

    fn recovery_storage_journal(&self) -> RuntimeResult<std::sync::Arc<vb_storage::FjallJournal>> {
        self.journal
            .storage_journal()
            .ok_or(RuntimeError::RecoveryNotAvailable)
    }

    fn load_recovery_prefix_evidence(
        journal: &vb_storage::FjallJournal,
        run: RunId,
    ) -> RuntimeResult<RecoveryPrefixEvidence> {
        let events = Self::load_recovery_events(journal, run)?;
        let seed = Self::recover_frame_seed_from_events(&events)?;
        let workflow_digest = Self::recovery_workflow_digest(&seed)?;
        let next_seq = Self::next_recovery_sequence(&seed.summary())?;
        let admission = crate::recovery::hydrate_run_admission_from_events(&events).ok_or(
            RuntimeError::RecoveryCannotResume {
                reason: String::from("admission_missing"),
            },
        )?;
        Ok(RecoveryPrefixEvidence {
            events,
            admission,
            workflow_digest,
            next_seq,
        })
    }

    fn load_recovery_events(
        journal: &vb_storage::FjallJournal,
        run: RunId,
    ) -> RuntimeResult<Vec<vb_storage::JournalEvent>> {
        journal
            .events_for_run_full(run)
            .map_err(|error| RuntimeError::Recovery {
                error: error.to_string(),
            })
    }

    /// Reconstructs a typed [`vb_storage::recovery::RecoveryFrameSeedProduct`]
    /// from the durable event slice.
    ///
    /// **FINDING-002 typestate closure.** This helper no longer accepts
    /// the raw [`vb_storage::recovery::RecoveryFrameSeed`] DTO. It threads
    /// the storage-classified typestate product into the runtime
    /// `RecoveredSeedProductContext`, so the storage
    /// `RecoveryCannotResumeState` witness survives into
    /// `RuntimeRecoveryProduct::CannotResume { reason }` without being
    /// erased by a raw-DTO roundtrip. The internal call uses
    /// `recover_runtime_frame_seed_from_events` (the non-`_raw_` entry
    /// point) so the storage layer performs the cannot-resume/resumable
    /// classification once and the runtime reuses that classification.
    fn recover_frame_seed_from_events(
        events: &[vb_storage::JournalEvent],
    ) -> RuntimeResult<vb_storage::recovery::RecoveryFrameSeedProduct> {
        vb_storage::recovery::recover_runtime_frame_seed_from_events(events).map_err(|error| {
            RuntimeError::Recovery {
                error: error.to_string(),
            }
        })
    }

    fn recovery_workflow_digest(
        seed: &vb_storage::recovery::RecoveryFrameSeedProduct,
    ) -> RuntimeResult<WorkflowDigest> {
        seed.summary()
            .workflow
            .ok_or(RuntimeError::RecoveryCannotResume {
                reason: String::from("workflow_digest_missing_from_recovery_summary"),
            })
    }

    fn next_recovery_sequence(
        summary: &vb_storage::recovery::RecoveryRuntimeSummary,
    ) -> RuntimeResult<vb_storage::EventSeq> {
        summary
            .last_seq
            .get()
            .checked_add(1)
            .map(vb_storage::EventSeq::new)
            .ok_or_else(|| RuntimeError::from(vb_storage::JournalError::SequenceOverflow))
    }

    fn validate_recovery_admission(
        run: RunId,
        runtime_policy: vb_core::RuntimePolicy,
        prefix: &RecoveryPrefixEvidence,
        recovered: &RecoveryArtifactWorkflow,
    ) -> RuntimeResult<()> {
        crate::recovery::validate_recovered_admission_evidence(
            crate::recovery::RecoveredAdmissionEvidence {
                context: crate::recovery::RecoveredAdmissionContext {
                    run,
                    expected_workflow: prefix.workflow_digest,
                    runtime_policy,
                },
                admission: &prefix.admission,
                artifact: &recovered.artifact,
                workflow: &recovered.workflow,
            },
        )
    }

    fn build_runtime_recovery_product(
        &self,
        run: RunId,
        prefix: RecoveryPrefixEvidence,
        recovered: RecoveryArtifactWorkflow,
        retained_inputs: Option<vb_storage::RunInputsRecord>,
    ) -> RuntimeResult<crate::recovery::RuntimeRecoveryProduct> {
        let expected = crate::recovery::action_abi_digests_from_contracts(
            &recovered.artifact.action_contracts,
        )?;
        let seed = Self::recover_seed_for_loaded_workflow(&prefix.events, &recovered.workflow)?;
        let boundary = Self::recovered_boundary_from_events(
            &seed,
            &prefix.events,
            &recovered.workflow,
            &expected,
        )?;
        // Enforce receipt-only reconciliation for recovered registered actions:
        // a pending registered action must be reconciliable from the durable
        // receipt before the run is allowed to resume (no live re-execution).
        self.validate_registered_recovery(&recovered.artifact, boundary)?;
        Self::product_from_recovered_seed(run, prefix, seed, boundary, retained_inputs)
    }

    /// Reconstructs a typed [`vb_storage::recovery::RecoveryFrameSeedProduct`]
    /// for a workflow-aware replay path.
    ///
    /// **FINDING-002 typestate closure.** Uses the typed entry point
    /// `recover_runtime_frame_seed_from_events_with_workflow` so the
    /// storage-classified cannot-resume/resumable product is the source
    /// of truth; the runtime never sees the raw DTO.
    fn recover_seed_for_loaded_workflow(
        events: &[vb_storage::JournalEvent],
        workflow: &CompiledWorkflow,
    ) -> RuntimeResult<vb_storage::recovery::RecoveryFrameSeedProduct> {
        vb_storage::recovery::recover_runtime_frame_seed_from_events_with_workflow(events, workflow)
            .map_err(|error| RuntimeError::Recovery {
                error: error.to_string(),
            })
    }

    /// Builds the recovered live-run boundary from the typed seed product.
    ///
    /// Takes the typed [`vb_storage::recovery::RecoveryFrameSeedProduct`]
    /// and deref-coerces to `&RecoveryFrameSeed` for the legacy
    /// `pending_action_ticket_from_events` / `recovered_run_boundary_from_seed`
    /// helpers, which still consume the raw DTO shape. The typed witness
    /// survives in the context for `product_from_recovered_context`.
    fn recovered_boundary_from_events(
        seed: &vb_storage::recovery::RecoveryFrameSeedProduct,
        events: &[vb_storage::JournalEvent],
        workflow: &CompiledWorkflow,
        expected: &[(vb_core::ActionId, WorkflowDigest)],
    ) -> RuntimeResult<crate::recovery::RecoveredRunBoundary> {
        let pending_action = crate::recovery::pending_action_ticket_from_events(
            seed.seed(),
            events,
            workflow,
            expected,
        )?;
        Ok(crate::recovery::recovered_run_boundary_from_seed(
            seed.seed(),
            pending_action,
            workflow,
            events,
        ))
    }

    fn product_from_recovered_seed(
        run: RunId,
        prefix: RecoveryPrefixEvidence,
        seed: vb_storage::recovery::RecoveryFrameSeedProduct,
        boundary: crate::recovery::RecoveredRunBoundary,
        retained_inputs: Option<vb_storage::RunInputsRecord>,
    ) -> RuntimeResult<crate::recovery::RuntimeRecoveryProduct> {
        let context = RecoveredSeedProductContext {
            run,
            prefix,
            seed,
            boundary,
        };
        Self::product_from_recovered_context(context, retained_inputs)
    }

    fn product_from_recovered_context(
        context: RecoveredSeedProductContext,
        retained_inputs: Option<vb_storage::RunInputsRecord>,
    ) -> RuntimeResult<crate::recovery::RuntimeRecoveryProduct> {
        let cannot_resume =
            crate::recovery::classify_full_recovery_resume(context.seed.seed(), context.boundary);
        if !cannot_resume.is_resumable() {
            return Ok(crate::recovery::RuntimeRecoveryProduct::cannot_resume(
                context.seed.summary(),
                cannot_resume,
            ));
        }
        // Terminal-lifecycle gate: a run whose latest terminal evidence (RunFailed /
        // RunFinished / RunCancelled / RunKilled) belongs to its current attempt must not be
        // silently re-driven by automatic cold recovery. The next-attempt RetryCheckpoint is
        // evidence only until an explicit `retry` drives `recover_retry` (a separate path).
        if crate::recovery::run_is_currently_terminal(&context.prefix.events) {
            return Ok(
                crate::recovery::RuntimeRecoveryProduct::cannot_resume_terminal(
                    context.seed.summary(),
                ),
            );
        }
        Self::resumable_product_from_recovered_context(context, retained_inputs)
    }

    fn resumable_product_from_recovered_context(
        context: RecoveredSeedProductContext,
        retained_inputs: Option<vb_storage::RunInputsRecord>,
    ) -> RuntimeResult<crate::recovery::RuntimeRecoveryProduct> {
        let initial_inputs = retained_inputs
            .as_ref()
            .map(|record| record.inputs().to_vec());
        let frame = crate::recovery::hydrate_frame_for_full_recovery_with_inputs(
            context.seed.seed(),
            context.boundary,
            initial_inputs,
        )?;
        let collect_states = Self::hydrate_recovered_collect_states(&context.prefix.events)?;
        Ok(crate::recovery::RuntimeRecoveryProduct::resumable(
            crate::recovery::ResumableRecoveryProduct::new(
                crate::recovery::ResumableRecoveryParts {
                    run: context.run,
                    summary: context.seed.summary(),
                    frame,
                    artifact_digest: context.prefix.admission.artifact_digest(),
                    workflow_digest: context.prefix.workflow_digest,
                    next_seq: context.prefix.next_seq,
                    collect_states,
                    boundary: context.boundary,
                },
            ),
        ))
    }

    fn hydrate_recovered_collect_states(
        events: &[vb_storage::JournalEvent],
    ) -> RuntimeResult<crate::primitives::collect::CollectStates> {
        crate::primitives::collect::hydrate_collect_states_from_recovered_journal(events).map_err(
            |_| RuntimeError::RecoveryCannotResume {
                reason: String::from("collect_states_missing"),
            },
        )
    }

    fn enqueue_recovered_product(
        &self,
        product: crate::recovery::ResumableRecoveryProduct,
    ) -> RuntimeResult<()> {
        let run = product.run_id();
        let command = product.into_recover_command();
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Recover {
            command: Box::new(command),
        })
    }

    fn load_recovery_artifact_and_workflow(
        &self,
        journal: std::sync::Arc<vb_storage::FjallJournal>,
        artifact_digest: WorkflowDigest,
    ) -> RuntimeResult<RecoveryArtifactWorkflow> {
        use crate::admission::AcceptedArtifactStore;

        let store = crate::admission::StorageArtifactStore::with_catalog(
            journal,
            self.journal.executor_catalog(),
        );
        let artifact = store
            .load_accepted_artifact(artifact_digest)
            .map_err(|error| RuntimeError::RecoveryCannotResume {
                reason: match error {
                    crate::admission::ArtifactEnvelopeError::ArtifactNotFound { .. } => {
                        String::from("artifact_missing")
                    }
                    _ => String::from("artifact_decode_failed"),
                },
            })?;
        let parts = postcard::from_bytes::<vb_core::workflow::WorkflowParts>(&artifact.ir)
            .map_err(|error| RuntimeError::Recovery {
                error: error.to_string(),
            })?;
        let workflow =
            CompiledWorkflow::try_from_parts(parts).map_err(|error| RuntimeError::Recovery {
                error: error.to_string(),
            })?;
        Ok(RecoveryArtifactWorkflow { artifact, workflow })
    }

    /// Inspects run state.
    pub fn inspect_run(&self, run: RunId, correlation: u64) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        shard.enqueue(ShardCommand::Inspect { run, correlation })
    }

    /// Returns a direct, non-queued run snapshot from the owning shard.
    pub fn snapshot_run(&self, run: RunId, correlation: u64) -> RuntimeResult<InspectResponse> {
        let shard = self.shard_for(run)?;
        Ok(shard.snapshot_run(run, correlation))
    }

    #[must_use]
    pub fn pending_boundary_snapshot(
        &self,
        max_items_per_shard: usize,
    ) -> RuntimePendingBoundarySnapshot {
        let mut shards = Vec::with_capacity(self.shards.len());
        let mut totals = RuntimePendingBoundaryTotals::default();
        for (index, shard) in self.shards.iter().enumerate() {
            let snapshot =
                shard.pending_boundary_snapshot(shard_id_from_index(index), max_items_per_shard);
            totals.add_shard(&snapshot);
            shards.push(snapshot);
        }
        RuntimePendingBoundarySnapshot::new(shards.into_boxed_slice(), totals)
    }

    /// Processes one command on each shard. Returns false if any shard is shutting down.
    pub fn tick_all(&mut self) -> RuntimeResult<bool> {
        let mut alive = true;
        for shard in &mut self.shards {
            if !shard.tick()? {
                alive = false;
            }
        }
        Ok(alive)
    }

    /// Processes one tick on a specific shard with the given directive.
    ///
    /// This method directs a single shard's behavior for one tick. The directive
    /// determines what work the shard performs:
    ///
    /// - `Continue`: Process one command from the queue normally.
    /// - `Suspend`: Skip command processing; preserve queue depth.
    /// - `Migrate { target }`: Transfer all pending commands to the target shard.
    /// - `Shutdown`: Drain all remaining commands and shut down the shard.
    ///
    /// Returns `Ok(true)` if the shard is alive (continuing), `Ok(false)` if the
    /// shard has shut down, or an error if the shard index is invalid or migration
    /// failed.
    pub fn tick_shard(
        &mut self,
        shard_index: u32,
        directive: ShardDirective,
    ) -> RuntimeResult<bool> {
        let shard_index_usize = usize::try_from(shard_index)
            .map_err(|_| RuntimeError::ShardNotFound { shard: shard_index })?;

        // Validate source shard exists first
        if self.shards.get(shard_index_usize).is_none() {
            return Err(RuntimeError::ShardNotFound { shard: shard_index });
        }

        match directive {
            ShardDirective::Continue => {
                let shard = self
                    .shards
                    .get_mut(shard_index_usize)
                    .ok_or(RuntimeError::ShardNotFound { shard: shard_index })?;
                shard.tick()
            }
            ShardDirective::Suspend => {
                // Suspend: skip processing, preserve queue, return alive
                Ok(true)
            }
            ShardDirective::Migrate { target } => self.migrate_shard(shard_index_usize, target),
            ShardDirective::Shutdown => {
                let shard = self
                    .shards
                    .get_mut(shard_index_usize)
                    .ok_or(RuntimeError::ShardNotFound { shard: shard_index })?;
                shard.drain_pending_and_shutdown()?;
                Ok(false)
            }
            ShardDirective::Cancel => Err(RuntimeError::UnsupportedOperation {
                operation: "tick_shard_cancel",
            }),
            ShardDirective::Barrier => Err(RuntimeError::UnsupportedOperation {
                operation: "tick_shard_barrier",
            }),
        }
    }

    /// Migrates all commands from source shard to target shard.
    ///
    /// Returns `Ok(true)` if the source shard is still alive (has runs or pending commands),
    /// `Ok(false)` if the source shard is empty and can be shut down.
    fn migrate_shard(&mut self, source_idx: usize, target: u32) -> RuntimeResult<bool> {
        let target_usize =
            usize::try_from(target).map_err(|_| RuntimeError::ShardNotFound { shard: target })?;

        // Self-migrate check (already validated in caller, but double-check for safety)
        let source_u32 =
            u32::try_from(source_idx).map_err(|_| RuntimeError::ShardNotFound { shard: target })?;
        if target == source_u32 {
            return Err(RuntimeError::MigrateSelf);
        }

        // Validate target shard exists (already validated in caller, but double-check)
        if self.shards.get(target_usize).is_none() {
            return Err(RuntimeError::ShardNotFound { shard: target });
        }

        // Collect all commands from source shard
        let commands: Vec<ShardCommand> = {
            let shard = self
                .shards
                .get_mut(source_idx)
                .ok_or(RuntimeError::ShardNotFound { shard: source_u32 })?;
            let mut cmds = Vec::new();
            while let Some(cmd) = shard.command_queue.pop() {
                cmds.push(cmd);
            }
            cmds
        };

        // Push all commands to target shard
        {
            let target_shard = self
                .shards
                .get_mut(target_usize)
                .ok_or(RuntimeError::ShardNotFound { shard: target })?;
            for cmd in commands {
                target_shard.enqueue(cmd)?;
            }
        }

        // Return true if source shard still has runs (alive)
        let shard = self
            .shards
            .get_mut(source_idx)
            .ok_or(RuntimeError::ShardNotFound { shard: source_u32 })?;
        let alive = shard.active_run_count() > 0 || !shard.command_queue.is_empty();
        Ok(alive)
    }

    /// Completes an action for a run.
    pub fn complete_action(&self, run: RunId, step: StepIdx) -> RuntimeResult<()> {
        let shard = self.shard_for(run)?;
        if let Some(ticket) = self.lookup_pending_action_ticket(run, u64::from(step.get())) {
            shard.reject_unregistered_completion(ticket)?;
        }
        shard.enqueue(ShardCommand::ActionCompletedLegacy { run, step })
    }

    /// Completes an action for a run with its typed output payload.
    ///
    /// Validates the ticket against the current run state before enqueuing.
    /// Returns `InvalidActionCompletion` if the ticket is invalid (wrong action,
    /// non-running step, or stale attempt).
    pub fn complete_action_with_output(
        &mut self,
        ticket: ActionTicket,
        output: ActionOutputReady,
    ) -> RuntimeResult<()> {
        let shard = self.shard_for_mut(ticket.run)?;
        shard.reject_unregistered_completion(ticket)?;
        // Validate ticket before enqueuing — fail fast with InvalidActionCompletion
        // if the ticket doesn't match the current run state.
        if let Some(state) = shard.run_state_get(ticket.run) {
            crate::shard::lifecycle::preflight_action_completion(state, ticket, output)?;
        }
        shard.enqueue(ShardCommand::ActionCompleted { ticket, output })
    }

    /// Fails an action with a typed failure payload.
    pub fn fail_action(&self, ticket: ActionTicket, failure: ActionFailure) -> RuntimeResult<()> {
        let shard = self.shard_for(ticket.run)?;
        shard.enqueue(ShardCommand::RuntimeActionFailed { ticket, failure })
    }

    /// Looks up the canonical in-flight action ticket for `run`.
    ///
    /// IPC handlers receive only a `(run_id, ticket: u64)` wire pair. The wire
    /// `ticket` encodes only the lower-16-bit step index and does not carry the
    /// real `seq`, `action`, `attempt`, `idempotency_key`, or `capacity`
    /// values. The canonical ticket is held by the shard's `pending_actions`
    /// index and is the only authoritative source of those fields.
    ///
    /// Returns `None` if:
    /// - the run is not found,
    /// - the run has no in-flight action ticket,
    /// - the wire `ticket`'s lower 16 bits do not match the canonical step.
    ///
    /// This lookup is the boundary that prevents the IPC layer from
    /// fabricating dummy `seq`/`action`/`idempotency_key`/`capacity` fields
    /// (see bead vb-xb62s). Callers must fail closed if this returns `None`
    /// and must never invent fields the wire did not carry.
    #[must_use]
    pub fn lookup_pending_action_ticket(
        &self,
        run: RunId,
        ticket_wire: u64,
    ) -> Option<vb_core::action::ActionTicket> {
        let shard = self.shard_for_run(run).ok()?;
        let canonical = shard.pending_action_get(run)?;
        let wire_step = u16::try_from(ticket_wire).ok()?;
        if canonical.step.get() != wire_step {
            return None;
        }
        Some(canonical)
    }

    /// Looks up the opaque authority for the run's currently suspended Ask boundary.
    ///
    /// The ticket is issued only from the shard's current Asking state and its
    /// journal-backed AskScheduled boundary. A stale or unknown boundary returns
    /// `None`; callers must not construct or alter ticket fields themselves.
    #[must_use]
    pub fn lookup_pending_ask_ticket(
        &self,
        run: RunId,
        ask_step: vb_core::ids::StepIdx,
    ) -> Option<crate::shard::AskTicket> {
        self.shard_for_run(run)
            .ok()?
            .pending_ask_ticket(run, ask_step)
    }

    /// Lists trace events for a run without draining the shard trace ring.
    ///
    /// RA-030 wave-15 (vb-sxkz6): a run may have been migrated to a shard
    /// other than the home shard selected by the hash of `RunId`. Scan all
    /// shards so the trace ring of the owning shard is read.
    pub fn list_events(&self, run: RunId) -> RuntimeResult<Vec<TraceEvent>> {
        let shard = self.shard_for_run(run)?;
        let limit = shard.trace_ring().capacity();
        Ok(shard.trace_ring().snapshot_for_run(run, limit))
    }

    /// Answers an ask with an explicit typed payload and resume ticket.
    ///
    /// RA-030: a run may have been migrated to a shard other than the home
    /// shard selected by the hash of `RunId` (see `migrate_shard` / RA-021).
    /// Test the home shard first as a fast path, then scan the remaining
    /// shards for active or terminal ownership so the answer is routed to
    /// whichever shard actually holds the run state.
    pub fn answer_ask(&self, answer: AskAnswer) -> RuntimeResult<()> {
        let run = answer.ticket.run();
        let shard = self.shard_for_run(run)?;
        shard.validate_pending_ask_answer(answer)?;
        shard.enqueue(ShardCommand::AskAnswered { answer })
    }

    /// Legacy run-only timer delivery is fail-closed because it carries no authority.
    pub fn timer_fired(&self, run: RunId) -> RuntimeResult<()> {
        let _shard = self.shard_for_run(run)?;
        Err(RuntimeError::InvalidTimerFire)
    }

    /// Captures the current timer authority for tests and typed scheduler handoff.
    ///
    /// RA-030 wave-15 (vb-sxkz6): scans all shards for the run's timer entry.
    /// Returns `Err(RuntimeError::RunNotFound)` if no shard owns the run.
    /// Returns `Err(RuntimeError::InvalidTimerFire)` when the owner shard has
    /// no live timer entry for the run.
    pub fn capture_timer_entry(&self, run: RunId) -> RuntimeResult<TimerEntry> {
        let shard = self.shard_for_run(run)?;
        shard.timer_entry(run).ok_or(RuntimeError::InvalidTimerFire)
    }

    /// Advances a run from a timer-wheel-captured authority entry.
    ///
    /// RA-030 wave-15 (vb-sxkz6): scans all shards for the run owner.
    pub fn timer_entry_fired(&self, entry: TimerEntry) -> RuntimeResult<()> {
        let shard = self.shard_for_run(entry.run)?;
        shard.enqueue(ShardCommand::TimerFired {
            run: entry.run,
            generation: entry.generation,
            deadline: entry.deadline,
            kind: entry.kind,
        })
    }

    /// Takes the latest inspect response from the run's shard.
    ///
    /// RA-030 wave-15 (vb-sxkz6): scans all shards for the run owner.
    pub fn take_inspect_response(&mut self, run: RunId) -> RuntimeResult<Option<InspectResponse>> {
        let shard = self.shard_for_run_mut(run)?;
        Ok(shard.take_inspect_response())
    }

    /// Drains all trace events from all shards.
    pub fn drain_trace(&mut self) -> Vec<TraceEvent> {
        let mut events = Vec::new();
        for shard in &mut self.shards {
            let capacity = shard.trace_ring_mut().capacity();
            shard.trace_ring_mut().drain_into(capacity, &mut events);
        }
        events
    }

    /// Collects runtime metrics from all shards.
    pub fn collect_metrics(&self) -> RuntimeMetricsSnapshot {
        let mut shards = Vec::with_capacity(self.shard_count);
        let mut runs_active = 0u32;
        let mut runs_waiting = 0u32;
        let mut runs_failed_total = 0u64;
        let mut runs_finished_total = 0u64;
        let mut steps_total = 0u64;

        for (index, shard) in self.shards.iter().enumerate() {
            let counters = shard.counters().snapshot();
            let active_runs = u32::try_from(shard.active_run_count()).unwrap_or(u32::MAX);
            let queue_depth = u32::try_from(shard.command_queue_len()).unwrap_or(u32::MAX);
            let queue_remaining = u32::try_from(shard.remaining_capacity()).unwrap_or(u32::MAX);
            let pending_timers = u32::try_from(shard.pending_timer_count()).unwrap_or(u32::MAX);
            let (fp_free, fp_total) = shard.frame_pool_metrics();
            let frame_pool_free = u32::try_from(fp_free).unwrap_or(u32::MAX);
            let frame_pool_total = u32::try_from(fp_total).unwrap_or(u32::MAX);
            let trace_capacity = shard.trace_ring().capacity();
            let trace_len = shard.trace_ring().pending_len();
            let trace_ring_fill_pct = if trace_capacity > 0 {
                // Bounded narrowing mirrors the six sibling metric lines at runtime.rs:571-577.
                // TraceRing::new clamps capacity to >= 1 (RA-003 cap bound 2^20 << 2^24), so the
                // unwrap_or(0) fallback is unreachable in production. Fallback value is 0 (not
                // u32::MAX) to preserve the sentinel intent of the outer zero-denominator guard.
                //
                // DEVIATION FROM CONTRACT INV-004: `f32::from(u32)` is NOT implemented in
                // Rust (only `From<u8|u16|i8|i16>` exist for f32). See `u32_to_f32_exact`
                // above for the bit-equivalent IEEE-754 manual encoding; equivalence to
                // `(n as f32)` is verified in `.beads/vb-oul6u/evidence/ieee-754-bit-equivalence.log`
                // and pinned by the RA-003 corpus (`trace_ring_fill_pct` tests, 3/3 pass).
                let cap_u32 = u32::try_from(trace_capacity).unwrap_or(0);
                let len_u32 = u32::try_from(trace_len).unwrap_or(0);
                let len_f32 = u32_to_f32_exact(len_u32);
                let cap_f32 = u32_to_f32_exact(cap_u32);
                (len_f32 / cap_f32) * 100.0
            } else {
                0.0
            };

            runs_active = runs_active.saturating_add(active_runs);
            runs_waiting = runs_waiting.saturating_add(pending_timers);
            runs_failed_total = runs_failed_total.saturating_add(counters.runs_failed);
            runs_finished_total = runs_finished_total.saturating_add(counters.runs_completed);
            steps_total = steps_total.saturating_add(counters.steps_executed);

            let shard_id = u32::try_from(index).unwrap_or(u32::MAX);
            shards.push(ShardMetricsSnapshot {
                shard_id,
                active_runs,
                command_queue_depth: queue_depth,
                command_queue_remaining: queue_remaining,
                pending_timers,
                frame_pool_free,
                frame_pool_total,
                trace_ring_fill_pct,
                counters,
            });
        }

        RuntimeMetricsSnapshot {
            shards,
            runs_active,
            runs_waiting,
            runs_failed_total,
            runs_finished_total,
            steps_total,
        }
    }

    /// Returns aggregated counter snapshots from all shards.
    pub fn counters_snapshot(&self) -> CounterSnapshot {
        let mut total = CounterSnapshot {
            runs_submitted: 0,
            runs_completed: 0,
            runs_failed: 0,
            steps_executed: 0,
        };
        for shard in &self.shards {
            let snap = shard.counters().snapshot();
            total.runs_submitted = total.runs_submitted.saturating_add(snap.runs_submitted);
            total.runs_completed = total.runs_completed.saturating_add(snap.runs_completed);
            total.runs_failed = total.runs_failed.saturating_add(snap.runs_failed);
            total.steps_executed = total.steps_executed.saturating_add(snap.steps_executed);
        }
        total
    }

    /// Lists active run summaries across all shards, up to `limit` entries.
    ///
    /// If `workflow_filter` is provided, only runs matching that digest are included.
    /// Returns summaries sorted by run id ascending.
    pub fn list_active_runs(
        &self,
        limit: u32,
        workflow_filter: Option<vb_core::WorkflowDigest>,
    ) -> Vec<ActiveRunSummary> {
        let max = match usize::try_from(limit) {
            Ok(value) => value,
            Err(_) => usize::MAX,
        };
        let mut summaries = Vec::new();
        for shard in &self.shards {
            for (run_id, state) in shard.active_runs_iter() {
                if summaries.len() >= max {
                    break;
                }
                let digest = state.workflow.digest();
                if let Some(filter) = workflow_filter
                    && digest != filter
                {
                    continue;
                }
                let step_count = state.workflow.node_count();
                let mut steps_completed: u16 = 0;
                let mut step_index = 0u16;
                while step_index < step_count {
                    let step = vb_core::ids::StepIdx::new(step_index);
                    match state.frame.step_state(step) {
                        Ok(
                            vb_core::frame::StepState::Succeeded
                            | vb_core::frame::StepState::Failed
                            | vb_core::frame::StepState::Skipped
                            | vb_core::frame::StepState::Cancelled,
                        ) => {
                            steps_completed = steps_completed.saturating_add(1);
                        }
                        Ok(_) => {}
                        Err(_) => {
                            step_index = step_index.saturating_add(1);
                            continue;
                        }
                    }
                    step_index = step_index.saturating_add(1);
                }
                summaries.push(ActiveRunSummary {
                    run_id: *run_id,
                    workflow: digest,
                    step_count,
                    steps_completed,
                });
            }
        }
        summaries.sort_by_key(|s| s.run_id);
        summaries.truncate(max);
        summaries
    }

    /// Stops command processing and durably drains the owned journal.
    ///
    /// Suspended runs remain owned by their shards. The report preserves their
    /// boundary authorities before timer registrations are released. On failure
    /// those registrations remain available for inspection and retry.
    pub fn shutdown_graceful(&mut self) -> Result<ShutdownReport, ShutdownFailure> {
        shutdown::shutdown(self)
    }

    fn shard_index(&self, run: RunId) -> usize {
        let hash = run.get();
        let Ok(count) = u64::try_from(self.shard_count) else {
            return 0;
        };
        let Some(remainder) = hash.checked_rem(count) else {
            return 0;
        };
        let Ok(index) = usize::try_from(remainder) else {
            return 0;
        };
        index
    }

    fn shard_for(&self, run: RunId) -> Result<&Shard, RuntimeError> {
        let index = self.shard_index(run);
        self.shards.get(index).ok_or(RuntimeError::RunNotFound)
    }

    fn shard_for_mut(&mut self, run: RunId) -> Result<&mut Shard, RuntimeError> {
        let index = self.shard_index(run);
        self.shards.get_mut(index).ok_or(RuntimeError::RunNotFound)
    }

    /// Returns the shard that currently owns `run`, scanning all shards.
    ///
    /// RA-030 wave-15 (vb-sxkz6): the hash-based `shard_index(run)` returns
    /// the home shard which may differ from the owner after `migrate_shard`
    /// transfers a run's commands and run-state to a different shard. We
    /// check the home shard first as a fast path; on miss we scan the
    /// remaining shards in deterministic slice order.
    ///
    /// Returns `Err(RuntimeError::RunNotFound)` if `run` is not in any
    /// shard's `run_state` or `terminal_runs` set.
    fn shard_for_run(&self, run: RunId) -> Result<&Shard, RuntimeError> {
        let home_index = self.shard_index(run);
        if let Some(shard) = self.shards.get(home_index)
            && (shard.run_state_contains(run) || shard.terminal_runs_contains(run))
        {
            return Ok(shard);
        }
        self.shards
            .iter()
            .enumerate()
            .find(|(idx, shard)| {
                *idx != home_index
                    && (shard.run_state_contains(run) || shard.terminal_runs_contains(run))
            })
            .map(|(_, shard)| shard)
            .ok_or(RuntimeError::RunNotFound)
    }

    /// Mutable variant of `shard_for_run` for `take_inspect_response`.
    fn shard_for_run_mut(&mut self, run: RunId) -> Result<&mut Shard, RuntimeError> {
        // Mirror the home-fast-path + scan-fallback logic on immutable borrow,
        // then re-index after borrow ends to get the mutable shard.
        let home_index = self.shard_index(run);
        let owner_index = {
            if let Some(shard) = self.shards.get(home_index)
                && (shard.run_state_contains(run) || shard.terminal_runs_contains(run))
            {
                home_index
            } else {
                self.shards
                    .iter()
                    .position(|shard| {
                        shard.run_state_contains(run) || shard.terminal_runs_contains(run)
                    })
                    .ok_or(RuntimeError::RunNotFound)?
            }
        };
        self.shards
            .get_mut(owner_index)
            .ok_or(RuntimeError::RunNotFound)
    }
}

#[path = "runtime/registered_executor.rs"]
mod registered_executor;
#[cfg(test)]
#[path = "runtime_tests.rs"]
mod tests;
pub use registered_executor::RegisteredExecutionError;

#[cfg(test)]
#[path = "runtime/shutdown_tests.rs"]
mod shutdown_tests;
