#![forbid(unsafe_code)]
//! Tests for untested YamlError variants and branch coverage.
//!
//! These tests exist because the test-reviewer density audit found
//! YamlError variants and parsing branches without exact-assertion coverage.
//!
//! Target: 5x density (215 tests / 43 pub fns).

use crate::parse_workflow_source;
use crate::yaml_ast::types::TriggerAst;
use crate::yaml_error::YamlError;
use crate::yaml_events::{EventSpan, ScalarStyle, YamlEvent};
use crate::yaml_profile::reject_anchors_aliases_merges;
use crate::yaml_profile::{reject_forbidden_features, validate_yaml_profile};

fn assertion_failed(_message: std::fmt::Arguments<'_>) -> bool {
    false
}

macro_rules! fail_assert {
    ($($arg:tt)*) => {
        assert!(assertion_failed(format_args!($($arg)*)), $($arg)*)
    };
}

// ---------------------------------------------------------------------------
// YamlError variant smoke tests — variants defined but not fully exercised
// ---------------------------------------------------------------------------

/// `BinaryScalar` is defined but the actual rejection path runs through
/// `CustomTag` (the tag check in reject_forbidden_features). We test the
/// variant exists and formats correctly.
#[test]
fn yaml_error_binary_scalar_variant_exists() {
    let err = YamlError::BinaryScalar;
    let msg = err.to_string();
    assert!(
        msg.contains("binary"),
        "BinaryScalar error message should mention 'binary', got: {msg}"
    );
}

/// `UnsupportedFeature` is defined but no current code path returns it
/// (check_null_bytes returns ForbiddenFeature instead). We test the variant
/// exists and formats correctly.
#[test]
fn yaml_error_unsupported_feature_variant_exists() {
    let err = YamlError::UnsupportedFeature {
        feature: "some_feature",
    };
    let msg = err.to_string();
    assert!(
        msg.contains("some_feature"),
        "UnsupportedFeature message should contain feature name, got: {msg}"
    );
}

// ---------------------------------------------------------------------------
// ForbiddenFeature — null byte in source (scalar-level path unreachable)
// ---------------------------------------------------------------------------

/// `check_null_bytes_in_source` runs before scalar parsing and returns
/// `ForbiddenFeature { detail: "null_byte_in_source" }` for any null byte
/// in the raw source text. The scalar-level path
/// (`null_byte_in_scalar`) is unreachable through normal YAML parsing
/// because saphyr validates source text before building scalar values.
#[test]
fn forbidden_feature_null_byte_in_source_rejected() {
    let yaml = "key: \"has\x00null\"\n";
    let result = validate_yaml_profile(yaml);
    assert!(
        matches!(
            result,
            Err(YamlError::ForbiddenFeature {
                detail: "null_byte_in_source"
            })
        ),
        "expected ForbiddenFeature(null_byte_in_source), got: {result:?}"
    );
}

// ---------------------------------------------------------------------------
// FieldShape — non-string mapping keys in inputs / vars / result
// ---------------------------------------------------------------------------

/// `parse_inputs` returns `FieldShape { field: "inputs key", expected: "string" }`
/// when a key in the inputs mapping is not a string (e.g., integer).
#[test]
fn field_shape_inputs_key_not_string() {
    let yaml = r#"version: velvet-ballistics/v1
name: test
when: { manual: {} }
inputs:
  123: string
steps: []
"#;
    let result = parse_workflow_source(yaml);
    assert_eq!(
        result,
        Err(YamlError::FieldShape {
            field: "inputs key",
            expected: "string"
        })
    );
}

/// `parse_vars` returns `FieldShape { field: "vars key", expected: "string" }`
/// when a key in the vars mapping is not a string.
#[test]
fn field_shape_vars_key_not_string() {
    let yaml = r#"version: velvet-ballistics/v1
name: test
when: { manual: {} }
vars:
  456: "value"
steps: []
"#;
    let result = parse_workflow_source(yaml);
    assert_eq!(
        result,
        Err(YamlError::FieldShape {
            field: "vars key",
            expected: "string"
        })
    );
}

/// `parse_result` returns `FieldShape { field: "result key", expected: "string" }`
/// when a key in the result mapping is not a string.
#[test]
fn field_shape_result_key_not_string() {
    let yaml = r#"version: velvet-ballistics/v1
name: test
when: { manual: {} }
steps: []
result:
  789: "some value"
"#;
    let result = parse_workflow_source(yaml);
    assert_eq!(
        result,
        Err(YamlError::FieldShape {
            field: "result key",
            expected: "string"
        })
    );
}

// ---------------------------------------------------------------------------
// ParseError — malformed YAML
// ---------------------------------------------------------------------------

/// `parse_workflow_ast` returns `ParseError` when the YAML document is
/// syntactically malformed (e.g., mismatched brackets).
#[test]
fn parse_error_for_malformed_yaml() {
    // Mismatched flow indicators — saphyr reports this as a parse error.
    let yaml = "key: [1, 2\n";
    let result = parse_workflow_source(yaml);
    match result {
        Err(YamlError::ParseError { line, reason }) => {
            assert!(line > 0, "ParseError line should be > 0, got {line}");
            assert!(!reason.is_empty(), "ParseError reason should be non-empty");
        }
        other => fail_assert!("expected ParseError, got {other:?}"),
    }
}

/// `parse_workflow_source` surfaces `ParseError` for unclosed strings.
#[test]
fn parse_error_unclosed_double_quote() {
    let yaml = "key: \"unclosed\n";
    let result = parse_workflow_source(yaml);
    match result {
        Err(YamlError::ParseError { line, .. }) => {
            assert!(line > 0, "ParseError line should be > 0, got {line}");
        }
        other => fail_assert!("expected ParseError, got {other:?}"),
    }
}

#[test]
fn raw_yaml_event_trigger_parses_type_field() {
    let source = "version: velvet-ballistics/v1\nname: test\nwhen:\n  event:\n    type: job.created\nsteps: []\n";

    assert_eq!(
        parse_workflow_source(source).map(|workflow| workflow.trigger().clone()),
        Ok(TriggerAst::Event {
            event_type: "job.created".to_owned(),
        })
    );
}

#[test]
fn raw_yaml_event_trigger_rejects_invalid_shapes_with_exact_paths() {
    let cases = [
        (
            "missing type",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  event: {}\nsteps: []\n",
            YamlError::MissingField {
                field: "when.event.type",
            },
        ),
        (
            "scalar body",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  event: job.created\nsteps: []\n",
            YamlError::FieldShape {
                field: "when.event",
                expected: "mapping",
            },
        ),
        (
            "non-string type",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  event:\n    type: 42\nsteps: []\n",
            YamlError::FieldShape {
                field: "when.event.type",
                expected: "non-empty string",
            },
        ),
        (
            "empty type",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  event:\n    type: ''\nsteps: []\n",
            YamlError::FieldShape {
                field: "when.event.type",
                expected: "non-empty string",
            },
        ),
        (
            "extra event field",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  event:\n    type: job.created\n    name: legacy\nsteps: []\n",
            YamlError::UnknownField {
                field: "name".into(),
            },
        ),
        (
            "unknown trigger",
            "version: velvet-ballistics/v1\nname: test\nwhen:\n  queue: {}\nsteps: []\n",
            YamlError::UnknownField {
                field: "queue".into(),
            },
        ),
    ];

    for (case, source, expected) in cases {
        assert_eq!(parse_workflow_source(source), Err(expected), "case: {case}");
    }
}

// ---------------------------------------------------------------------------
// Merge-key detection via reject_anchors_aliases_merges
// ---------------------------------------------------------------------------

/// In `reject_anchors_aliases_merges`, a Scalar event with anchor_id == 0
/// and a merge key tag (yaml.org/2002:merge) is rejected as AnchorAliasMerge.
#[test]
fn reject_anchors_aliases_merges_rejects_yaml_org_merge_via_scalar() {
    // Scalar with yaml.org/2002:merge tag, zero anchor_id → merge key path
    let events = &[YamlEvent::Scalar {
        value: "<<".into(),
        style: ScalarStyle::Plain,
        anchor_id: 0,
        tag: Some("tag:yaml.org,2002:merge".into()),
        span: EventSpan {
            start: 0,
            end: 2,
            line: 1,
            column: 1,
        },
    }];
    let result = reject_anchors_aliases_merges(events);
    assert_eq!(result, Err(YamlError::AnchorAliasMerge));
}

/// In `reject_anchors_aliases_merges`, a Scalar event with anchor_id == 0
/// and a !!merge tag is rejected as AnchorAliasMerge.
#[test]
fn reject_anchors_aliases_merges_rejects_double_bang_merge_via_scalar() {
    // Scalar with !!merge tag, zero anchor_id → merge key path
    let events = &[YamlEvent::Scalar {
        value: "<<".into(),
        style: ScalarStyle::Plain,
        anchor_id: 0,
        tag: Some("!!merge".into()),
        span: EventSpan {
            start: 0,
            end: 2,
            line: 1,
            column: 1,
        },
    }];
    let result = reject_anchors_aliases_merges(events);
    assert_eq!(result, Err(YamlError::AnchorAliasMerge));
}

// ---------------------------------------------------------------------------
// is_allowed_tag branch coverage
// ---------------------------------------------------------------------------

/// Allowed yaml.org/2002:str tag suffix passes through
/// `reject_forbidden_features` without error.
#[test]
fn is_allowed_tag_accepts_yaml_org_2002_str() {
    let events = &[YamlEvent::Scalar {
        value: "hello".into(),
        style: ScalarStyle::Plain,
        anchor_id: 0,
        tag: Some("tag:yaml.org,2002:str".into()),
        span: EventSpan {
            start: 0,
            end: 5,
            line: 1,
            column: 1,
        },
    }];
    let result = reject_forbidden_features(events);
    assert_eq!(result, Ok(()));
}

/// Allowed !!int tag suffix passes through
/// `reject_forbidden_features` without error.
#[test]
fn is_allowed_tag_accepts_double_bang_int() {
    let events = &[YamlEvent::Scalar {
        value: "42".into(),
        style: ScalarStyle::Plain,
        anchor_id: 0,
        tag: Some("!!int".into()),
        span: EventSpan {
            start: 0,
            end: 2,
            line: 1,
            column: 1,
        },
    }];
    let result = reject_forbidden_features(events);
    assert_eq!(result, Ok(()));
}

/// A custom tag on a sequence (e.g., !seq) is rejected as CustomTag
/// by `reject_forbidden_features` (not BinaryScalar, even though it could
/// theoretically be a binary tag — the actual binary-scalar path is a no-op).
#[test]
fn forbidden_feature_custom_tag_on_sequence_rejected() {
    let yaml = "items: !seq\n  - a\n";
    let result = validate_yaml_profile(yaml);
    match result {
        Err(YamlError::CustomTag { tag }) => {
            assert!(tag.contains("seq"), "expected 'seq' in tag, got: {tag}");
        }
        other => fail_assert!("expected CustomTag, got {other:?}"),
    }
}

/// A custom tag on a mapping (e.g., !map) is rejected as CustomTag.
#[test]
fn forbidden_feature_custom_tag_on_mapping_rejected() {
    let yaml = "data: !map\n  k: v\n";
    let result = validate_yaml_profile(yaml);
    match result {
        Err(YamlError::CustomTag { tag }) => {
            assert!(tag.contains("map"), "expected 'map' in tag, got: {tag}");
        }
        other => fail_assert!("expected CustomTag, got {other:?}"),
    }
}
