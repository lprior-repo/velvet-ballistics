#![allow(
    clippy::as_conversions,
    clippy::cast_possible_truncation,
    clippy::expect_used,
    clippy::indexing_slicing,
    clippy::panic,
    clippy::panic_in_result_fn,
    clippy::unwrap_used
)]
use super::*;
use crate::{
    BlobRecord, CompiledIrRecord, EventSeq, IndexStatusState, JournalError, JournalEvent,
    RunHeaderRecord, WorkflowSourceRecord, constants::*, recovery::RunSnapshot,
};
use vb_core::{RunId, SlotIdx, StepIdx, WorkflowDigest, WorkflowId};

fn temp_journal() -> (tempfile::TempDir, FjallJournal) {
    let temp = tempfile::tempdir().expect("tempdir creation should succeed");
    let journal = FjallJournal::open(temp.path(), None).expect("journal open should succeed");
    (temp, journal)
}

fn make_event(run: RunId, seq: u64) -> JournalEvent {
    JournalEvent::RunAccepted {
        run,
        seq: EventSeq::new(seq),
        workflow: WorkflowDigest::from_bytes([0; DIGEST_BYTES]),
    }
}

fn make_step_started(run: RunId, seq: u64, step: u16) -> JournalEvent {
    JournalEvent::StepStarted {
        run,
        seq: EventSeq::new(seq),
        step: StepIdx::new(step),
        attempt: 1,
    }
}

fn corrupt_magic_preserving_crc(value: &mut [u8]) {
    let magic_bytes = 0xDEAD_BEEFu32.to_le_bytes();
    if let Some(slice) = value.get_mut(0..4) {
        slice.copy_from_slice(&magic_bytes);
    }
    let checksum = crc32c::crc32c(&value[..CRC_OFFSET]);
    let crc_bytes = checksum.to_le_bytes();
    if let Some(slice) = value.get_mut(CRC_OFFSET..CRC_OFFSET.saturating_add(4)) {
        slice.copy_from_slice(&crc_bytes);
    }
}

fn accepted_artifact_record_for_source(
    source_digest: WorkflowDigest,
) -> Result<CompiledIrRecord, JournalError> {
    let zero_digest = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);
    let mut artifact = crate::admission::AcceptedArtifact {
        digest: zero_digest,
        source_digest,
        policy_digest: WorkflowDigest::from_bytes([0xA5; DIGEST_BYTES]),
        ir: b"compiled ir payload".to_vec(),
        verification: crate::admission::VerificationProof::new(zero_digest, 15, false),
        accepted_at_seq: EventSeq::new(0),
        required_capabilities: Box::new([]),
        action_contracts: Box::new([]),
    };
    let digest = crate::admission::accepted_artifact_digest(&artifact)?;
    artifact.digest = digest;
    artifact.verification.digest = digest;
    let ir = postcard::to_allocvec(&artifact).map_err(JournalError::PostcardEncodeFailed)?;
    Ok(CompiledIrRecord { digest, ir })
}

// =========================================================================
// Write/read round-trip tests
// =========================================================================

#[test]
fn workflow_source_roundtrip() {
    let (_temp, journal) = temp_journal();
    let source = b"workflow: hello_world".to_vec();
    let digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let record = WorkflowSourceRecord {
        digest,
        source: source.clone(),
    };
    journal
        .put_workflow_source(&record)
        .expect("put should succeed");
    let loaded = journal.workflow_source(digest).expect("get should succeed");
    let Some(found) = loaded else {
        panic!("workflow source should be found");
    };
    assert_eq!(found.source, source);
    assert_eq!(found.digest, digest);
}

#[test]
fn workflow_source_returns_none_for_missing_digest() {
    let (_temp, journal) = temp_journal();
    let missing = WorkflowDigest::from_bytes([0xFF; DIGEST_BYTES]);
    let result = journal
        .workflow_source(missing)
        .expect("lookup should succeed");
    assert_eq!(result, None, "missing digest should return None");
}

#[test]
fn compiled_ir_roundtrip() {
    let (_temp, journal) = temp_journal();
    let ir = b"compiled-artifact-bytes".to_vec();
    let digest = WorkflowDigest::from_bytes(blake3::hash(&ir).into());
    let record = CompiledIrRecord {
        digest,
        ir: ir.clone(),
    };
    journal
        .put_compiled_ir(&record)
        .expect("put should succeed");
    let loaded = journal.compiled_ir(digest).expect("get should succeed");
    let Some(found) = loaded else {
        panic!("compiled IR should be found");
    };
    assert_eq!(found.ir, ir);
}

#[test]
fn compiled_ir_returns_none_for_missing_digest() {
    let (_temp, journal) = temp_journal();
    let missing = WorkflowDigest::from_bytes([0x00; DIGEST_BYTES]);
    let result = journal.compiled_ir(missing).expect("lookup should succeed");
    assert_eq!(result, None, "missing digest should return None");
}

#[test]
fn run_header_roundtrip() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(12345);
    let digest = WorkflowDigest::from_bytes([0xAB; DIGEST_BYTES]);
    let record = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(7),
        compiled_digest: digest,
        status: 2,
        accepted_at_ms: 1700000000000,
    };
    journal.put_run_header(&record).expect("put should succeed");
    let loaded = journal.run_header(run).expect("get should succeed");
    let Some(found) = loaded else {
        panic!("run header should be found");
    };
    assert_eq!(found.run, run);
    assert_eq!(found.workflow_id, WorkflowId::new(7));
    assert_eq!(found.status, 2);
    assert_eq!(found.accepted_at_ms, 1700000000000);
}

#[test]
fn run_header_returns_none_for_missing_run() {
    let (_temp, journal) = temp_journal();
    let result = journal
        .run_header(RunId::new(999))
        .expect("lookup should succeed");
    assert_eq!(result, None, "missing run should return None");
}

#[test]
fn snapshot_roundtrip() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(55);
    let workflow = WorkflowDigest::from_bytes([0x55; DIGEST_BYTES]);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(10),
        workflow,
        slots: vec![0u8, 1u8],
        taint: vec![0u8, 0u8],
    };
    journal.put_snapshot(&snapshot).expect("put should succeed");
    let loaded = journal
        .snapshot(run, EventSeq::new(10))
        .expect("get should succeed");
    let Some(found) = loaded else {
        panic!("snapshot should be found");
    };
    assert_eq!(found.run, run);
    assert_eq!(found.seq, EventSeq::new(10));
    assert_eq!(found.slots.len(), 2);
    assert_eq!(found.workflow, workflow);
}

#[test]
fn blob_roundtrip() {
    let (_temp, journal) = temp_journal();
    let payload = vec![0xCA, 0xFE, 0xBA, 0xBE];
    let digest: [u8; DIGEST_BYTES] = blake3::hash(&payload).into();
    let record = BlobRecord {
        digest,
        bytes: payload.clone(),
    };
    journal.put_blob(&record).expect("put should succeed");
    let loaded = journal.blob(digest).expect("get should succeed");
    let Some(found) = loaded else {
        panic!("blob should be found");
    };
    assert_eq!(found.bytes, payload);
}

#[test]
fn blob_returns_none_for_missing_digest() {
    let (_temp, journal) = temp_journal();
    let result = journal
        .blob([0; DIGEST_BYTES])
        .expect("lookup should succeed");
    assert_eq!(result, None, "missing blob should return None");
}

#[test]
fn blob_rejects_digest_mismatch() {
    let (_temp, journal) = temp_journal();
    let payload = vec![1, 2, 3];
    let wrong_digest: [u8; DIGEST_BYTES] = [0xFF; DIGEST_BYTES];
    let record = BlobRecord {
        digest: wrong_digest,
        bytes: payload,
    };
    let result = journal.put_blob(&record);
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "digest mismatch must be rejected, got {:?}",
        result
    );
}

#[test]
fn workflow_source_read_rejects_payload_digest_not_matching_requested_key() {
    let (_temp, journal) = temp_journal();
    let requested_source = b"requested workflow".to_vec();
    let requested_digest = WorkflowDigest::from_bytes(blake3::hash(&requested_source).into());
    let stored_source = b"stored under the wrong key".to_vec();
    let stored_digest = WorkflowDigest::from_bytes(blake3::hash(&stored_source).into());
    let record = WorkflowSourceRecord {
        digest: stored_digest,
        source: stored_source,
    };
    let key = crate::keys::workflow_source_key(requested_digest.as_bytes())
        .expect("workflow source key should encode");
    let value = crate::codec::encode_record(
        MAGIC_WORKFLOW_SOURCE,
        crate::RecordKind::WorkflowSource,
        0,
        &record,
        MAX_WORKFLOW_SOURCE_BYTES,
    )
    .expect("forged workflow source envelope should encode");
    journal
        .workflow_source
        .insert(key.to_vec(), value)
        .expect("raw corrupt workflow source insert should succeed");

    let result = journal.workflow_source(requested_digest);

    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "workflow source read must rebind requested digest key, got {result:?}"
    );
}

#[test]
fn workflow_source_read_rejects_tampered_source_when_record_digest_matches_key() {
    let (_temp, journal) = temp_journal();
    let trusted_source = b"trusted workflow source".to_vec();
    let requested_digest = WorkflowDigest::from_bytes(blake3::hash(&trusted_source).into());
    let record = WorkflowSourceRecord {
        digest: requested_digest,
        source: b"tampered workflow source".to_vec(),
    };
    let key = crate::keys::workflow_source_key(requested_digest.as_bytes())
        .expect("workflow source key should encode");
    let value = crate::codec::encode_record(
        MAGIC_WORKFLOW_SOURCE,
        crate::RecordKind::WorkflowSource,
        0,
        &record,
        MAX_WORKFLOW_SOURCE_BYTES,
    )
    .expect("forged workflow source envelope should encode");
    journal
        .workflow_source
        .insert(key.to_vec(), value)
        .expect("raw tampered workflow source insert should succeed");

    let result = journal.workflow_source(requested_digest);

    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "workflow source read must hash source bytes even when record digest matches key, got {result:?}"
    );
}

#[test]
fn compiled_ir_read_rejects_payload_content_not_matching_digest() {
    let (_temp, journal) = temp_journal();
    let trusted_ir = b"trusted compiled ir".to_vec();
    let digest = WorkflowDigest::from_bytes(blake3::hash(&trusted_ir).into());
    let record = CompiledIrRecord {
        digest,
        ir: b"tampered compiled ir".to_vec(),
    };
    let key = crate::keys::compiled_ir_key(digest.as_bytes()).expect("compiled ir key encodes");
    let value = crate::codec::encode_record(
        MAGIC_COMPILED_ARTIFACT,
        crate::RecordKind::CompiledIr,
        0,
        &record,
        MAX_COMPILED_IR_BYTES,
    )
    .expect("forged compiled ir envelope should encode");
    journal
        .compiled_ir
        .insert(key.to_vec(), value)
        .expect("raw corrupt compiled ir insert should succeed");

    let result = journal.compiled_ir(digest);

    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "compiled IR read must verify decoded content digest, got {result:?}"
    );
}

#[test]
fn compiled_ir_for_source_digest_rejects_scanned_key_record_digest_mismatch() {
    let (_temp, journal) = temp_journal();
    let source_digest = WorkflowDigest::from_bytes([0x66; DIGEST_BYTES]);
    let record = accepted_artifact_record_for_source(source_digest)
        .expect("accepted artifact should encode");
    let wrong_key_digest = WorkflowDigest::from_bytes([0x99; DIGEST_BYTES]);
    let key = crate::keys::compiled_ir_key(wrong_key_digest.as_bytes())
        .expect("compiled ir key should encode");
    let value = crate::codec::encode_record(
        MAGIC_COMPILED_ARTIFACT,
        crate::RecordKind::CompiledIr,
        0,
        &record,
        MAX_COMPILED_IR_BYTES,
    )
    .expect("forged compiled ir envelope should encode");
    journal
        .compiled_ir
        .insert(key.to_vec(), value)
        .expect("raw compiled ir insert should succeed");

    let result = journal.compiled_ir_for_source_digest(source_digest);

    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "compiled_ir_for_source_digest must validate scanned key↔record digest before source match, got {result:?}"
    );
}

#[test]
fn blob_read_rejects_payload_content_not_matching_digest() {
    let (_temp, journal) = temp_journal();
    let trusted_bytes = b"trusted blob".to_vec();
    let digest: [u8; DIGEST_BYTES] = blake3::hash(&trusted_bytes).into();
    let record = BlobRecord {
        digest,
        bytes: b"tampered blob".to_vec(),
    };
    let key = crate::keys::blob_key(digest).expect("blob key encodes");
    let value = crate::codec::encode_record(
        MAGIC_BLOB,
        crate::RecordKind::Blob,
        0,
        &record,
        MAX_BLOB_BYTES,
    )
    .expect("forged blob envelope should encode");
    journal
        .blob
        .insert(key.to_vec(), value)
        .expect("raw corrupt blob insert should succeed");

    let result = journal.blob(digest);

    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "blob read must verify decoded content digest, got {result:?}"
    );
}

#[test]
fn snapshot_read_rejects_payload_sequence_not_matching_requested_key() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(77);
    let requested_seq = EventSeq::new(3);
    let stored_seq = EventSeq::new(4);
    let snapshot = RunSnapshot {
        run,
        seq: stored_seq,
        workflow: WorkflowDigest::from_bytes([0x77; DIGEST_BYTES]),
        slots: vec![1, 2, 3],
        taint: vec![0],
    };
    let key = crate::keys::run_snapshot_key(run, requested_seq).expect("snapshot key encodes");
    let value = crate::codec::encode_record(
        MAGIC_SNAPSHOT,
        crate::RecordKind::Snapshot,
        stored_seq.get(),
        &snapshot,
        MAX_SNAPSHOT_BYTES,
    )
    .expect("forged snapshot envelope should encode");
    journal
        .run_snapshot
        .insert(key.to_vec(), value)
        .expect("raw corrupt snapshot insert should succeed");

    let result = journal.snapshot(run, requested_seq);

    assert!(
        matches!(
            result,
            Err(JournalError::SequenceGap {
                expected,
                actual
            }) if expected == requested_seq && actual == stored_seq
        ),
        "snapshot read must rebind requested (run, seq) key, got {result:?}"
    );
}

#[test]
fn snapshot_read_rejects_envelope_only_sequence_mismatch_with_exact_fields() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(78);
    let seq = EventSeq::new(5);
    let envelope_seq = 9005;
    let snapshot = RunSnapshot {
        run,
        seq,
        workflow: WorkflowDigest::from_bytes([0x78; DIGEST_BYTES]),
        slots: vec![1, 2, 3],
        taint: vec![0],
    };
    let key = crate::keys::run_snapshot_key(run, seq).expect("snapshot key encodes");
    let value = crate::codec::encode_record(
        MAGIC_SNAPSHOT,
        crate::RecordKind::Snapshot,
        envelope_seq,
        &snapshot,
        MAX_SNAPSHOT_BYTES,
    )
    .expect("forged snapshot envelope should encode");
    journal
        .run_snapshot
        .insert(key.to_vec(), value)
        .expect("raw snapshot insert should succeed");

    let result = journal.snapshot(run, seq);

    match result {
        Err(JournalError::ReplayEnvelopeSequenceMismatch {
            run: got_run,
            envelope_seq: got_envelope_seq,
            payload_seq,
        }) => {
            assert_eq!(got_run, run);
            assert_eq!(got_envelope_seq, envelope_seq);
            assert_eq!(payload_seq, seq.get());
        }
        other => panic!(
            "snapshot envelope-only mismatch must return exact ReplayEnvelopeSequenceMismatch, got {other:?}"
        ),
    }
}

#[test]
fn run_header_read_rejects_payload_run_not_matching_requested_key() {
    let (_temp, journal) = temp_journal();
    let requested_run = RunId::new(81);
    let stored_run = RunId::new(82);
    let record = RunHeaderRecord {
        run: stored_run,
        workflow_id: WorkflowId::new(7),
        compiled_digest: WorkflowDigest::from_bytes([0x82; DIGEST_BYTES]),
        status: 2,
        accepted_at_ms: 1700000000000,
    };
    let key = crate::keys::run_header_key(requested_run).expect("run header key encodes");
    let value = crate::codec::encode_record(
        MAGIC_INDEX_RECORD,
        crate::RecordKind::RunHeader,
        stored_run.get(),
        &record,
        MAX_RUN_HEADER_BYTES,
    )
    .expect("forged run header envelope should encode");
    journal
        .run_header
        .insert(key.to_vec(), value)
        .expect("raw corrupt run header insert should succeed");

    let result = journal.run_header(requested_run);

    assert!(
        matches!(
            result,
            Err(JournalError::WrongRun { expected, actual })
                if expected == requested_run && actual == stored_run
        ),
        "run header read must rebind requested run key, got {result:?}"
    );
}

#[test]
fn run_header_read_rejects_envelope_only_sequence_mismatch_with_exact_fields() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(83);
    let envelope_seq = 9083;
    let record = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(7),
        compiled_digest: WorkflowDigest::from_bytes([0x83; DIGEST_BYTES]),
        status: 2,
        accepted_at_ms: 1700000000000,
    };
    let key = crate::keys::run_header_key(run).expect("run header key encodes");
    let value = crate::codec::encode_record(
        MAGIC_INDEX_RECORD,
        crate::RecordKind::RunHeader,
        envelope_seq,
        &record,
        MAX_RUN_HEADER_BYTES,
    )
    .expect("forged run header envelope should encode");
    journal
        .run_header
        .insert(key.to_vec(), value)
        .expect("raw run header insert should succeed");

    let result = journal.run_header(run);

    match result {
        Err(JournalError::ReplayEnvelopeSequenceMismatch {
            run: got_run,
            envelope_seq: got_envelope_seq,
            payload_seq,
        }) => {
            assert_eq!(got_run, run);
            assert_eq!(got_envelope_seq, envelope_seq);
            assert_eq!(payload_seq, run.get());
        }
        other => panic!(
            "run_header envelope-only mismatch must return exact ReplayEnvelopeSequenceMismatch, got {other:?}"
        ),
    }
}

#[test]
fn run_headers_scan_rejects_payload_run_not_matching_scanned_key() {
    let (_temp, journal) = temp_journal();
    let key_run = RunId::new(91);
    let payload_run = RunId::new(92);
    let record = RunHeaderRecord {
        run: payload_run,
        workflow_id: WorkflowId::new(9),
        compiled_digest: WorkflowDigest::from_bytes([0x92; DIGEST_BYTES]),
        status: 2,
        accepted_at_ms: 1700000000000,
    };
    let key = crate::keys::run_header_key(key_run).expect("run header key encodes");
    let value = crate::codec::encode_record(
        MAGIC_INDEX_RECORD,
        crate::RecordKind::RunHeader,
        payload_run.get(),
        &record,
        MAX_RUN_HEADER_BYTES,
    )
    .expect("forged run header envelope should encode");
    journal
        .run_header
        .insert(key.to_vec(), value)
        .expect("raw corrupt run header insert should succeed");

    let result = journal.run_headers();

    assert!(
        matches!(
            result,
            Err(JournalError::WrongRun { expected, actual })
                if expected == key_run && actual == payload_run
        ),
        "run_headers scan must rebind scanned key to payload, got {result:?}"
    );
}

#[test]
fn run_headers_scan_rejects_envelope_only_sequence_mismatch_with_exact_fields() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(93);
    let envelope_seq = 9093;
    let record = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(9),
        compiled_digest: WorkflowDigest::from_bytes([0x93; DIGEST_BYTES]),
        status: 2,
        accepted_at_ms: 1700000000000,
    };
    let key = crate::keys::run_header_key(run).expect("run header key encodes");
    let value = crate::codec::encode_record(
        MAGIC_INDEX_RECORD,
        crate::RecordKind::RunHeader,
        envelope_seq,
        &record,
        MAX_RUN_HEADER_BYTES,
    )
    .expect("forged run header envelope should encode");
    journal
        .run_header
        .insert(key.to_vec(), value)
        .expect("raw run header insert should succeed");

    let result = journal.run_headers();

    match result {
        Err(JournalError::ReplayEnvelopeSequenceMismatch {
            run: got_run,
            envelope_seq: got_envelope_seq,
            payload_seq,
        }) => {
            assert_eq!(got_run, run);
            assert_eq!(got_envelope_seq, envelope_seq);
            assert_eq!(payload_seq, run.get());
        }
        other => panic!(
            "run_headers scan envelope-only mismatch must return exact ReplayEnvelopeSequenceMismatch, got {other:?}"
        ),
    }
}

// =========================================================================
// Keyspace isolation — different run IDs don't interfere
// =========================================================================

#[test]
fn events_for_run_isolates_different_runs() {
    let (_temp, journal) = temp_journal();
    let run_a = RunId::new(100);
    let run_b = RunId::new(200);

    // Write events for run A
    let events_a = [make_event(run_a, 0), make_step_started(run_a, 1, 0)];
    journal
        .append_strict_batch(&events_a)
        .expect("batch A should succeed");

    // Write events for run B
    let events_b = [
        make_event(run_b, 0),
        make_step_started(run_b, 1, 0),
        make_step_started(run_b, 2, 1),
    ];
    journal
        .append_strict_batch(&events_b)
        .expect("batch B should succeed");

    // Replay run A: should only get run A events
    let replayed_a = journal
        .events_for_run(run_a)
        .expect("replay A should succeed");
    assert_eq!(replayed_a.len(), 2, "run A should have exactly 2 events");
    for event in &replayed_a {
        assert_eq!(event.run_id(), run_a, "replayed event must belong to run A");
    }

    // Replay run B: should only get run B events
    let replayed_b = journal
        .events_for_run(run_b)
        .expect("replay B should succeed");
    assert_eq!(replayed_b.len(), 3, "run B should have exactly 3 events");
    for event in &replayed_b {
        assert_eq!(event.run_id(), run_b, "replayed event must belong to run B");
    }
}

#[test]
fn run_headers_isolate_different_runs() {
    let (_temp, journal) = temp_journal();
    let run_a = RunId::new(10);
    let run_b = RunId::new(20);
    let digest = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);

    journal
        .put_run_header(&RunHeaderRecord {
            run: run_a,
            workflow_id: WorkflowId::new(1),
            compiled_digest: digest,
            status: 1,
            accepted_at_ms: 100,
        })
        .expect("put A should succeed");

    journal
        .put_run_header(&RunHeaderRecord {
            run: run_b,
            workflow_id: WorkflowId::new(2),
            compiled_digest: digest,
            status: 2,
            accepted_at_ms: 200,
        })
        .expect("put B should succeed");

    let header_a = journal
        .run_header(run_a)
        .expect("get A should succeed")
        .expect("A present");
    let header_b = journal
        .run_header(run_b)
        .expect("get B should succeed")
        .expect("B present");

    assert_eq!(header_a.workflow_id, WorkflowId::new(1));
    assert_eq!(header_a.status, 1);
    assert_eq!(header_b.workflow_id, WorkflowId::new(2));
    assert_eq!(header_b.status, 2);
}

#[test]
fn snapshots_isolate_different_runs() {
    let (_temp, journal) = temp_journal();
    let run_a = RunId::new(50);
    let run_b = RunId::new(60);
    let workflow = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);

    journal
        .put_snapshot(&RunSnapshot {
            run: run_a,
            seq: EventSeq::new(1),
            workflow,
            slots: vec![0u8],
            taint: vec![],
        })
        .expect("put A should succeed");

    journal
        .put_snapshot(&RunSnapshot {
            run: run_b,
            seq: EventSeq::new(1),
            workflow,
            slots: vec![1u8, 2u8, 3u8],
            taint: vec![0u8],
        })
        .expect("put B should succeed");

    let snap_a = journal
        .snapshot(run_a, EventSeq::new(1))
        .expect("get A")
        .expect("present");
    let snap_b = journal
        .snapshot(run_b, EventSeq::new(1))
        .expect("get B")
        .expect("present");

    assert_eq!(snap_a.run, run_a);
    assert_eq!(snap_a.slots.len(), 1);
    assert_eq!(snap_b.run, run_b);
    assert_eq!(snap_b.slots.len(), 3);
}

// =========================================================================
// Sequential event ordering
// =========================================================================

#[test]
fn events_for_run_returns_events_in_sequence_order() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(300);

    let events: Vec<JournalEvent> = (0..5)
        .map(|i| JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(i),
            step: StepIdx::new(i as u16),
            attempt: 1,
        })
        .collect();
    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");

    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), 5);
    for (i, event) in replayed.iter().enumerate() {
        assert_eq!(
            event.seq().get(),
            i as u64,
            "event at index {} should have seq {}",
            i,
            i
        );
    }
}

#[test]
fn events_for_run_rejects_sequence_gap() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(400);

    // Write seq 0 and seq 2 (gap at seq 1)
    let e0 = make_event(run, 0);
    let e2 = make_event(run, 2);
    journal.append_unfsynced(&e0).expect("append 0");
    journal.append_unfsynced(&e2).expect("append 2");

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::SequenceGap { .. })),
        "sequence gap must be detected during replay, got {:?}",
        result
    );
}

#[test]
fn events_for_run_returns_empty_for_unknown_run() {
    let (_temp, journal) = temp_journal();
    let result = journal
        .events_for_run(RunId::new(99999))
        .expect("replay should succeed");
    assert_eq!(result.len(), 0, "unknown run should have zero events");
}

// =========================================================================
// Duplicate event rejection
// =========================================================================

#[test]
fn append_strict_rejects_duplicate_event() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(500);
    let event = make_event(run, 0);

    journal
        .append_strict(&event)
        .expect("first append should succeed");
    let result = journal.append_strict(&event);
    assert!(
        matches!(result, Err(JournalError::DuplicateEvent { .. })),
        "duplicate event must be rejected, got {:?}",
        result
    );
}

#[test]
fn append_journaled_succeeds_and_is_readable() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(600);
    let event = make_event(run, 0);

    journal
        .append_journaled(&event)
        .expect("append_journaled should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), 1);
    assert_eq!(replayed[0], event);
}

#[test]
fn append_journaled_rejects_invalid_event_without_persisting() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(601);
    let event = JournalEvent::StepStarted {
        run,
        seq: EventSeq::new(0),
        step: StepIdx::new(1),
        attempt: 0,
    };

    let result = journal.append_journaled(&event);

    assert!(
        matches!(result, Err(JournalError::InvalidEvent)),
        "invalid event must be rejected before storage, got {:?}",
        result
    );
    assert_eq!(
        journal
            .get_event_bytes(run, EventSeq::new(0))
            .expect("query"),
        None
    );
}

#[test]
fn append_strict_batch_rejects_invalid_event_without_partial_commit() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(602);
    let events = [
        make_event(run, 0),
        JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(1),
            step: StepIdx::new(1),
            attempt: 0,
        },
    ];

    let result = journal.append_strict_batch(&events);

    assert!(
        matches!(result, Err(JournalError::InvalidEvent)),
        "invalid batch event must fail closed, got {:?}",
        result
    );
    assert_eq!(
        journal
            .get_event_bytes(run, EventSeq::new(0))
            .expect("query seq0"),
        None
    );
    assert_eq!(
        journal
            .get_event_bytes(run, EventSeq::new(1))
            .expect("query seq1"),
        None
    );
}

#[test]
fn append_strict_batch_writes_all_events() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(700);
    let events = [
        make_event(run, 0),
        make_step_started(run, 1, 0),
        JournalEvent::RunFinished {
            run,
            seq: EventSeq::new(2),
            result: SlotIdx::new(0),
            attempt: 1,
        },
    ];
    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), 3);
    assert_eq!(replayed[0], events[0]);
    assert_eq!(replayed[1], events[1]);
    assert_eq!(replayed[2], events[2]);
}

#[test]
fn append_strict_batch_on_empty_is_ok() {
    let (_temp, journal) = temp_journal();
    let result = journal.append_strict_batch(&[]);
    assert!(result.is_ok(), "empty batch should succeed");
}

// =========================================================================
// Declared keyspaces
// =========================================================================

#[test]
fn declared_keyspaces_count_matches_opened_keyspaces() {
    let declared = FjallJournal::declared_keyspaces();
    assert_eq!(declared.len(), 11, "there should be 11 declared keyspaces");
    let (_temp, _journal) = temp_journal();
    // If we got here, all keyspaces opened successfully
}

// =========================================================================
// Verify content digest
// =========================================================================

#[test]
fn verify_content_digest_accepts_valid() {
    let content = b"some bytes";
    let hash = blake3::hash(content);
    let result = verify_content_digest(content, hash.as_bytes());
    assert!(result.is_ok(), "valid content digest should pass");
}

#[test]
fn verify_content_digest_rejects_mismatch() {
    let content = b"some bytes";
    let wrong = blake3::hash(b"other bytes");
    let result = verify_content_digest(content, wrong.as_bytes());
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "mismatched digest should fail"
    );
}

// =========================================================================
// Multiple event types round-trip through journal
// =========================================================================

#[test]
fn all_event_variant_roundtrip_through_journal() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(800);
    let digest = WorkflowDigest::from_bytes([0xBB; DIGEST_BYTES]);

    let events = [
        JournalEvent::RunAccepted {
            run,
            seq: EventSeq::new(0),
            workflow: digest,
        },
        JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(1),
            step: StepIdx::new(0),
            attempt: 1,
        },
        JournalEvent::ActionScheduled {
            run,
            seq: EventSeq::new(2),
            step: StepIdx::new(0),
            action: vb_core::ActionId::new(1),
            attempt: 1,
        },
        JournalEvent::SlotWrittenEvent {
            run,
            seq: EventSeq::new(3),
            slot: SlotIdx::new(0),
            value: None,
            extra: None,
            attempt: 1,
        },
        JournalEvent::ActionCompletedEvent {
            run,
            seq: EventSeq::new(4),
            step: StepIdx::new(0),
            action: vb_core::ActionId::new(1),
            attempt: 1,
        },
        JournalEvent::ActionFailedEvent {
            run,
            seq: EventSeq::new(5),
            step: StepIdx::new(1),
            action: vb_core::ActionId::new(2),
            attempt: 1,
        },
        JournalEvent::WaitScheduledEvent {
            run,
            seq: EventSeq::new(6),
            step: StepIdx::new(1),
            attempt: 1,
        },
        JournalEvent::AskScheduledEvent {
            run,
            seq: EventSeq::new(7),
            step: StepIdx::new(2),
            attempt: 1,
        },
        JournalEvent::AskAnsweredEvent {
            run,
            seq: EventSeq::new(8),
            step: StepIdx::new(2),
            attempt: 1,
        },
        JournalEvent::RetryScheduledEvent {
            run,
            seq: EventSeq::new(9),
            step: StepIdx::new(1),
            attempt: 1,
        },
        JournalEvent::RunCancelled {
            run,
            seq: EventSeq::new(10),
            attempt: 1,
            reason: None,
        },
    ];

    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), events.len());
    for (i, (original, replayed_event)) in events.iter().zip(replayed.iter()).enumerate() {
        assert_eq!(original, replayed_event, "event at index {} mismatch", i);
    }
}

// =========================================================================
// put_workflow_source with valid and invalid digests
// =========================================================================

#[test]
fn workflow_source_rejects_digest_mismatch() {
    let (_temp, journal) = temp_journal();
    let source = b"workflow: real content".to_vec();
    let wrong_digest = WorkflowDigest::from_bytes([0xFF; DIGEST_BYTES]);
    let record = WorkflowSourceRecord {
        digest: wrong_digest,
        source,
    };
    let result = journal.put_workflow_source(&record);
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "wrong digest must be rejected, got {:?}",
        result
    );
}

#[test]
fn workflow_source_accepts_large_valid_payload() {
    let (_temp, journal) = temp_journal();
    // Build a source that is near but under the max (use 64 KiB)
    let source = vec![0x41u8; 65536];
    let digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let record = WorkflowSourceRecord {
        digest,
        source: source.clone(),
    };
    journal
        .put_workflow_source(&record)
        .expect("put should succeed for large valid payload");
    let loaded = journal.workflow_source(digest).expect("get should succeed");
    let Some(found) = loaded else {
        panic!("large workflow source should be found");
    };
    assert_eq!(found.source.len(), source.len());
    assert_eq!(found.source, source);
}

#[test]
fn workflow_source_stores_multiple_distinct_digests() {
    let (_temp, journal) = temp_journal();
    let source_a = b"workflow: a".to_vec();
    let source_b = b"workflow: b".to_vec();
    let digest_a = WorkflowDigest::from_bytes(blake3::hash(&source_a).into());
    let digest_b = WorkflowDigest::from_bytes(blake3::hash(&source_b).into());
    let record_a = WorkflowSourceRecord {
        digest: digest_a,
        source: source_a.clone(),
    };
    let record_b = WorkflowSourceRecord {
        digest: digest_b,
        source: source_b.clone(),
    };
    journal
        .put_workflow_source(&record_a)
        .expect("put A should succeed");
    journal
        .put_workflow_source(&record_b)
        .expect("put B should succeed");
    let loaded_a = journal
        .workflow_source(digest_a)
        .expect("get A should succeed")
        .expect("A present");
    let loaded_b = journal
        .workflow_source(digest_b)
        .expect("get B should succeed")
        .expect("B present");
    assert_eq!(loaded_a.source, source_a);
    assert_eq!(loaded_b.source, source_b);
}

// =========================================================================
// put_snapshot with various sequence numbers
// =========================================================================

#[test]
fn snapshot_multiple_sequences_same_run() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(100);
    let workflow = WorkflowDigest::from_bytes([0xAA; DIGEST_BYTES]);
    for seq_val in 0u64..5 {
        let snapshot = RunSnapshot {
            run,
            seq: EventSeq::new(seq_val),
            workflow,
            slots: vec![seq_val as u8],
            taint: vec![],
        };
        journal.put_snapshot(&snapshot).expect("put should succeed");
    }
    // Each snapshot should be retrievable independently
    for seq_val in 0u64..5 {
        let loaded = journal
            .snapshot(run, EventSeq::new(seq_val))
            .expect("get should succeed")
            .expect("should be present");
        assert_eq!(loaded.seq, EventSeq::new(seq_val));
        assert_eq!(loaded.slots, vec![seq_val as u8]);
    }
}

#[test]
fn snapshot_returns_none_for_missing_sequence() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(101);
    let workflow = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);
    // Write seq 0 and seq 5
    let snap0 = RunSnapshot {
        run,
        seq: EventSeq::new(0),
        workflow,
        slots: vec![],
        taint: vec![],
    };
    let snap5 = RunSnapshot {
        run,
        seq: EventSeq::new(5),
        workflow,
        slots: vec![5u8],
        taint: vec![],
    };
    journal.put_snapshot(&snap0).expect("put 0");
    journal.put_snapshot(&snap5).expect("put 5");
    // seq 3 should be missing
    let result = journal
        .snapshot(run, EventSeq::new(3))
        .expect("get should succeed");
    assert_eq!(result, None, "missing snapshot seq should return None");
    // but seq 0 and 5 are present
    assert!(
        journal
            .snapshot(run, EventSeq::new(0))
            .expect("get 0")
            .is_some()
    );
    assert!(
        journal
            .snapshot(run, EventSeq::new(5))
            .expect("get 5")
            .is_some()
    );
}

#[test]
fn snapshot_preserves_large_slots_and_taint() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(102);
    let workflow = WorkflowDigest::from_bytes([0x55; DIGEST_BYTES]);
    let slots = vec![0xAB_u8; 4096];
    let taint = vec![0x01_u8; 4096];
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(0),
        workflow,
        slots: slots.clone(),
        taint: taint.clone(),
    };
    journal.put_snapshot(&snapshot).expect("put should succeed");
    let loaded = journal
        .snapshot(run, EventSeq::new(0))
        .expect("get should succeed")
        .expect("present");
    assert_eq!(loaded.slots, slots);
    assert_eq!(loaded.taint, taint);
}

// =========================================================================
// get_run_header / put_run_header extended round-trips
// =========================================================================

#[test]
fn run_header_overwrite_updates_status() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(999);
    let digest = WorkflowDigest::from_bytes([0x01; DIGEST_BYTES]);
    let original = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(1),
        compiled_digest: digest,
        status: 1,
        accepted_at_ms: 100,
    };
    journal.put_run_header(&original).expect("put original");
    let updated = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(1),
        compiled_digest: digest,
        status: 3,
        accepted_at_ms: 100,
    };
    journal.put_run_header(&updated).expect("put updated");
    let loaded = journal
        .run_header(run)
        .expect("get should succeed")
        .expect("present");
    assert_eq!(loaded.status, 3, "status should be updated to 3");
    assert_eq!(loaded.run, run);
}

#[test]
fn run_headers_returns_all_headers_in_order() {
    let (_temp, journal) = temp_journal();
    let digest = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);
    // Insert in non-sorted order (run IDs 30, 10, 20)
    for run_id in [30u64, 10u64, 20u64] {
        let record = RunHeaderRecord {
            run: RunId::new(run_id),
            workflow_id: WorkflowId::new(run_id as u32),
            compiled_digest: digest,
            status: 1,
            accepted_at_ms: run_id,
        };
        journal.put_run_header(&record).expect("put should succeed");
    }
    let headers = journal.run_headers().expect("run_headers should succeed");
    assert_eq!(headers.len(), 3, "should have 3 headers");
    // run_headers are returned in key order (big-endian run IDs)
    let run_ids: Vec<u64> = headers.iter().map(|h| h.run.get()).collect();
    let mut sorted = run_ids.clone();
    sorted.sort();
    assert_eq!(run_ids, sorted, "headers should be in key order");
}

// =========================================================================
// Event append and sequential read edge cases
// =========================================================================

#[test]
fn append_queued_unfsynced_allows_idempotent_duplicate() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(1100);
    let event = make_event(run, 0);
    journal
        .append_queued_unfsynced(&event)
        .expect("first append should succeed");
    let result = journal.append_queued_unfsynced(&event);
    assert!(
        result.is_ok(),
        "idempotent duplicate of same event should succeed, got {:?}",
        result
    );
}

#[test]
fn append_queued_unfsynced_rejects_different_duplicate() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(1101);
    let event_a = make_event(run, 0);
    let mut event_b = make_event(run, 0);
    // Change the workflow digest so event_b differs
    if let JournalEvent::RunAccepted {
        ref mut workflow, ..
    } = event_b
    {
        *workflow = WorkflowDigest::from_bytes([0xFF; DIGEST_BYTES]);
    }
    journal
        .append_queued_unfsynced(&event_a)
        .expect("first append should succeed");
    let result = journal.append_queued_unfsynced(&event_b);
    assert!(
        matches!(result, Err(JournalError::DuplicateEvent { .. })),
        "different event at same run/seq must be rejected, got {:?}",
        result
    );
}

#[test]
fn events_for_run_with_many_events() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(1200);
    let count: u64 = 100;
    let events: Vec<JournalEvent> = (0..count)
        .map(|i| JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(i),
            step: StepIdx::new(i as u16),
            attempt: 1,
        })
        .collect();
    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), count as usize);
    for (i, event) in replayed.iter().enumerate() {
        assert_eq!(event.seq().get(), i as u64);
        assert_eq!(event.run_id(), run);
    }
}

// =========================================================================
// Status index construction
// =========================================================================

#[test]
fn status_index_stores_and_scans_markers() {
    let (_temp, journal) = temp_journal();
    let run_a = RunId::new(2000);
    let run_b = RunId::new(2001);
    // Insert status markers for different states
    journal
        .put_status_index(IndexStatusState::Active, 1000, run_a)
        .expect("status A");
    journal
        .put_status_index(IndexStatusState::Completed, 2000, run_a)
        .expect("status B");
    journal
        .put_status_index(IndexStatusState::Active, 3000, run_b)
        .expect("status C");
    // Scan the entire keyspace
    let mut count = 0usize;
    for item in journal.index_status.iter() {
        assert!(item.key().is_ok());
        count = count.saturating_add(1);
    }
    assert_eq!(count, 3, "should have 3 status index markers");
}

// =========================================================================
// Workflow and action index construction
// =========================================================================

#[test]
fn workflow_index_stores_markers() {
    let (_temp, journal) = temp_journal();
    let wf1 = WorkflowId::new(1);
    let wf2 = WorkflowId::new(2);
    let run_a = RunId::new(3000);
    let run_b = RunId::new(3001);
    journal.put_workflow_index(wf1, run_a).expect("wf idx A");
    journal.put_workflow_index(wf1, run_b).expect("wf idx B");
    journal.put_workflow_index(wf2, run_a).expect("wf idx C");
    let mut count = 0usize;
    for item in journal.index_workflow.iter() {
        assert!(item.key().is_ok());
        count = count.saturating_add(1);
    }
    assert_eq!(count, 3, "should have 3 workflow index markers");
}

#[test]
fn action_index_stores_markers() {
    let (_temp, journal) = temp_journal();
    let action1 = vb_core::ActionId::new(10);
    let action2 = vb_core::ActionId::new(20);
    let run = RunId::new(4000);
    let step_a = StepIdx::new(1);
    let step_b = StepIdx::new(2);
    journal
        .put_action_index(action1, run, step_a)
        .expect("action idx A");
    journal
        .put_action_index(action1, run, step_b)
        .expect("action idx B");
    journal
        .put_action_index(action2, run, step_a)
        .expect("action idx C");
    let mut count = 0usize;
    for item in journal.index_action.iter() {
        assert!(item.key().is_ok());
        count = count.saturating_add(1);
    }
    assert_eq!(count, 3, "should have 3 action index markers");
}

// =========================================================================
// Cross-keyspace batch operations
// =========================================================================

#[test]
fn batch_commits_across_multiple_keyspaces() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(5000);
    let digest = WorkflowDigest::from_bytes([0xCC; DIGEST_BYTES]);

    let source = b"batch workflow".to_vec();
    let source_digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let workflow_record = WorkflowSourceRecord {
        digest: source_digest,
        source,
    };

    let ir = b"batch ir".to_vec();
    let ir_digest = WorkflowDigest::from_bytes(blake3::hash(&ir).into());
    let ir_record = CompiledIrRecord {
        digest: ir_digest,
        ir,
    };

    let header = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(42),
        compiled_digest: digest,
        status: 1,
        accepted_at_ms: 9000,
    };

    let event = JournalEvent::RunAccepted {
        run,
        seq: EventSeq::new(0),
        workflow: source_digest,
    };

    let payload = vec![0xBB];
    let blob_digest: [u8; DIGEST_BYTES] = blake3::hash(&payload).into();
    let blob_record = BlobRecord {
        digest: blob_digest,
        bytes: payload,
    };

    {
        let mut batch = journal.batch();
        batch
            .put_workflow_source(&workflow_record)
            .expect("batch workflow source");
        batch
            .put_compiled_ir(&ir_record)
            .expect("batch compiled ir");
        batch.put_run_header(&header).expect("batch run header");
        batch.append_event(&event).expect("batch event");
        batch.put_blob(&blob_record).expect("batch blob");
        batch
            .put_status_index(IndexStatusState::Submitted, 100, run)
            .expect("batch status idx");
        batch
            .put_workflow_index(WorkflowId::new(42), run)
            .expect("batch workflow idx");
        batch
            .put_action_index(vb_core::ActionId::new(1), run, StepIdx::new(0))
            .expect("batch action idx");
        assert_eq!(batch.len(), 8, "batch should contain 8 operations");
        assert!(!batch.is_empty(), "batch should not be empty");
        batch.commit().expect("batch commit should succeed");
    }

    // Verify all keyspaces have the data
    assert!(
        journal
            .workflow_source(source_digest)
            .expect("get ws")
            .is_some()
    );
    assert!(journal.compiled_ir(ir_digest).expect("get ir").is_some());
    assert!(journal.run_header(run).expect("get header").is_some());
    let replayed = journal.events_for_run(run).expect("get events");
    assert_eq!(replayed.len(), 1);
    assert!(journal.blob(blob_digest).expect("get blob").is_some());
}

#[test]
fn batch_rejects_workflow_source_with_wrong_digest() {
    let (_temp, journal) = temp_journal();
    let source = b"real content".to_vec();
    let wrong_digest = WorkflowDigest::from_bytes([0xFF; DIGEST_BYTES]);
    let record = WorkflowSourceRecord {
        digest: wrong_digest,
        source,
    };
    let mut batch = journal.batch();
    let result = batch.put_workflow_source(&record);
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "batch should reject digest mismatch, got {:?}",
        result
    );
}

#[test]
fn batch_rejects_blob_with_wrong_digest() {
    let (_temp, journal) = temp_journal();
    let payload = vec![1, 2, 3];
    let wrong_digest: [u8; DIGEST_BYTES] = [0xFF; DIGEST_BYTES];
    let record = BlobRecord {
        digest: wrong_digest,
        bytes: payload,
    };
    let mut batch = journal.batch();
    let result = batch.put_blob(&record);
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "batch should reject blob digest mismatch, got {:?}",
        result
    );
}

#[test]
fn batch_empty_commit_succeeds() {
    let (_temp, journal) = temp_journal();
    let batch = journal.batch();
    assert!(batch.is_empty(), "new batch should be empty");
    assert_eq!(batch.len(), 0, "new batch length should be 0");
    batch.commit().expect("empty batch commit should succeed");
}

#[test]
fn batch_with_strict_durability() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(5001);
    let header = RunHeaderRecord {
        run,
        workflow_id: WorkflowId::new(1),
        compiled_digest: WorkflowDigest::from_bytes([0; DIGEST_BYTES]),
        status: 0,
        accepted_at_ms: 1,
    };
    let batch = journal.batch();
    let mut batch = batch.strict();
    batch
        .put_run_header(&header)
        .expect("batch put should succeed");
    batch.commit().expect("strict batch commit should succeed");
    assert!(journal.run_header(run).expect("get").is_some());
}

// =========================================================================
// Missing key lookups return correct error / None
// =========================================================================

#[test]
fn compiled_ir_returns_none_for_unwritten_digest() {
    let (_temp, journal) = temp_journal();
    let missing = WorkflowDigest::from_bytes([0xAA; DIGEST_BYTES]);
    let result = journal.compiled_ir(missing).expect("lookup should succeed");
    assert_eq!(result, None, "missing compiled IR should return None");
}

#[test]
fn snapshot_returns_none_for_missing_run() {
    let (_temp, journal) = temp_journal();
    let result = journal
        .snapshot(RunId::new(99999), EventSeq::new(0))
        .expect("lookup should succeed");
    assert_eq!(result, None, "missing snapshot should return None");
}

#[test]
fn blob_returns_none_for_unwritten_digest() {
    let (_temp, journal) = temp_journal();
    let result = journal
        .blob([0x99; DIGEST_BYTES])
        .expect("lookup should succeed");
    assert_eq!(result, None, "missing blob should return None");
}

// =========================================================================
// compiled_ir with digest verification
// =========================================================================

#[test]
fn compiled_ir_roundtrip_large_payload() {
    let (_temp, journal) = temp_journal();
    let ir = vec![0x42u8; 65536];
    let digest = WorkflowDigest::from_bytes(blake3::hash(&ir).into());
    let record = CompiledIrRecord {
        digest,
        ir: ir.clone(),
    };
    journal
        .put_compiled_ir(&record)
        .expect("put should succeed");
    let loaded = journal
        .compiled_ir(digest)
        .expect("get should succeed")
        .expect("present");
    assert_eq!(loaded.ir, ir);
}

// =========================================================================
// persist_strict succeeds on idle journal
// =========================================================================

#[test]
fn persist_strict_succeeds_without_prior_writes() {
    let (_temp, journal) = temp_journal();
    journal
        .persist_strict()
        .expect("persist_strict on idle journal should succeed");
}

// =========================================================================
// Edge case: write and read single event
// =========================================================================

#[test]
fn write_and_read_single_event() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7777);
    let digest = WorkflowDigest::from_bytes([0xDD; DIGEST_BYTES]);
    let event = JournalEvent::RunAccepted {
        run,
        seq: EventSeq::new(0),
        workflow: digest,
    };
    journal
        .append_strict(&event)
        .expect("append should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), 1, "should have exactly one event");
    assert_eq!(replayed[0], event, "replayed event should match original");
}

// =========================================================================
// Edge case: write batch of 100 events, read all back in order
// =========================================================================

#[test]
fn write_batch_100_events_read_all_in_order() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(8888);
    let count: u64 = 100;

    let events: Vec<JournalEvent> = (0..count)
        .map(|i| JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(i),
            step: StepIdx::new((i % 256) as u16),
            attempt: 1,
        })
        .collect();

    journal
        .append_strict_batch(&events)
        .expect("batch append should succeed");

    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(
        replayed.len(),
        count as usize,
        "should have exactly 100 events"
    );

    for (i, event) in replayed.iter().enumerate() {
        assert_eq!(
            event.seq().get(),
            i as u64,
            "event at index {} should have seq {}",
            i,
            i
        );
        assert_eq!(event.run_id(), run, "all events should belong to same run");
        assert_eq!(
            *event, events[i],
            "event at index {} should match original",
            i
        );
    }
}

// =========================================================================
// Edge case: read from empty journal
// =========================================================================

#[test]
fn read_from_empty_journal_returns_nothing() {
    let (_temp, journal) = temp_journal();

    // All read operations on an empty journal should return None or empty
    let events = journal
        .events_for_run(RunId::new(1))
        .expect("events_for_run on empty journal should succeed");
    assert_eq!(events.len(), 0, "empty journal should have no events");

    let source = journal
        .workflow_source(WorkflowDigest::from_bytes([0; DIGEST_BYTES]))
        .expect("workflow_source on empty journal should succeed");
    assert_eq!(
        source, None,
        "empty journal should return None for workflow source"
    );

    let ir = journal
        .compiled_ir(WorkflowDigest::from_bytes([0; DIGEST_BYTES]))
        .expect("compiled_ir on empty journal should succeed");
    assert_eq!(ir, None, "empty journal should return None for compiled IR");

    let header = journal
        .run_header(RunId::new(1))
        .expect("run_header on empty journal should succeed");
    assert_eq!(
        header, None,
        "empty journal should return None for run header"
    );

    let snap = journal
        .snapshot(RunId::new(1), EventSeq::new(0))
        .expect("snapshot on empty journal should succeed");
    assert_eq!(snap, None, "empty journal should return None for snapshot");

    let blob = journal
        .blob([0; DIGEST_BYTES])
        .expect("blob on empty journal should succeed");
    assert_eq!(blob, None, "empty journal should return None for blob");

    let headers = journal
        .run_headers()
        .expect("run_headers on empty journal should succeed");
    assert_eq!(headers.len(), 0, "empty journal should have no run headers");
}

// =========================================================================
// Edge case: header validation - corrupted magic in stored record
// =========================================================================

#[test]
fn header_validation_rejects_corrupted_magic_in_stored_event() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(9001);
    let event = make_event(run, 0);
    journal
        .append_strict(&event)
        .expect("append should succeed");

    // Directly corrupt the magic bytes in the underlying keyspace
    let key =
        crate::keys::run_event_key(run, EventSeq::new(0)).expect("key construction should succeed");
    let mut value = journal
        .events
        .get(key.as_slice())
        .expect("fjall get should succeed")
        .expect("event should exist")
        .to_vec();

    // Overwrite the first 4 bytes (magic) with garbage
    let garbage_magic: u32 = 0xDEAD_BEEF;
    let magic_bytes = garbage_magic.to_le_bytes();
    if let Some(slice) = value.get_mut(0..4) {
        slice.copy_from_slice(&magic_bytes);
    }
    // Recompute CRC so the header passes CRC check but has wrong magic
    let checksum = crc32c::crc32c(&value[..CRC_OFFSET]);
    let crc_bytes = checksum.to_le_bytes();
    if let Some(slice) = value.get_mut(CRC_OFFSET..CRC_OFFSET.saturating_add(4)) {
        slice.copy_from_slice(&crc_bytes);
    }

    // Write back corrupted value
    journal
        .events
        .insert(key.to_vec(), value)
        .expect("insert should succeed");

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::BadMagic { .. })),
        "corrupted magic in stored event must yield BadMagic, got {:?}",
        result
    );
}

#[test]
fn events_for_run_rejects_header_payload_kind_mismatch() -> Result<(), Box<dyn std::error::Error>> {
    let temp = tempfile::tempdir()?;
    let journal = FjallJournal::open(temp.path(), None)?;
    let run = RunId::new(9004);
    let event = JournalEvent::AskTimedOutEvent {
        run,
        seq: EventSeq::new(0),
        step: StepIdx::new(2),
        attempt: 1,
    };
    let value = crate::codec::encode_record(
        MAGIC_JOURNAL_EVENT,
        crate::RecordKind::AskAnswered,
        event.seq().get(),
        &event,
        MAX_JOURNAL_EVENT_PAYLOAD_BYTES,
    )?;
    let key = crate::keys::run_event_key(run, EventSeq::new(0))?;
    journal.events.insert(key.to_vec(), value)?;

    match journal.events_for_run(run) {
        Err(JournalError::RecordKindPayloadMismatch {
            envelope_kind,
            payload_kind,
        }) if envelope_kind == crate::RecordKind::AskAnswered.id()
            && payload_kind == crate::RecordKind::AskTimedOut.id() =>
        {
            Ok(())
        }
        Ok(_) | Err(_) => Err(Box::new(JournalError::InvalidEvent)),
    }
}

// =========================================================================
// Adversarial replay parity: AskTimedOut(29) ↔ AskAnswered(18) swap.
// =========================================================================

/// The replay path (`events_for_run`) must reject a stored record whose
/// envelope kind is `AskTimedOut(29)` while the payload is an
/// `AskAnsweredEvent`. Without parity enforcement, a tampered record would
/// reach the recovery code as an "answer" instead of a "timeout" and
/// silently diverge from the runtime state. The diagnostic must name both
/// the envelope and the payload kind.
#[test]
fn events_for_run_rejects_ask_timed_out_envelope_with_ask_answered_payload()
-> Result<(), Box<dyn std::error::Error>> {
    let temp = tempfile::tempdir()?;
    let journal = FjallJournal::open(temp.path(), None)?;
    let run = RunId::new(9101);
    let event = JournalEvent::AskAnsweredEvent {
        run,
        seq: EventSeq::new(0),
        step: StepIdx::new(2),
        attempt: 1,
    };
    let value = crate::codec::encode_record(
        MAGIC_JOURNAL_EVENT,
        crate::RecordKind::AskTimedOut,
        event.seq().get(),
        &event,
        MAX_JOURNAL_EVENT_PAYLOAD_BYTES,
    )?;
    let key = crate::keys::run_event_key(run, EventSeq::new(0))?;
    journal.events.insert(key.to_vec(), value)?;

    match journal.events_for_run(run) {
        Err(JournalError::RecordKindPayloadMismatch {
            envelope_kind,
            payload_kind,
        }) if envelope_kind == crate::RecordKind::AskTimedOut.id()
            && payload_kind == crate::RecordKind::AskAnswered.id() =>
        {
            Ok(())
        }
        other => {
            eprintln!(
                "events_for_run must reject AskTimedOut(29) envelope carrying AskAnswered payload, got {other:?}"
            );
            Err(Box::new(JournalError::InvalidEvent))
        }
    }
}

/// Symmetric inverse: a stored record whose envelope kind is
/// `AskAnswered(18)` while the payload is an `AskTimedOutEvent` must also be
/// rejected by the replay path. This is the parity direction exercised by
/// the existing `events_for_run_rejects_header_payload_kind_mismatch` test,
/// but is repeated here under the explicit AskTimedOut ↔ AskAnswered
/// contract so the storage journal parity/API contract is unambiguously
/// covered for both swap directions through every public path.
#[test]
fn events_for_run_rejects_ask_answered_envelope_with_ask_timed_out_payload()
-> Result<(), Box<dyn std::error::Error>> {
    let temp = tempfile::tempdir()?;
    let journal = FjallJournal::open(temp.path(), None)?;
    let run = RunId::new(9102);
    let event = JournalEvent::AskTimedOutEvent {
        run,
        seq: EventSeq::new(0),
        step: StepIdx::new(2),
        attempt: 1,
    };
    let value = crate::codec::encode_record(
        MAGIC_JOURNAL_EVENT,
        crate::RecordKind::AskAnswered,
        event.seq().get(),
        &event,
        MAX_JOURNAL_EVENT_PAYLOAD_BYTES,
    )?;
    let key = crate::keys::run_event_key(run, EventSeq::new(0))?;
    journal.events.insert(key.to_vec(), value)?;

    match journal.events_for_run(run) {
        Err(JournalError::RecordKindPayloadMismatch {
            envelope_kind,
            payload_kind,
        }) if envelope_kind == crate::RecordKind::AskAnswered.id()
            && payload_kind == crate::RecordKind::AskTimedOut.id() =>
        {
            Ok(())
        }
        other => {
            eprintln!(
                "events_for_run must reject AskAnswered(18) envelope carrying AskTimedOut payload, got {other:?}"
            );
            Err(Box::new(JournalError::InvalidEvent))
        }
    }
}

// =========================================================================
// Edge case: header validation - wrong schema version in stored record
// =========================================================================

#[test]
fn header_validation_rejects_wrong_schema_version_in_stored_event() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(9002);
    let event = make_event(run, 0);
    journal
        .append_strict(&event)
        .expect("append should succeed");

    let key =
        crate::keys::run_event_key(run, EventSeq::new(0)).expect("key construction should succeed");
    let mut value = journal
        .events
        .get(key.as_slice())
        .expect("fjall get should succeed")
        .expect("event should exist")
        .to_vec();

    // Overwrite schema version (offset 4, u16 LE) with a future version
    let future_version: u16 = 99;
    let version_bytes = future_version.to_le_bytes();
    if let Some(slice) = value.get_mut(4..6) {
        slice.copy_from_slice(&version_bytes);
    }
    // Recompute CRC after modifying header
    let checksum = crc32c::crc32c(&value[..CRC_OFFSET]);
    let crc_bytes = checksum.to_le_bytes();
    if let Some(slice) = value.get_mut(CRC_OFFSET..CRC_OFFSET.saturating_add(4)) {
        slice.copy_from_slice(&crc_bytes);
    }

    journal
        .events
        .insert(key.to_vec(), value)
        .expect("insert should succeed");

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::UnsupportedSchemaVersion { .. })),
        "wrong schema version in stored event must yield UnsupportedSchemaVersion, got {:?}",
        result
    );
}

// =========================================================================
// Edge case: snapshot round-trip (write snapshot, read back)
// =========================================================================

#[test]
fn snapshot_roundtrip_preserves_all_fields() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7777);
    let workflow = WorkflowDigest::from_bytes([0x77; DIGEST_BYTES]);
    let slots = vec![0x01_u8, 0x02, 0x03, 0x04];
    let taint = vec![0xFF_u8, 0xFE, 0xFD];
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(42),
        workflow,
        slots: slots.clone(),
        taint: taint.clone(),
    };

    journal
        .put_snapshot(&snapshot)
        .expect("put_snapshot should succeed");
    let loaded = journal
        .snapshot(run, EventSeq::new(42))
        .expect("snapshot get should succeed")
        .expect("snapshot should exist");

    assert_eq!(loaded.run, run, "run must match");
    assert_eq!(loaded.seq, EventSeq::new(42), "seq must match");
    assert_eq!(loaded.workflow, workflow, "workflow must match");
    assert_eq!(loaded.slots, slots, "slots must match byte-for-byte");
    assert_eq!(loaded.taint, taint, "taint must match byte-for-byte");
}

#[test]
fn snapshot_roundtrip_with_empty_slots_and_taint() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7778);
    let workflow = WorkflowDigest::from_bytes([0; DIGEST_BYTES]);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(0),
        workflow,
        slots: vec![],
        taint: vec![],
    };

    journal
        .put_snapshot(&snapshot)
        .expect("put_snapshot should succeed");
    let loaded = journal
        .snapshot(run, EventSeq::new(0))
        .expect("snapshot get should succeed")
        .expect("snapshot should exist");

    assert_eq!(loaded.slots.len(), 0, "slots should be empty");
    assert_eq!(loaded.taint.len(), 0, "taint should be empty");
    assert_eq!(loaded, snapshot, "full snapshot must round-trip");
}

// =========================================================================
// Edge case: source marker round-trip (workflow source)
// =========================================================================

#[test]
fn source_marker_roundtrip_preserves_content_and_digest() {
    let (_temp, journal) = temp_journal();
    let source = b"workflow:\n  name: edge_test\n  steps: []".to_vec();
    let digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let record = WorkflowSourceRecord {
        digest,
        source: source.clone(),
    };

    journal
        .put_workflow_source(&record)
        .expect("put_workflow_source should succeed");
    let loaded = journal
        .workflow_source(digest)
        .expect("workflow_source get should succeed")
        .expect("workflow source should exist");

    assert_eq!(
        loaded.source, source,
        "source bytes must round-trip exactly"
    );
    assert_eq!(loaded.digest, digest, "digest must round-trip exactly");
}

#[test]
fn source_marker_roundtrip_with_minimal_source() {
    let (_temp, journal) = temp_journal();
    // Minimal valid source: empty bytes
    let source: Vec<u8> = vec![];
    let digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let record = WorkflowSourceRecord {
        digest,
        source: source.clone(),
    };

    journal
        .put_workflow_source(&record)
        .expect("put_workflow_source should succeed for empty source");
    let loaded = journal
        .workflow_source(digest)
        .expect("workflow_source get should succeed")
        .expect("workflow source should exist");

    assert_eq!(loaded.source.len(), 0, "empty source should round-trip");
    assert_eq!(loaded.source, source);
}

// =========================================================================
// Edge case: multiple persist_strict calls in sequence
// =========================================================================

#[test]
fn multiple_persist_strict_calls_succeed() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(9900);
    let event = make_event(run, 0);
    journal.append_strict(&event).expect("first append");
    journal.persist_strict().expect("first persist");
    journal.persist_strict().expect("second persist");
    journal.persist_strict().expect("third persist");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), 1);
}

// =========================================================================
// Edge case: interleaved writes to different runs
// =========================================================================

#[test]
fn interleaved_writes_to_different_runs_preserves_ordering() {
    let (_temp, journal) = temp_journal();
    let run_a = RunId::new(10001);
    let run_b = RunId::new(10002);
    let digest = WorkflowDigest::from_bytes([0x11; DIGEST_BYTES]);

    let events = [
        JournalEvent::RunAccepted {
            run: run_a,
            seq: EventSeq::new(0),
            workflow: digest,
        },
        JournalEvent::RunAccepted {
            run: run_b,
            seq: EventSeq::new(0),
            workflow: digest,
        },
        JournalEvent::StepStarted {
            run: run_a,
            seq: EventSeq::new(1),
            step: StepIdx::new(0),
            attempt: 1,
        },
        JournalEvent::StepStarted {
            run: run_b,
            seq: EventSeq::new(1),
            step: StepIdx::new(0),
            attempt: 1,
        },
        JournalEvent::StepStarted {
            run: run_a,
            seq: EventSeq::new(2),
            step: StepIdx::new(1),
            attempt: 1,
        },
    ];
    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");

    let replayed_a = journal.events_for_run(run_a).expect("replay A");
    let replayed_b = journal.events_for_run(run_b).expect("replay B");

    assert_eq!(replayed_a.len(), 3, "run A should have 3 events");
    assert_eq!(replayed_b.len(), 2, "run B should have 2 events");
    assert_eq!(replayed_a[0].seq().get(), 0);
    assert_eq!(replayed_a[1].seq().get(), 1);
    assert_eq!(replayed_a[2].seq().get(), 2);
    assert_eq!(replayed_b[0].seq().get(), 0);
    assert_eq!(replayed_b[1].seq().get(), 1);
}

// =========================================================================
// Edge case: batch with single element
// =========================================================================

#[test]
fn append_strict_batch_single_element_roundtrips() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10100);
    let event = make_event(run, 0);
    journal
        .append_strict_batch(&[event.clone()])
        .expect("single-element batch");
    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 1);
    assert_eq!(replayed[0], event);
}

// =========================================================================
// Edge case: duplicate detection after batch commit
// =========================================================================

#[test]
fn duplicate_event_after_batch_commit_is_rejected() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10200);
    let event = make_event(run, 0);
    journal
        .append_strict_batch(&[event.clone()])
        .expect("batch commit");
    let result = journal.append_strict(&event);
    assert!(
        matches!(result, Err(JournalError::DuplicateEvent { .. })),
        "duplicate after batch should be rejected, got {:?}",
        result
    );
}

// =========================================================================
// Edge case: snapshot with post-snapshot events starts replay after snapshot
// =========================================================================

#[test]
fn events_for_run_starts_after_snapshot_when_pre_snapshot_trimmed() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10300);
    let workflow = WorkflowDigest::from_bytes([0x33; DIGEST_BYTES]);

    // Write a snapshot at seq 2
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(2),
        workflow,
        slots: vec![],
        taint: vec![],
    };
    journal.put_snapshot(&snapshot).expect("put snapshot");

    // Only write events at seq 3, 4, 5 (as if snapshot-covered events were trimmed)
    for seq in 3u64..6 {
        let event = JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(seq),
            step: StepIdx::new(seq as u16),
            attempt: 1,
        };
        journal
            .append_unfsynced(&event)
            .expect("append should succeed");
    }

    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(
        replayed.len(),
        3,
        "should replay 3 events starting after snapshot seq"
    );
    assert_eq!(replayed[0].seq().get(), 3);
    assert_eq!(replayed[1].seq().get(), 4);
    assert_eq!(replayed[2].seq().get(), 5);
}

#[test]
fn events_for_run_bounded_rejects_over_limit() -> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10301);
    for seq in 0u16..2 {
        journal
            .append_unfsynced(&make_step_started(run, u64::from(seq), seq))
            .map_err(|err| err.to_string())?;
    }

    let Some(limit) = EventReplayLimit::new(1) else {
        return Err("non-zero replay limit was rejected".to_owned());
    };
    let result = journal.events_for_run_bounded(run, limit);
    assert!(
        matches!(
            result,
            Err(JournalError::TooManyEvents {
                run: found_run,
                limit: 1,
                observed: 2,
            }) if found_run == run
        ),
        "bounded replay must fail closed when more events are present"
    );
    Ok(())
}

#[test]
fn events_for_run_detects_missing_first_tail_event_after_snapshot() -> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10302);
    let workflow = WorkflowDigest::from_bytes([0x44; DIGEST_BYTES]);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(2),
        workflow,
        slots: vec![],
        taint: vec![],
    };
    journal
        .put_snapshot(&snapshot)
        .map_err(|err| err.to_string())?;
    journal
        .append_unfsynced(&make_step_started(run, 4, 4))
        .map_err(|err| err.to_string())?;

    let result = journal.events_for_run(run);
    assert!(
        matches!(
            result,
            Err(JournalError::SequenceGap {
                expected,
                actual,
            }) if expected == EventSeq::new(3) && actual == EventSeq::new(4)
        ),
        "missing first event after the durable snapshot must not be laundered"
    );
    Ok(())
}

#[test]
fn events_for_run_without_snapshot_rejects_missing_initial_sequence() -> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10303);
    journal
        .append_unfsynced(&make_step_started(run, 4, 4))
        .map_err(|err| err.to_string())?;

    let result = journal.events_for_run(run);
    assert!(
        matches!(
            result,
            Err(JournalError::SequenceGap { expected, actual })
                if expected == EventSeq::new(0) && actual == EventSeq::new(4)
        ),
        "runs without snapshots must start at seq 0, got {:?}",
        result
    );
    Ok(())
}

#[test]
fn events_for_run_rejects_corrupt_latest_snapshot_before_skipping_events() -> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10304);
    let workflow = WorkflowDigest::from_bytes([0x45; DIGEST_BYTES]);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(2),
        workflow,
        slots: vec![],
        taint: vec![],
    };
    journal
        .put_snapshot(&snapshot)
        .map_err(|err| err.to_string())?;
    journal
        .append_unfsynced(&make_step_started(run, 3, 3))
        .map_err(|err| err.to_string())?;

    let key =
        crate::keys::run_snapshot_key(run, EventSeq::new(2)).map_err(|err| err.to_string())?;
    let mut value = journal
        .run_snapshot
        .get(key.as_slice())
        .map_err(|err| err.to_string())?
        .ok_or_else(|| "snapshot record should exist".to_owned())?
        .to_vec();
    corrupt_magic_preserving_crc(&mut value);
    journal
        .run_snapshot
        .insert(key.to_vec(), value)
        .map_err(|err| err.to_string())?;

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::BadMagic { .. })),
        "corrupt latest snapshot must fail before tail replay, got {:?}",
        result
    );
    Ok(())
}

#[test]
fn events_for_run_rejects_latest_snapshot_payload_digest_mismatch_before_tail_replay()
-> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10306);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(2),
        workflow: WorkflowDigest::from_bytes([0x47; DIGEST_BYTES]),
        slots: vec![],
        taint: vec![],
    };
    journal
        .put_snapshot(&snapshot)
        .map_err(|err| err.to_string())?;
    journal
        .append_unfsynced(&make_step_started(run, 3, 3))
        .map_err(|err| err.to_string())?;

    let key =
        crate::keys::run_snapshot_key(run, EventSeq::new(2)).map_err(|err| err.to_string())?;
    let mut value = journal
        .run_snapshot
        .get(key.as_slice())
        .map_err(|err| err.to_string())?
        .ok_or_else(|| "snapshot record should exist".to_owned())?
        .to_vec();
    let last = value
        .last_mut()
        .ok_or_else(|| "snapshot record must be non-empty".to_owned())?;
    *last ^= 0x01;
    journal
        .run_snapshot
        .insert(key.to_vec(), value)
        .map_err(|err| err.to_string())?;

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::PayloadDigestMismatch)),
        "corrupt latest snapshot payload digest must fail before tail replay, got {:?}",
        result
    );
    Ok(())
}

#[test]
fn events_for_run_rejects_latest_snapshot_postcard_decode_failure_before_tail_replay()
-> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10307);
    journal
        .append_unfsynced(&make_step_started(run, 3, 3))
        .map_err(|err| err.to_string())?;

    let key =
        crate::keys::run_snapshot_key(run, EventSeq::new(2)).map_err(|err| err.to_string())?;
    let invalid_payload = vec![0xFF_u8];
    let value = crate::codec::encode_record(
        MAGIC_SNAPSHOT,
        crate::records::RecordKind::Snapshot,
        2,
        &invalid_payload,
        MAX_SNAPSHOT_BYTES,
    )
    .map_err(|err| err.to_string())?;
    journal
        .run_snapshot
        .insert(key.to_vec(), value)
        .map_err(|err| err.to_string())?;

    let result = journal.events_for_run(run);
    assert!(
        matches!(result, Err(JournalError::PostcardDecodeFailed(_))),
        "invalid latest snapshot payload must fail before tail replay, got {:?}",
        result
    );
    Ok(())
}

#[test]
fn events_for_run_skips_corrupt_pre_snapshot_event_by_key_range() -> Result<(), String> {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(10305);
    for seq in 0_u64..3 {
        journal
            .append_unfsynced(&make_step_started(run, seq, seq as u16))
            .map_err(|err| err.to_string())?;
    }
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(1),
        workflow: WorkflowDigest::from_bytes([0x46; DIGEST_BYTES]),
        slots: vec![],
        taint: vec![],
    };
    journal
        .put_snapshot(&snapshot)
        .map_err(|err| err.to_string())?;

    let key = crate::keys::run_event_key(run, EventSeq::new(0)).map_err(|err| err.to_string())?;
    let mut value = journal
        .events
        .get(key.as_slice())
        .map_err(|err| err.to_string())?
        .ok_or_else(|| "event record should exist".to_owned())?
        .to_vec();
    corrupt_magic_preserving_crc(&mut value);
    journal
        .events
        .insert(key.to_vec(), value)
        .map_err(|err| err.to_string())?;

    let replayed = journal.events_for_run(run).map_err(|err| err.to_string())?;
    assert_eq!(replayed, vec![make_step_started(run, 2, 2)]);
    Ok(())
}

// =========================================================================
// Edge case: compiled_ir stores multiple distinct digests
// =========================================================================

#[test]
fn compiled_ir_stores_multiple_distinct_digests() {
    let (_temp, journal) = temp_journal();
    let ir_v1 = b"compiled-v1".to_vec();
    let digest_v1 = WorkflowDigest::from_bytes(blake3::hash(&ir_v1).into());
    let record_v1 = CompiledIrRecord {
        digest: digest_v1,
        ir: ir_v1.clone(),
    };
    journal.put_compiled_ir(&record_v1).expect("put v1");

    let ir_v2 = b"compiled-v2".to_vec();
    let digest_v2 = WorkflowDigest::from_bytes(blake3::hash(&ir_v2).into());
    let record_v2 = CompiledIrRecord {
        digest: digest_v2,
        ir: ir_v2.clone(),
    };
    journal.put_compiled_ir(&record_v2).expect("put v2");

    let loaded_v1 = journal
        .compiled_ir(digest_v1)
        .expect("get v1")
        .expect("present");
    let loaded_v2 = journal
        .compiled_ir(digest_v2)
        .expect("get v2")
        .expect("present");
    assert_eq!(loaded_v1.ir, ir_v1);
    assert_eq!(loaded_v2.ir, ir_v2);
}

// =========================================================================
// Edge case: many distinct runs with one event each
// =========================================================================

#[test]
fn many_runs_one_event_each_are_isolated() {
    let (_temp, journal) = temp_journal();
    let count: u64 = 20;
    for i in 0u64..count {
        let run = RunId::new(11000_u64.saturating_add(i));
        let event = make_event(run, 0);
        journal
            .append_unfsynced(&event)
            .expect("append should succeed");
    }

    for i in 0u64..count {
        let run = RunId::new(11000_u64.saturating_add(i));
        let replayed = journal.events_for_run(run).expect("replay");
        assert_eq!(replayed.len(), 1, "run {} should have 1 event", i);
        assert_eq!(replayed[0].run_id(), run);
    }
}

// =========================================================================
// Edge case: large batch write of 500 events
// =========================================================================

#[test]
fn large_batch_500_events_roundtrips() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(12000);
    let count: u64 = 500;

    let events: Vec<JournalEvent> = (0..count)
        .map(|i| JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(i),
            step: StepIdx::new((i % 256) as u16),
            attempt: 1,
        })
        .collect();

    journal
        .append_strict_batch(&events)
        .expect("batch should succeed");
    let replayed = journal.events_for_run(run).expect("replay should succeed");
    assert_eq!(replayed.len(), count as usize);
    for (i, event) in replayed.iter().enumerate() {
        assert_eq!(event.seq().get(), i as u64);
    }
}

// =========================================================================
// Edge case: boundary sequence numbers (0 and 1)
// =========================================================================

#[test]
fn boundary_sequence_numbers_roundtrip() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(13000);
    let digest = WorkflowDigest::from_bytes([0x44; DIGEST_BYTES]);

    let e0 = JournalEvent::RunAccepted {
        run,
        seq: EventSeq::new(0),
        workflow: digest,
    };
    journal.append_unfsynced(&e0).expect("append seq 0");

    let e1 = JournalEvent::StepStarted {
        run,
        seq: EventSeq::new(1),
        step: StepIdx::new(0),
        attempt: 1,
    };
    journal.append_unfsynced(&e1).expect("append seq 1");

    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 2);
    assert_eq!(replayed[0].seq().get(), 0);
    assert_eq!(replayed[1].seq().get(), 1);
}

// =========================================================================
// Edge case: blob with 16 KiB payload roundtrips
// =========================================================================

#[test]
fn blob_large_payload_roundtrips() {
    let (_temp, journal) = temp_journal();
    let payload = vec![0xFE_u8; 16384];
    let digest: [u8; DIGEST_BYTES] = blake3::hash(&payload).into();
    let record = BlobRecord {
        digest,
        bytes: payload.clone(),
    };
    journal.put_blob(&record).expect("put should succeed");
    let loaded = journal
        .blob(digest)
        .expect("get should succeed")
        .expect("present");
    assert_eq!(loaded.bytes, payload);
}

// =========================================================================
// Edge case: batch append_event rejects duplicate key within same batch
// =========================================================================
//
// SA-003: prior behavior allowed duplicate `(run, seq)` insertions
// within a single `JournalWriteBatch`, relying on Fjall's
// last-write-wins semantics to collapse them at commit time. That
// silent overwrite dropped the first event's value without
// signaling an error. The fixed behavior rejects the second
// append with `DuplicateStagedKey` so callers can detect the
// intra-batch collision explicitly.

#[test]
fn batch_append_event_rejects_intra_batch_duplicate() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(14000);
    let event = make_event(run, 0);

    let mut batch = journal.batch();
    batch.append_event(&event).expect("first batch append");

    let second = batch.append_event(&event);
    assert!(
        matches!(second, Err(JournalError::DuplicateStagedKey { .. })),
        "second same-batch append must reject with DuplicateStagedKey, got {:?}",
        second
    );

    // The rejection must not mutate the prior staged event: the
    // batch still contains exactly one event and commits cleanly.
    assert_eq!(
        batch.len(),
        1,
        "rejected append must not stage a second event"
    );
    batch.commit().expect("commit should succeed");

    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(
        replayed.len(),
        1,
        "duplicate must be rejected, leaving a single durable event"
    );
}

// =========================================================================
// Edge case: batch with snapshot and event for same run
// =========================================================================

#[test]
fn batch_with_snapshot_and_event_for_same_run() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(15000);
    let workflow = WorkflowDigest::from_bytes([0x55; DIGEST_BYTES]);
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(0),
        workflow,
        slots: vec![1, 2, 3],
        taint: vec![],
    };
    let event = make_event(run, 1);

    let mut batch = journal.batch();
    batch.put_snapshot(&snapshot).expect("batch snapshot");
    batch.append_event(&event).expect("batch event");
    batch.commit().expect("commit");

    let loaded_snap = journal
        .snapshot(run, EventSeq::new(0))
        .expect("get snapshot")
        .expect("present");
    assert_eq!(loaded_snap.slots, vec![1, 2, 3]);
    // Snapshot at seq 0 covers events 0..0; event at seq 1 is after snapshot
    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 1);
}

// =========================================================================
// Edge case: workflow source with 128 KiB payload
// =========================================================================

#[test]
fn workflow_source_near_max_bytes_is_accepted() {
    let (_temp, journal) = temp_journal();
    let source = vec![0x42u8; 131072];
    let digest = WorkflowDigest::from_bytes(blake3::hash(&source).into());
    let record = WorkflowSourceRecord {
        digest,
        source: source.clone(),
    };
    journal
        .put_workflow_source(&record)
        .expect("put should succeed for 128 KiB");
    let loaded = journal
        .workflow_source(digest)
        .expect("get")
        .expect("present");
    assert_eq!(loaded.source.len(), source.len());
}

// =========================================================================
// Edge case: run header with max field values
// =========================================================================

#[test]
fn run_header_with_max_field_values() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(u64::MAX);
    let digest = WorkflowDigest::from_bytes([0xFF; DIGEST_BYTES]);
    let record = RunHeaderRecord {
        run,
        workflow_id: vb_core::WorkflowId::new(u32::MAX),
        compiled_digest: digest,
        status: u8::MAX,
        accepted_at_ms: u64::MAX,
    };
    journal.put_run_header(&record).expect("put should succeed");
    let loaded = journal.run_header(run).expect("get").expect("present");
    assert_eq!(loaded.run, run);
    assert_eq!(loaded.workflow_id, vb_core::WorkflowId::new(u32::MAX));
    assert_eq!(loaded.status, u8::MAX);
    assert_eq!(loaded.accepted_at_ms, u64::MAX);
}

// =========================================================================
// Edge case: empty run headers list
// =========================================================================

#[test]
fn run_headers_empty_journal_returns_empty_vec() {
    let (_temp, journal) = temp_journal();
    let headers = journal.run_headers().expect("run_headers on empty journal");
    assert_eq!(headers.len(), 0, "empty journal should have no headers");
}

// =========================================================================
// Edge case: snapshot with populated slots and empty taint
// =========================================================================

#[test]
fn snapshot_with_populated_slots_empty_taint() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(16000);
    let workflow = WorkflowDigest::from_bytes([0x66; DIGEST_BYTES]);
    let slots = vec![0x01_u8; 256];
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(10),
        workflow,
        slots: slots.clone(),
        taint: vec![],
    };
    journal.put_snapshot(&snapshot).expect("put");
    let loaded = journal
        .snapshot(run, EventSeq::new(10))
        .expect("get")
        .expect("present");
    assert_eq!(loaded.slots, slots);
    assert!(loaded.taint.is_empty());
}

// =========================================================================
// Edge case: snapshot with empty slots and populated taint
// =========================================================================

#[test]
fn snapshot_with_empty_slots_populated_taint() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(16001);
    let workflow = WorkflowDigest::from_bytes([0x77; DIGEST_BYTES]);
    let taint = vec![0xFF_u8; 128];
    let snapshot = RunSnapshot {
        run,
        seq: EventSeq::new(5),
        workflow,
        slots: vec![],
        taint: taint.clone(),
    };
    journal.put_snapshot(&snapshot).expect("put");
    let loaded = journal
        .snapshot(run, EventSeq::new(5))
        .expect("get")
        .expect("present");
    assert!(loaded.slots.is_empty());
    assert_eq!(loaded.taint, taint);
}

// =========================================================================
// Edge case: append_queued_unfsynced then read back
// =========================================================================

#[test]
fn append_queued_unfsynced_then_read_back() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(17000);
    let event = make_event(run, 0);
    journal
        .append_queued_unfsynced(&event)
        .expect("append should succeed");
    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 1);
    assert_eq!(replayed[0], event);
}

// =========================================================================
// Edge case: consecutive append_journaled calls
// =========================================================================

#[test]
fn consecutive_append_journaled_calls() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(18000);

    for seq in 0u64..10 {
        let event = JournalEvent::StepStarted {
            run,
            seq: EventSeq::new(seq),
            step: StepIdx::new(seq as u16),
            attempt: 1,
        };
        journal
            .append_journaled(&event)
            .expect("append_journaled should succeed");
    }

    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 10);
    for (i, event) in replayed.iter().enumerate() {
        assert_eq!(event.seq().get(), i as u64);
    }
}

// =========================================================================
// Edge case: mixed durability modes on same run
// =========================================================================

#[test]
fn mixed_durability_modes_on_same_run() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(19000);
    let digest = WorkflowDigest::from_bytes([0x88; DIGEST_BYTES]);

    let e0 = JournalEvent::RunAccepted {
        run,
        seq: EventSeq::new(0),
        workflow: digest,
    };
    journal.append_strict(&e0).expect("strict append");

    let e1 = JournalEvent::StepStarted {
        run,
        seq: EventSeq::new(1),
        step: StepIdx::new(0),
        attempt: 1,
    };
    journal.append_journaled(&e1).expect("journaled append");

    let e2 = JournalEvent::StepStarted {
        run,
        seq: EventSeq::new(2),
        step: StepIdx::new(1),
        attempt: 1,
    };
    journal.append_strict(&e2).expect("strict append 2");

    let replayed = journal.events_for_run(run).expect("replay");
    assert_eq!(replayed.len(), 3);
    assert_eq!(replayed[0], e0);
    assert_eq!(replayed[1], e1);
    assert_eq!(replayed[2], e2);
}

// =========================================================================
// Edge case: index keyspaces remain empty until explicitly written
// =========================================================================

#[test]
fn index_keyspaces_empty_after_regular_writes() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(20000);
    let event = make_event(run, 0);
    journal.append_strict(&event).expect("append");

    let mut status_count = 0usize;
    for item in journal.index_status.iter() {
        assert!(item.key().is_ok());
        status_count = status_count.saturating_add(1);
    }
    assert_eq!(status_count, 0, "status index should be empty");

    let mut workflow_count = 0usize;
    for item in journal.index_workflow.iter() {
        assert!(item.key().is_ok());
        workflow_count = workflow_count.saturating_add(1);
    }
    assert_eq!(workflow_count, 0, "workflow index should be empty");

    let mut action_count = 0usize;
    for item in journal.index_action.iter() {
        assert!(item.key().is_ok());
        action_count = action_count.saturating_add(1);
    }
    assert_eq!(action_count, 0, "action index should be empty");
}

// =========================================================================
// Edge case: all declared keyspaces are queryable after open
// =========================================================================

#[test]
fn all_declared_keyspaces_are_iterable_after_open() {
    let (_temp, journal) = temp_journal();
    assert!(journal.workflow_source.iter().next().is_none());
    assert!(journal.compiled_ir.iter().next().is_none());
    assert!(journal.run_header.iter().next().is_none());
    assert!(journal.events.iter().next().is_none());
    assert!(journal.run_snapshot.iter().next().is_none());
    assert!(journal.blob.iter().next().is_none());
    assert!(journal.index_status.iter().next().is_none());
    assert!(journal.index_workflow.iter().next().is_none());
    assert!(journal.index_action.iter().next().is_none());
}

// =========================================================================
// close() method tests
// =========================================================================

/// Test that close() propagates errors from persist_strict on a clean journal.
/// A clean (empty) journal should not produce persist errors.
#[test]
fn close_succeeds_on_clean_journal() {
    let (_temp, mut journal) = temp_journal();
    // close() should succeed on idle journal
    journal
        .close()
        .expect("close on clean journal should succeed");
}

/// Test that close() returns unit on success.
#[test]
fn close_returns_unit_on_success() {
    let (_temp, mut journal) = temp_journal();
    let result = journal.close();
    assert!(result.is_ok(), "close should return Ok(()) on success");
}

/// Test that drop does NOT call close() by verifying the process lock is released
/// even when close() is not called. The journal can be reopened after drop.
#[test]
fn drop_releases_process_lock_even_without_explicit_close() {
    let temp = tempfile::tempdir().expect("tempdir creation should succeed");
    let path = temp.path().to_path_buf();

    // First, open and hold the journal
    {
        let journal = FjallJournal::open(&path, None).expect("journal open should succeed");
        let run = RunId::new(9999);
        let digest = WorkflowDigest::from_bytes([0xEE; DIGEST_BYTES]);
        let event = JournalEvent::RunAccepted {
            run,
            seq: EventSeq::new(0),
            workflow: digest,
        };
        journal
            .append_strict(&event)
            .expect("append should succeed");
        // Explicitly do NOT call close() here
    } // journal drops here without explicit close

    // The process lock should be released when journal drops, allowing reopen
    // If drop called close() and close() succeeded, this would also work.
    // If drop called close() and close() failed, the process lock might not be released.
    let journal2 =
        FjallJournal::open(&path, None).expect("journal should be reopenable after drop");
    let replayed = journal2
        .events_for_run(RunId::new(9999))
        .expect("replay should succeed");
    assert_eq!(
        replayed.len(),
        1,
        "should have exactly one event after reopen"
    );
}

/// Test that close() propagates persist errors when underlying storage fails.
/// This uses a test-only fault hook to force the strict durability boundary to fail.
#[test]
fn close_propagates_persist_errors() {
    let (_temp, mut journal) = temp_journal();
    journal.fail_next_persist_for_test();

    let result = journal.close();
    assert!(
        matches!(result, Err(JournalError::StrictDurabilityFailed)),
        "close must propagate strict durability failures, got {:?}",
        result
    );
}

// =========================================================================
// Regression test for SA-016
// =========================================================================
//
// SA-016 confirmed that `append_queued_unfsynced` actually commits to
// the LSM memtable per call; "unpersisted" only meant "not fsynced".  The
// misleading name was corrected to `append_queued_unfsynced` so that the
// type signature documents the actual semantics: the event is durable
// against process-level recovery (visible to readers and replay) but has
// not been force-fsync'd to disk.

#[test]
fn append_queued_unfsynced_commits_to_memtable_and_is_visible_to_readers() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7000);
    let event = make_event(run, 0);

    // The renamed entry point must accept and commit the event without
    // requiring an explicit fsync call from the caller.
    journal
        .append_queued_unfsynced(&event)
        .expect("append_queued_unfsynced should commit to the memtable");

    // "unfsynced" means it is committed to the LSM memtable and visible
    // to subsequent readers — that is the actual documented contract.
    let replayed = journal
        .events_for_run(run)
        .expect("replay should succeed after an unfsynced commit");
    assert_eq!(
        replayed.len(),
        1,
        "event must be visible to readers immediately after append_queued_unfsynced"
    );
    assert_eq!(
        replayed[0], event,
        "replayed event must equal appended event"
    );
}

// =========================================================================
// Regression test for SA-016 — wave-15 follow-up bead vb-y8tyj
// =========================================================================
//
// The wave-13 parent bead (vb-s9iyv) renamed the public wrapper from
// `append_queued_unpersisted` to `append_queued_unfsynced`. The wave-15
// follow-up bead (vb-y8tyj) finishes the rename by renaming the inner
// helper from `append_unpersisted` to `append_unfsynced` so the entire
// append path carries the accurate "unfsynced" semantics.
//
// This test exercises the renamed helper directly (not via the wrapper)
// to lock the rename in place at the source-of-truth symbol. Any
// re-introduction of the old `append_unpersisted` name will fail to
// compile this test.

#[test]
fn append_unfsynced_helper_commits_event_to_memtable() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7001);
    let event = make_event(run, 0);

    // Direct invocation of the renamed inner helper. The wrapper's
    // idempotency layer is intentionally bypassed: this test pins the
    // rename to the source-of-truth function symbol.
    journal
        .append_unfsynced(&event)
        .expect("append_unfsynced should commit to the LSM memtable");

    let replayed = journal
        .events_for_run(run)
        .expect("replay should succeed after an unfsynced commit");
    assert_eq!(
        replayed.len(),
        1,
        "event must be visible to readers immediately after append_unfsynced"
    );
    assert_eq!(
        replayed[0], event,
        "replayed event must equal appended event"
    );
}

#[test]
fn append_unfsynced_helper_rejects_duplicate_key() {
    let (_temp, journal) = temp_journal();
    let run = RunId::new(7002);
    let event_a = make_event(run, 0);

    journal
        .append_unfsynced(&event_a)
        .expect("first append_unfsynced should succeed");

    // Build a different event at the same (run, seq) — the helper must
    // reject with DuplicateEvent (not silently overwrite, not panic).
    let event_b = make_step_started(run, 0, 0);
    let result = journal.append_unfsynced(&event_b);

    match result {
        Err(JournalError::DuplicateEvent { run: r, seq }) => {
            assert_eq!(r, run, "DuplicateEvent must carry the colliding run");
            assert_eq!(seq.get(), 0, "DuplicateEvent must carry the colliding seq");
        }
        Ok(()) => panic!("append_unfsynced must reject a duplicate (run, seq)"),
        Err(other) => panic!("append_unfsynced returned unexpected error: {other:?}"),
    }

    // The original record must remain intact.
    let replayed = journal
        .events_for_run(run)
        .expect("replay should succeed after rejected duplicate");
    assert_eq!(replayed.len(), 1, "duplicate must not overwrite original");
    assert_eq!(replayed[0], event_a, "original record must remain intact");
}

// =========================================================================
// round10-a / Issue 5: replay/codec bind regression test
//
// The envelope binds three things: the Fjall key, the envelope's `sequence`
// field, and the payload's `seq`. A tampered value whose envelope sequence
// diverges from the payload seq must surface as
// `JournalError::ReplayEnvelopeSequenceMismatch` at replay time, not be
// silently replayed under the wrong identity.
// =========================================================================

#[test]
fn key_payload_mismatch_fails_replay() -> Result<(), JournalError> {
    let (_temp, journal) = temp_journal();
    let run = vb_core::RunId::new(7);
    let key_seq = EventSeq::new(42);
    let envelope_seq: u64 = 99;

    // Build a normal RunAccepted event for (run=7, seq=42). The payload's
    // seq is 42, so the Fjall key will be (run=7, seq=42) and the payload
    // will report seq=42.
    let event = JournalEvent::RunAccepted {
        run,
        seq: key_seq,
        workflow: WorkflowDigest::from_bytes([0; DIGEST_BYTES]),
    };

    // Encode the envelope with envelope.sequence=99 while the payload's
    // seq remains 42. This produces a record whose envelope sequence
    // disagrees with the payload's seq field — exactly the divergence
    // round10-a / Issue 5 must catch.
    let mut encoded = crate::codec::encode_record(
        MAGIC_JOURNAL_EVENT,
        crate::records::RecordKind::RunAccepted,
        envelope_seq,
        &event,
        MAX_JOURNAL_EVENT_PAYLOAD_BYTES,
    )
    .expect("encode_record should succeed");

    // Recompute the header checksum so the bind reaches the envelope-vs-
    // payload check (rather than failing earlier with HeaderChecksumMismatch).
    let checksum = crc32c::crc32c(&encoded[..56]);
    encoded[56] = (checksum & 0xFF) as u8;
    encoded[57] = ((checksum >> 8) & 0xFF) as u8;
    encoded[58] = ((checksum >> 16) & 0xFF) as u8;
    encoded[59] = ((checksum >> 24) & 0xFF) as u8;

    // Insert the tampered record directly under the (run=7, seq=42) key
    // so the replay path sees a real, on-disk mismatch.
    let key = crate::keys::run_event_key(run, key_seq)?;
    journal
        .events
        .insert(key.to_vec(), encoded)
        .map_err(JournalError::Fjall)?;

    // Replay must surface the typed mismatch error rather than silently
    // returning the event under a forged sequence.
    let err = journal
        .events_for_run(run)
        .expect_err("replay must reject envelope/payload sequence mismatch");
    assert!(
        matches!(
            err,
            JournalError::ReplayEnvelopeSequenceMismatch {
                run: actual_run,
                envelope_seq: 99,
                payload_seq: 42,
            } if actual_run == run
        ),
        "expected ReplayEnvelopeSequenceMismatch for run={run:?}, envelope_seq=99, payload_seq=42, got {:?}",
        err
    );
    Ok(())
}

#[test]
fn replay_rejects_key_payload_sequence_mismatch() -> Result<(), JournalError> {
    let (_temp, journal) = temp_journal();
    let run = vb_core::RunId::new(8);
    let key_seq = EventSeq::new(0);
    let payload_seq = EventSeq::new(1);

    let event = JournalEvent::RunAccepted {
        run,
        seq: payload_seq,
        workflow: WorkflowDigest::from_bytes([0; DIGEST_BYTES]),
    };
    let encoded = crate::codec::encode_record(
        MAGIC_JOURNAL_EVENT,
        crate::records::RecordKind::RunAccepted,
        payload_seq.get(),
        &event,
        MAX_JOURNAL_EVENT_PAYLOAD_BYTES,
    )?;

    let key = crate::keys::run_event_key(run, key_seq)?;
    journal
        .events
        .insert(key.to_vec(), encoded)
        .map_err(JournalError::Fjall)?;

    let err = journal
        .events_for_run(run)
        .expect_err("replay must reject key/payload sequence mismatch");
    assert!(
        matches!(
            err,
            JournalError::ReplayKeyMismatch {
                run: actual_run,
                key_seq: 0,
                payload_seq: 1,
            } if actual_run == run
        ),
        "expected ReplayKeyMismatch for key seq 0 and payload seq 1, got {err:?}"
    );
    Ok(())
}
