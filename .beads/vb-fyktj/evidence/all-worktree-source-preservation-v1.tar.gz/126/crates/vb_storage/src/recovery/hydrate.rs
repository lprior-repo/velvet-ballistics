#![forbid(unsafe_code)]
//! RunFrame hydration from snapshot and journal events.
//!
//! Provides:
//! - `hydrate_run_frame`: Reconstruct live RunFrame from snapshot + tail events
//! - `hydrate_run_frame_from_events`: Reconstruct live RunFrame from events only

use crate::JournalEvent;
use crate::recovery::hydrate_support::{
    apply_tail_events, decode_snapshot_slots, derive_dimensions_from_snapshot_and_tail,
    verified_action_envelope_digest, verify_action_ticket_event,
};
use crate::recovery::types::ActionReplayEffect;
use crate::recovery::types::{
    ActionReplayTracker, RecoveredSlotEntry, RecoveredStepEntry, RecoveredStepState,
    RecoveryCannotResumeState, RecoveryError, RecoveryFrameSeed, RecoveryResult, RunSnapshot,
};
use std::collections::BTreeSet;
use vb_core::{ActionId, RunId, StepIdx, WorkflowDigest};
/// Production proof surface for snapshot-plus-tail run identity.
#[must_use]
pub fn hydrate_snapshot_tail_run_matches(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> bool {
    snapshot.run == run_id && tail_events.iter().all(|event| event.run_id() == run_id)
}

/// Production proof surface for snapshot-plus-tail sequence ordering.
#[must_use]
pub fn hydrate_snapshot_tail_seq_after_snapshot(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
) -> bool {
    tail_events.iter().all(|event| event.seq() > snapshot.seq)
}

/// Production proof surface for non-empty recovery evidence.
#[must_use]
pub fn hydrate_snapshot_tail_has_evidence(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
) -> bool {
    !tail_events.is_empty() || !snapshot.slots.is_empty() || !snapshot.taint.is_empty()
}

/// Production proof surface for hydrate_run_frame preconditions that do not decode bytes.
#[must_use]
pub fn hydrate_snapshot_tail_preconditions(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> bool {
    hydrate_snapshot_tail_run_matches(snapshot, tail_events, run_id)
        && hydrate_snapshot_tail_seq_after_snapshot(snapshot, tail_events)
        && hydrate_snapshot_tail_has_evidence(snapshot, tail_events)
}

/// Production proof surface for events-only hydrate preconditions.
#[must_use]
pub const fn hydrate_events_preconditions(events: &[JournalEvent]) -> bool {
    !events.is_empty()
}

/// Production proof surface for positive frame dimensions.
#[must_use]
pub const fn hydrate_dimensions_positive(step_count: u16, slot_count: u16) -> bool {
    step_count > 0 && slot_count > 0
}

/// Copy-only metadata needed to validate snapshot/tail hydration ordering.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct TailEventMetadata {
    pub(crate) run: RunId,
    pub(crate) seq: crate::EventSeq,
}

impl TailEventMetadata {
    #[must_use]
    pub(crate) const fn new(run: RunId, seq: crate::EventSeq) -> Self {
        Self { run, seq }
    }

    #[must_use]
    pub(crate) const fn from_event(event: &JournalEvent) -> Self {
        Self::new(event.run_id(), event.seq())
    }
}

/// Allocation-free classification for snapshot/tail hydration preconditions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SnapshotRecoveryInputViolation {
    SnapshotRunMismatch {
        expected_run: RunId,
        snapshot_run: RunId,
        snapshot_seq: crate::EventSeq,
    },
    TailRunMismatch {
        expected: RunId,
        actual: RunId,
    },
    TailSeqNotAfterSnapshot {
        snapshot_seq: crate::EventSeq,
        actual_seq: crate::EventSeq,
    },
    /// First tail event seq is not contiguous with snapshot seq.
    TailSeqGap {
        snapshot_seq: crate::EventSeq,
        actual_seq: crate::EventSeq,
    },
    NoRecoveryData {
        run: RunId,
    },
}

pub(crate) const fn validate_snapshot_metadata(
    snapshot_run: RunId,
    snapshot_seq: crate::EventSeq,
    run_id: RunId,
) -> Result<(), SnapshotRecoveryInputViolation> {
    if snapshot_run.get() == run_id.get() {
        Ok(())
    } else {
        Err(SnapshotRecoveryInputViolation::SnapshotRunMismatch {
            expected_run: run_id,
            snapshot_run,
            snapshot_seq,
        })
    }
}

pub(crate) const fn validate_tail_run_metadata(
    event: TailEventMetadata,
    run_id: RunId,
) -> Result<(), SnapshotRecoveryInputViolation> {
    if event.run.get() == run_id.get() {
        Ok(())
    } else {
        Err(SnapshotRecoveryInputViolation::TailRunMismatch {
            expected: run_id,
            actual: event.run,
        })
    }
}

pub(crate) const fn validate_tail_seq_after_snapshot(
    event: TailEventMetadata,
    snapshot_seq: crate::EventSeq,
) -> Result<(), SnapshotRecoveryInputViolation> {
    if event.seq.get() > snapshot_seq.get() {
        Ok(())
    } else {
        Err(SnapshotRecoveryInputViolation::TailSeqNotAfterSnapshot {
            snapshot_seq,
            actual_seq: event.seq,
        })
    }
}

pub(crate) const fn validate_recovery_data_present(
    tail_events_empty: bool,
    snapshot_slots_empty: bool,
    snapshot_taint_empty: bool,
    run_id: RunId,
) -> Result<(), SnapshotRecoveryInputViolation> {
    if tail_events_empty && snapshot_slots_empty && snapshot_taint_empty {
        Err(SnapshotRecoveryInputViolation::NoRecoveryData { run: run_id })
    } else {
        Ok(())
    }
}

/// Hydrates a live RunFrame from a snapshot plus ordered tail journal events.
///
/// Reconstructs the full runtime frame by decoding the snapshot's compact
/// slot/taint data and applying tail events on top.
///
/// # Errors
///
/// Returns `RecoveryError` when:
/// - Snapshot run_id does not match requested run_id
/// - Tail events contain a different run_id
/// - Tail event seq is not strictly after snapshot seq
/// - Snapshot bytes are corrupt or undecodable
/// - No snapshot and no tail events are provided
/// - Derived dimensions are zero or overflow `u16`
///
/// Hydrates a live `RunFrame` from a snapshot plus ordered tail events.
///
/// The snapshot+tail path is the **lower-level** durable hydration
/// mechanism: it consumes the snapshot bytes and reapplies tail events
/// to derive a `RunFrame` shape with hydrated slot/taint data and a
/// monotonically advanced program counter. The corresponding cannot-
/// resume witness lives at the typed boundary that consumes this
/// frame (the `RuntimeRecoveryBoundary`
/// implementation at the runtime layer; see
/// `DurableFrameRecoveryBoundary::hydrate_run_frame` and
/// `summary::recover_runtime_frame_seed_from_events`). The events-only
/// [`hydrate_run_frame_from_events`] entry point is where the typed
/// `UnsupportedFrameSeed { run, reason }` rejection is enforced, so
/// any caller passing a frame seed alone through the typed boundary
/// still fails closed with the precise reason string. The
/// snapshot+tail entry point ALSO enforces the typed cannot-resume
/// gate up-front via [`classify_snapshot_tail_cannot_resume`] so a
/// tail that would leave pending timers/asks/actions or carry a
/// `SlotWrittenEvent { value: None, .. }` is rejected with
/// `UnsupportedFrameSeed { reason }` BEFORE any frame is allocated.
/// This closes BLOCKER 4 and matches the typed-boundary contract the
/// events-only path already satisfies. The per-event-typed lower-
/// level gate is also enforced inside the tail application helpers
/// (see `hydrate_support::apply_slot_written`) so any
/// `SlotWrittenEvent { value: None }` that slips past the up-front
/// check (e.g. through a programmatic call path) is rejected by the
/// helper as defense-in-depth. A valid (snapshot slot bytes + tail
/// step lifecycle) path continues to assemble the lower-level frame
/// successfully. This keeps the unit-level durability, taint
/// preservation, and replay-shape tests green: they construct valid
/// durable evidence.
pub fn hydrate_run_frame(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> RecoveryResult<vb_core::RunFrame> {
    validate_snapshot_recovery_inputs(snapshot, tail_events, run_id)?;
    reject_if_cannot_resume(snapshot, tail_events, run_id)?;
    let snapshot_slots =
        decode_snapshot_slots(&snapshot.slots, &snapshot.taint, run_id, snapshot.seq)?;
    let (step_count, slot_count, first_step) =
        derive_dimensions_from_snapshot_and_tail(snapshot, tail_events, run_id, &snapshot_slots)?;
    ensure_nonzero_step_count(step_count)?;

    let mut frame = vb_core::RunFrame::new(run_id, first_step, step_count, slot_count)
        .map_err(|_| RecoveryError::FrameDimensionOverflow { run: run_id })?;
    apply_snapshot_slots(&mut frame, &snapshot_slots)?;

    let mut tracker = ActionReplayTracker::new();
    let executed = apply_tail_events(&mut frame, tail_events, &mut tracker, &[]);
    increment_executed(&mut frame, run_id, executed?)?;
    Ok(frame)
}

/// Rejects a snapshot+tail pair that fails the typed cannot-resume gate.
///
/// Returns `Ok(())` when the pair has enough evidence to rebuild a live
/// frame; otherwise returns `RecoveryError::UnsupportedFrameSeed`
/// carrying the precise priority-ordered reason string.
fn reject_if_cannot_resume(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> RecoveryResult<()> {
    let cannot_resume = classify_snapshot_tail_cannot_resume(snapshot, tail_events);
    if cannot_resume.is_resumable() {
        return Ok(());
    }
    Err(RecoveryError::UnsupportedFrameSeed {
        run: run_id,
        reason: String::from(cannot_resume.unsupported_reason()),
    })
}

/// Walks the snapshot+tail pair and classifies the cannot-resume
/// surface that the typed boundary would otherwise flag. Returns a
/// [`RecoveryCannotResumeState`] whose `is_resumable()` reflects
/// whether the pair carries enough evidence to rebuild a live frame.
///
/// Flags set by this helper:
/// - `slot_values` — any `SlotWrittenEvent { value: None, .. }` in
///   the tail (defense-in-depth alongside `apply_slot_written`).
/// - `pending_actions` — any `ActionScheduled` /
///   `ActionScheduledTicket` whose step still appears in the tail
///   without a matching `ActionCompleted*` / `ActionFailedEvent` /
///   `ActionAbandoned`.
/// - `pending_timers` — any `WaitScheduledEvent` whose step still
///   appears without a matching `WaitResolvedEvent`.
/// - `pending_asks` — any `AskScheduledEvent` whose step still
///   appears without a matching `AskAnsweredEvent` /
///   `AskTimedOutEvent`.
///
/// The frame-seed-only `*_missing` flags are NOT set by this helper:
/// they describe the absence of full RunState evidence, which the
/// snapshot+tail path rebuilds from durable snapshot bytes.
///
/// The `_snapshot` parameter is reserved for future flag-set
/// expansion: today the typed `*_missing` flags are stamped
/// unconditionally by [`RecoveryCannotResumeState::from_seed`], but
/// this helper will eventually need to inspect the snapshot's
/// `slots`/`taint`/`workflow` bytes to distinguish
/// `snapshot_supports_resume` from
/// `snapshot_bytes_diverge_from_tail`. Keeping the parameter in the
/// public signature avoids a future API break. Underscore prefix is
/// the standard Rust convention for intentional non-use.
#[must_use]
pub fn classify_snapshot_tail_cannot_resume(
    _snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
) -> RecoveryCannotResumeState {
    let mut state = RecoveryCannotResumeState::RESUMABLE;
    let mut pending_waits: BTreeSet<StepIdx> = BTreeSet::new();
    let mut pending_asks: BTreeSet<StepIdx> = BTreeSet::new();
    let mut pending_actions: BTreeSet<StepIdx> = BTreeSet::new();
    for event in tail_events {
        mark_slot_value_none(&mut state, event);
        drain_classify_event_to_pending_sets(
            &mut pending_waits,
            &mut pending_asks,
            &mut pending_actions,
            event,
        );
    }
    set_cannot_resume_from_pending_sets(
        &mut state,
        &pending_waits,
        &pending_asks,
        &pending_actions,
    );
    state
}

/// Sets `state.slot_values = true` when the event is a
/// `SlotWrittenEvent { value: None, .. }`; otherwise no-op.
fn mark_slot_value_none(state: &mut RecoveryCannotResumeState, event: &JournalEvent) {
    if let JournalEvent::SlotWrittenEvent { value: None, .. } = event {
        state.slot_values = true;
    }
}

/// Distributes a single event into the per-domain pending sets.
fn drain_classify_event_to_pending_sets(
    pending_waits: &mut BTreeSet<StepIdx>,
    pending_asks: &mut BTreeSet<StepIdx>,
    pending_actions: &mut BTreeSet<StepIdx>,
    event: &JournalEvent,
) {
    match event {
        JournalEvent::WaitScheduledEvent { step, .. } => {
            pending_waits.insert(*step);
        }
        JournalEvent::WaitResolvedEvent { step, .. } => {
            pending_waits.remove(step);
        }
        JournalEvent::AskScheduledEvent { step, .. } => {
            pending_asks.insert(*step);
        }
        JournalEvent::AskAnsweredEvent { step, .. } => {
            pending_asks.remove(step);
        }
        JournalEvent::AskTimedOutEvent { step, .. } => {
            pending_asks.remove(step);
        }
        JournalEvent::ActionScheduled { step, .. } => {
            pending_actions.insert(*step);
        }
        JournalEvent::ActionCompletedEvent { step, .. } => {
            pending_actions.remove(step);
        }
        JournalEvent::ActionFailedEvent { step, .. } => {
            pending_actions.remove(step);
        }
        JournalEvent::ActionScheduledTicket { ticket, .. } => {
            pending_actions.insert(ticket.step);
        }
        JournalEvent::ActionCompletedEnvelope { ticket, .. } => {
            pending_actions.remove(&ticket.step);
        }
        JournalEvent::ActionAbandoned { ticket, .. } => {
            pending_actions.remove(&ticket.step);
        }
        _ => {}
    }
}

/// Transfers the "non-empty pending set" markers from the per-domain
/// sets into the typed cannot-resume witness. Only the boolean
/// emptiness flags are set; the `slot_values` flag is set by
/// [`mark_slot_value_none`] because it does not require accumulation.
fn set_cannot_resume_from_pending_sets(
    state: &mut RecoveryCannotResumeState,
    waits: &BTreeSet<StepIdx>,
    asks: &BTreeSet<StepIdx>,
    actions: &BTreeSet<StepIdx>,
) {
    state.pending_timers = !waits.is_empty();
    state.pending_asks = !asks.is_empty();
    state.pending_actions = !actions.is_empty();
}

fn validate_snapshot_recovery_inputs(
    snapshot: &RunSnapshot,
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> RecoveryResult<()> {
    validate_snapshot_metadata(snapshot.run, snapshot.seq, run_id)
        .map_err(snapshot_input_violation_to_error)?;
    validate_tail_events_match_run(tail_events, run_id)?;
    validate_tail_events_after_snapshot(tail_events, snapshot)?;
    validate_recovery_data_present(
        tail_events.is_empty(),
        snapshot.slots.is_empty(),
        snapshot.taint.is_empty(),
        run_id,
    )
    .map_err(snapshot_input_violation_to_error)
}

fn validate_tail_events_match_run(
    tail_events: &[JournalEvent],
    run_id: RunId,
) -> RecoveryResult<()> {
    for event in tail_events {
        validate_tail_run_metadata(TailEventMetadata::from_event(event), run_id)
            .map_err(snapshot_input_violation_to_error)?;
    }
    Ok(())
}

fn validate_tail_events_after_snapshot(
    tail_events: &[JournalEvent],
    snapshot: &RunSnapshot,
) -> RecoveryResult<()> {
    // Contiguity gate: first tail event must be snapshot.seq + 1.
    // This catches gaps between snapshot and tail that the
    // per-event ordering check misses.
    if let Some(first) = tail_events.first() {
        let first_seq = first.seq();
        let expected = snapshot
            .seq
            .get()
            .checked_add(1)
            .ok_or(SnapshotRecoveryInputViolation::TailSeqGap {
                snapshot_seq: snapshot.seq,
                actual_seq: snapshot.seq,
            })
            .map_err(snapshot_input_violation_to_error)?;
        if first_seq.get() != expected {
            return Err(snapshot_input_violation_to_error(
                SnapshotRecoveryInputViolation::TailSeqGap {
                    snapshot_seq: snapshot.seq,
                    actual_seq: first_seq,
                },
            ));
        }
    }
    for event in tail_events {
        validate_tail_seq_after_snapshot(TailEventMetadata::from_event(event), snapshot.seq)
            .map_err(snapshot_input_violation_to_error)?;
    }
    Ok(())
}

fn snapshot_input_violation_to_error(violation: SnapshotRecoveryInputViolation) -> RecoveryError {
    match violation {
        SnapshotRecoveryInputViolation::SnapshotRunMismatch {
            expected_run,
            snapshot_seq,
            ..
        } => RecoveryError::CorruptSnapshot {
            run: expected_run,
            seq: snapshot_seq,
        },
        SnapshotRecoveryInputViolation::TailRunMismatch { expected, actual } => {
            RecoveryError::ReplayDivergence {
                step: vb_core::StepIdx::ZERO,
                detail: format!(
                    "tail event run_id mismatch: expected {expected:?}, found {actual:?}"
                ),
            }
        }
        SnapshotRecoveryInputViolation::TailSeqNotAfterSnapshot {
            snapshot_seq,
            actual_seq,
        } => RecoveryError::ReplayDivergence {
            step: vb_core::StepIdx::ZERO,
            detail: format!(
                "tail event seq {} is not after snapshot seq {}",
                actual_seq.get(),
                snapshot_seq.get()
            ),
        },
        SnapshotRecoveryInputViolation::TailSeqGap {
            snapshot_seq,
            actual_seq,
        } => RecoveryError::ReplayDivergence {
            step: vb_core::StepIdx::ZERO,
            detail: format!(
                "tail event seq {} is not contiguous with snapshot seq {} (gap detected)",
                actual_seq.get(),
                snapshot_seq.get()
            ),
        },
        SnapshotRecoveryInputViolation::NoRecoveryData { run } => {
            RecoveryError::NoRecoveryData { run }
        }
    }
}

fn ensure_nonzero_step_count(step_count: u16) -> RecoveryResult<()> {
    if step_count == 0 {
        return Err(RecoveryError::ReplayDivergence {
            step: vb_core::StepIdx::ZERO,
            detail: "derived step_count is zero".to_owned(),
        });
    }
    Ok(())
}

fn apply_snapshot_slots(
    frame: &mut vb_core::RunFrame,
    snapshot_slots: &[RecoveredSlotEntry],
) -> RecoveryResult<()> {
    for entry in snapshot_slots {
        frame
            .write_slot_with_taint(entry.slot, entry.value, entry.taint)
            .map_err(|_| RecoveryError::ReplayDivergence {
                step: vb_core::StepIdx::ZERO,
                detail: "snapshot slot write out of bounds".to_owned(),
            })?;
    }
    Ok(())
}

fn increment_executed(
    frame: &mut vb_core::RunFrame,
    run_id: RunId,
    executed: u64,
) -> RecoveryResult<()> {
    for _ in 0..executed {
        frame
            .increment_executed()
            .map_err(|_| RecoveryError::FrameDimensionOverflow { run: run_id })?;
    }
    Ok(())
}

/// Hydrates a live RunFrame from full journal events (no snapshot).
///
/// # Errors
///
/// Returns `RecoveryError` when:
/// - Events are empty
/// - Derived dimensions are zero or overflow `u16`
/// - The recovered frame seed is cannot-resume (e.g. pending
///   actions, pending timers, pending asks, unsupported slot
///   values/taint/payloads, or missing full-RunState components
///   like workflow, store, action attempts, admission, collect
///   states, action contracts, or action ABI digests).
pub fn hydrate_run_frame_from_events(
    events: &[JournalEvent],
    run_id: RunId,
) -> RecoveryResult<vb_core::RunFrame> {
    if events.is_empty() {
        return Err(RecoveryError::NoRecoveryData { run: run_id });
    }

    let seed = crate::recovery::replay::summary::recover_runtime_frame_seed_from_events(events)?;
    ensure_nonzero_step_count(seed.step_count)?;
    let cannot_resume = seed.cannot_resume_state();
    if !cannot_resume.is_resumable() {
        return Err(RecoveryError::UnsupportedFrameSeed {
            run: run_id,
            reason: String::from(cannot_resume.unsupported_reason()),
        });
    }
    let mut frame = build_frame_from_seed(&seed, run_id)?;
    apply_seed_step_states(&mut frame, &seed.steps)?;
    apply_seed_slots(&mut frame, &seed.slots)?;
    apply_seed_pc(&mut frame, seed.pc)?;
    let executed = apply_replay_accounting(&mut frame, events, run_id, &[])?;
    increment_executed(&mut frame, run_id, executed)?;

    Ok(frame)
}

fn build_frame_from_seed(
    seed: &RecoveryFrameSeed,
    run_id: RunId,
) -> RecoveryResult<vb_core::RunFrame> {
    vb_core::RunFrame::new(run_id, seed.first_step, seed.step_count, seed.slot_count)
        .map_err(|_| RecoveryError::FrameDimensionOverflow { run: run_id })
}

fn apply_seed_step_states(
    frame: &mut vb_core::RunFrame,
    steps: &[RecoveredStepEntry],
) -> RecoveryResult<()> {
    for entry in steps {
        let result = match entry.state {
            RecoveredStepState::Running => frame.mark_running(entry.step),
            RecoveredStepState::Succeeded => frame.mark_succeeded(entry.step),
            RecoveredStepState::Failed => frame.mark_failed(entry.step),
            RecoveredStepState::Waiting => frame
                .mark_running(entry.step)
                .and_then(|_| frame.mark_waiting(entry.step)),
            RecoveredStepState::Asking => frame
                .mark_running(entry.step)
                .and_then(|_| frame.mark_asking(entry.step)),
        };
        result.map_err(|_| RecoveryError::ReplayDivergence {
            step: entry.step,
            detail: "seed step state transition failed".to_owned(),
        })?;
    }
    Ok(())
}

fn apply_seed_slots(
    frame: &mut vb_core::RunFrame,
    slots: &[RecoveredSlotEntry],
) -> RecoveryResult<()> {
    for entry in slots {
        frame
            .write_slot_with_taint(entry.slot, entry.value, entry.taint)
            .map_err(|_| RecoveryError::ReplayDivergence {
                step: vb_core::StepIdx::ZERO,
                detail: "seed slot write out of bounds".to_owned(),
            })?;
    }
    Ok(())
}

fn apply_seed_pc(frame: &mut vb_core::RunFrame, pc: vb_core::StepIdx) -> RecoveryResult<()> {
    frame
        .set_pc(pc)
        .map_err(|_| RecoveryError::ReplayDivergence {
            step: pc,
            detail: "seed pc out of bounds".to_owned(),
        })
}

fn apply_replay_accounting(
    frame: &mut vb_core::RunFrame,
    events: &[JournalEvent],
    run_id: RunId,
    expected_action_abi_digests: &[(vb_core::ActionId, vb_core::WorkflowDigest)],
) -> RecoveryResult<u64> {
    let mut tracker = ActionReplayTracker::new();
    let mut count = 0u64;
    let mut peak = 0u16;
    for event in events {
        if apply_accounting_event(frame, event, &mut tracker, expected_action_abi_digests)? {
            count = increment_replay_count(count, run_id)?;
        }
        if frame.parallel_in_flight() > peak {
            peak = frame.parallel_in_flight();
        }
    }
    frame.set_max_parallel_in_flight(peak);
    Ok(count)
}

fn increment_replay_count(current: u64, run_id: RunId) -> RecoveryResult<u64> {
    current
        .checked_add(1)
        .ok_or(RecoveryError::FrameDimensionOverflow { run: run_id })
}
fn apply_accounting_event(
    frame: &mut vb_core::RunFrame,
    event: &JournalEvent,
    tracker: &mut ActionReplayTracker,
    expected_action_abi_digests: &[(vb_core::ActionId, vb_core::WorkflowDigest)],
) -> RecoveryResult<bool> {
    match event {
        JournalEvent::ActionScheduled { .. }
        | JournalEvent::ActionCompletedEvent { .. }
        | JournalEvent::ActionFailedEvent { .. } => {
            apply_simple_action_event(frame, tracker, event)
        }
        JournalEvent::ActionScheduledTicket { .. } => {
            apply_action_scheduled_ticket_event(frame, tracker, event, expected_action_abi_digests)
        }
        JournalEvent::ActionCompletedEnvelope { .. } => apply_action_completed_envelope_event(
            frame,
            tracker,
            event,
            expected_action_abi_digests,
        ),
        _ => classify_metadata_event(event),
    }
}

fn apply_simple_action_event(
    frame: &mut vb_core::RunFrame,
    tracker: &mut ActionReplayTracker,
    event: &JournalEvent,
) -> RecoveryResult<bool> {
    match event {
        JournalEvent::ActionScheduled { action, step, .. } => {
            reject_resolved_action(tracker, *action, *step)?;
            add_replay_parallel_in_flight(frame, *step).map(|()| true)
        }
        JournalEvent::ActionCompletedEvent { action, step, .. } => {
            reject_resolved_action(tracker, *action, *step)?;
            tracker.mark_completed(*action, *step);
            sub_replay_parallel_in_flight(frame, *step).map(|()| true)
        }
        JournalEvent::ActionFailedEvent { action, step, .. } => {
            reject_resolved_action(tracker, *action, *step)?;
            tracker.mark_failed(*action, *step);
            sub_replay_parallel_in_flight(frame, *step).map(|()| true)
        }
        _ => Ok(false),
    }
}

fn apply_action_scheduled_ticket_event(
    frame: &mut vb_core::RunFrame,
    tracker: &mut ActionReplayTracker,
    event: &JournalEvent,
    expected_action_abi_digests: &[(vb_core::ActionId, vb_core::WorkflowDigest)],
) -> RecoveryResult<bool> {
    let JournalEvent::ActionScheduledTicket {
        run,
        ticket,
        input,
        output,
        action_abi_digest,
        ..
    } = event
    else {
        return Ok(false);
    };
    verify_action_ticket_event(*run, *ticket)?;
    check_action_abi_digest_against_expected(
        ticket.action,
        *action_abi_digest,
        expected_action_abi_digests,
    )?;
    let effect =
        tracker.mark_scheduled_ticket_effect(*ticket, *input, *output, *action_abi_digest)?;
    if effect == ActionReplayEffect::Apply {
        add_replay_parallel_in_flight(frame, ticket.step)?;
    }
    Ok(effect == ActionReplayEffect::Apply)
}

fn apply_action_completed_envelope_event(
    frame: &mut vb_core::RunFrame,
    tracker: &mut ActionReplayTracker,
    event: &JournalEvent,
    expected_action_abi_digests: &[(vb_core::ActionId, vb_core::WorkflowDigest)],
) -> RecoveryResult<bool> {
    let JournalEvent::ActionCompletedEnvelope {
        run,
        ticket,
        output,
        outcome,
        value,
        encoded_len,
        taint,
        value_digest,
        action_abi_digest,
        ..
    } = event
    else {
        return Ok(false);
    };
    let verified_digest = verified_action_envelope_digest(
        *run,
        *ticket,
        *outcome,
        value,
        *encoded_len,
        *value_digest,
    )?;
    tracker.require_scheduled_ticket(*ticket, *output, *action_abi_digest)?;
    check_action_abi_digest_against_expected(
        ticket.action,
        *action_abi_digest,
        expected_action_abi_digests,
    )?;
    let effect = tracker.mark_completed_envelope_effect(
        *ticket,
        *output,
        *encoded_len,
        *taint,
        verified_digest,
        *action_abi_digest,
    )?;
    if effect == ActionReplayEffect::Apply {
        sub_replay_parallel_in_flight(frame, ticket.step)?;
    }
    Ok(effect == ActionReplayEffect::Apply)
}
// VB-NOORE (wildcard elimination): explicit arms for every
// JournalEvent variant so adding a new variant forces a
// compile-time failure. The dispatcher routes action events
// to dedicated helpers, so this classifier returns Ok(false)
// for any action variant that ever reaches it (a defensive
// belt-and-braces for the dispatcher's `_ =>` arm).
fn classify_metadata_event(event: &JournalEvent) -> RecoveryResult<bool> {
    match event {
        JournalEvent::StepStarted { .. }
        | JournalEvent::StepSucceeded { .. }
        | JournalEvent::StepFailed { .. }
        | JournalEvent::SlotWrittenEvent { .. }
        | JournalEvent::WaitScheduledEvent { .. }
        | JournalEvent::AskScheduledEvent { .. }
        | JournalEvent::AskTimedOutEvent { .. }
        | JournalEvent::WaitResolvedEvent { .. }
        | JournalEvent::AskAnsweredEvent { .. }
        | JournalEvent::RetryScheduledEvent { .. }
        | JournalEvent::PolicyDecisionEvent { .. } => Ok(true),
        JournalEvent::ActionScheduled { .. }
        | JournalEvent::ActionScheduledTicket { .. }
        | JournalEvent::ActionCompletedEvent { .. }
        | JournalEvent::ActionCompletedEnvelope { .. }
        | JournalEvent::ActionFailedEvent { .. }
        | JournalEvent::ActionAbandoned { .. }
        | JournalEvent::RunAccepted { .. }
        | JournalEvent::RunAdmission { .. }
        | JournalEvent::RetryCheckpoint { .. }
        | JournalEvent::RunCancelled { .. }
        | JournalEvent::RunKilled { .. }
        | JournalEvent::RunFinished { .. }
        | JournalEvent::RunFailedEvent { .. }
        | JournalEvent::RunResumed { .. }
        | JournalEvent::RunRetried { .. }
        | JournalEvent::RunAnswered { .. } => Ok(false),
    }
}

fn add_replay_parallel_in_flight(
    frame: &mut vb_core::RunFrame,
    step: vb_core::StepIdx,
) -> RecoveryResult<()> {
    frame
        .add_parallel_in_flight(1)
        .map_err(|_| RecoveryError::ReplayDivergence {
            step,
            detail: "parallel_in_flight overflow".to_owned(),
        })
}

fn sub_replay_parallel_in_flight(
    frame: &mut vb_core::RunFrame,
    step: vb_core::StepIdx,
) -> RecoveryResult<()> {
    frame
        .sub_parallel_in_flight(1)
        .map_err(|_| RecoveryError::ReplayDivergence {
            step,
            detail: "parallel_in_flight underflow".to_owned(),
        })
}

fn reject_resolved_action(
    tracker: &ActionReplayTracker,
    action: vb_core::ActionId,
    step: vb_core::StepIdx,
) -> RecoveryResult<()> {
    if tracker.is_resolved(action, step) {
        return Err(RecoveryError::NonIdempotentActionBlocked { action, step });
    }
    Ok(())
}
/// Checks whether the found action ABI digest matches any of the expected digests.
fn check_action_abi_digest_against_expected(
    action_id: ActionId,
    found: WorkflowDigest,
    expected: &[(ActionId, WorkflowDigest)],
) -> RecoveryResult<()> {
    if found == zero_workflow_digest() {
        return Err(RecoveryError::ActionAbiMismatch { action_id });
    }
    for (exp_action_id, exp_digest) in expected {
        if *exp_action_id == action_id {
            if *exp_digest == zero_workflow_digest() || *exp_digest != found {
                return Err(RecoveryError::ActionAbiMismatch {
                    action_id: *exp_action_id,
                });
            }
            return Ok(());
        }
    }
    Err(RecoveryError::ActionAbiMismatch { action_id })
}

const fn zero_workflow_digest() -> WorkflowDigest {
    WorkflowDigest::from_bytes([0; 32])
}
