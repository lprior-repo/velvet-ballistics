#![forbid(unsafe_code)]
//! Run lifecycle management: submit, resume, cancel, action completion, timers.

#[path = "lifecycle/execution_binding.rs"]
mod execution_binding;

include!("lifecycle/chunk_003.rs");
include!("lifecycle/chunk_001.rs");
include!("lifecycle/chunk_002.rs");
include!("lifecycle/chunk_005.rs");
include!("lifecycle/chunk_004.rs");

#[cfg(test)]
mod tests {
    include!("lifecycle_tests/chunk_001.rs");
    include!("lifecycle_tests/chunk_002.rs");
    include!("lifecycle_tests/chunk_003.rs");
    include!("lifecycle_tests/chunk_004.rs");
    include!("lifecycle_tests/chunk_005.rs");
    include!("lifecycle_tests/chunk_006.rs");
    include!("lifecycle_tests/chunk_007.rs");
    include!("lifecycle_tests/chunk_008.rs");
    include!("lifecycle_tests/chunk_009.rs");
    include!("lifecycle_tests/chunk_010.rs");
    include!("lifecycle_tests/recovery_context_tests.rs");
    include!("lifecycle_tests/contract_validation_tests.rs");
    include!("lifecycle_tests/action_recovery_tests.rs");
}
